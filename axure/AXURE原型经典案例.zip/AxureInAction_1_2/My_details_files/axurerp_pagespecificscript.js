﻿for(var i = 0; i < 147; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if ((GetGlobalVariableValue('ShoppingBasket')) == ('Empty')) {

	SetPanelState('u61', 'pd0u61','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('1'))) {

SetWidgetRichText('u63', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (1 item)</span></p>');

	SetPanelState('u61', 'pd1u61','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('2'))) {

SetWidgetRichText('u63', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (2 items)</span></p>');

	SetPanelState('u61', 'pd1u61','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('3'))) {

SetWidgetRichText('u63', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (3 items)</span></p>');

	SetPanelState('u61', 'pd1u61','none','',500,'none','',500);

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) {

}

});

function rdo0LoadHome(e) {

}
u115.tabIndex = 0;

u115.style.cursor = 'pointer';
$axure.eventManager.click('u115', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
document.getElementById('u21_img').tabIndex = 0;
HookHover('u21', false);

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u132'] = 'top';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u4'] = 'top';document.getElementById('u17_img').tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	SetPanelState('u0', 'pd1u0','none','',500,'none','',500);

	MoveWidgetBy('u122', GetNum('0'), GetNum('135'),'none',500);

}
});
u135.tabIndex = 0;

u135.style.cursor = 'pointer';
$axure.eventManager.click('u135', function(e) {

if (true) {

SetGlobalVariableValue('LoginStatus', 'LoggedOut');

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Logged_out.html');

}
});
gv_vAlignTable['u135'] = 'top';gv_vAlignTable['u42'] = 'center';u101.tabIndex = 0;

u101.style.cursor = 'pointer';
$axure.eventManager.click('u101', function(e) {

if (true) {

	SetPanelVisibility('u76','hidden','none',500);

}
});

$axure.eventManager.mouseover('u101', function(e) {
if (!IsTrueMouseOver('u101',e)) return;
if (true) {

	SetPanelVisibility('u86','','none',500);

}
});

$axure.eventManager.mouseout('u101', function(e) {
if (!IsTrueMouseOut('u101',e)) return;
if (true) {

	SetPanelVisibility('u86','hidden','none',500);

}
});
gv_vAlignTable['u14'] = 'center';gv_vAlignTable['u48'] = 'center';u105.tabIndex = 0;

u105.style.cursor = 'pointer';
$axure.eventManager.click('u105', function(e) {

if (true) {

	SetPanelVisibility('u76','hidden','none',500);

}
});

$axure.eventManager.mouseover('u105', function(e) {
if (!IsTrueMouseOver('u105',e)) return;
if (true) {

	SetPanelVisibility('u95','','none',500);

}
});

$axure.eventManager.mouseout('u105', function(e) {
if (!IsTrueMouseOut('u105',e)) return;
if (true) {

	SetPanelVisibility('u95','hidden','none',500);

}
});
document.getElementById('u27_img').tabIndex = 0;
HookHover('u27', false);

u27.style.cursor = 'pointer';
$axure.eventManager.click('u27', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u138'] = 'center';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u120'] = 'top';u110.tabIndex = 0;

u110.style.cursor = 'pointer';
$axure.eventManager.click('u110', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');

SetGlobalVariableValue('BookPageViewed', '');

SetGlobalVariableValue('CitySelected', '');

SetGlobalVariableValue('LoginStatus', '');

SetGlobalVariableValue('ReviewVar', '');

SetGlobalVariableValue('EmployeesName', '');

	SetPanelState('u108', 'pd1u108','none','',500,'none','',500);
function waituf022ddcb6b474903a282219d39d908ef1() {

	SetPanelState('u108', 'pd0u108','none','',500,'none','',500);
}
setTimeout(waituf022ddcb6b474903a282219d39d908ef1, 4000);

}
});
gv_vAlignTable['u110'] = 'top';document.getElementById('u37_img').tabIndex = 0;
HookHover('u37', false);

u37.style.cursor = 'pointer';
$axure.eventManager.click('u37', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
document.getElementById('u62_img').tabIndex = 0;

u62.style.cursor = 'pointer';
$axure.eventManager.click('u62', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}
});
gv_vAlignTable['u75'] = 'center';document.getElementById('u133_img').tabIndex = 0;

u133.style.cursor = 'pointer';
$axure.eventManager.click('u133', function(e) {

if (true) {

SetGlobalVariableValue('Address1', GetWidgetText('u126'));

SetWidgetRichText('u136', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('Address1')) + ' ' + (GetGlobalVariableValue('Address2')) + '</span></p>');

SetGlobalVariableValue('City', GetWidgetText('u130'));

SetWidgetRichText('u141', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('City')) + '</span></p>');

SetGlobalVariableValue('Postcode', GetWidgetText('u131'));

SetWidgetRichText('u142', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('Postcode')) + '</span></p>');

SetGlobalVariableValue('Address2', GetWidgetText('u128'));

	SetPanelState('u122', 'pd0u122','none','',500,'none','',500);

}
});
gv_vAlignTable['u34'] = 'center';document.getElementById('u47_img').tabIndex = 0;
HookHover('u47', false);

u47.style.cursor = 'pointer';
$axure.eventManager.click('u47', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u88'] = 'center';u103.tabIndex = 0;

u103.style.cursor = 'pointer';
$axure.eventManager.click('u103', function(e) {

if (true) {

	SetPanelVisibility('u76','hidden','none',500);

}
});

$axure.eventManager.mouseover('u103', function(e) {
if (!IsTrueMouseOver('u103',e)) return;
if (true) {

	SetPanelVisibility('u89','','none',500);

}
});

$axure.eventManager.mouseout('u103', function(e) {
if (!IsTrueMouseOut('u103',e)) return;
if (true) {

	SetPanelVisibility('u89','hidden','none',500);

}
});
gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u112'] = 'center';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u78'] = 'center';u119.tabIndex = 0;

u119.style.cursor = 'pointer';
$axure.eventManager.click('u119', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u119'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u125'] = 'top';document.getElementById('u41_img').tabIndex = 0;
HookHover('u41', false);

u41.style.cursor = 'pointer';
$axure.eventManager.click('u41', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
document.getElementById('u25_img').tabIndex = 0;
HookHover('u25', false);

u25.style.cursor = 'pointer';
$axure.eventManager.click('u25', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u140'] = 'center';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u85'] = 'center';document.getElementById('u51_img').tabIndex = 0;
HookHover('u51', false);

u51.style.cursor = 'pointer';
$axure.eventManager.click('u51', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u10'] = 'center';gv_vAlignTable['u100'] = 'top';document.getElementById('u23_img').tabIndex = 0;
HookHover('u23', false);

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u30'] = 'center';u116.tabIndex = 0;

u116.style.cursor = 'pointer';
$axure.eventManager.click('u116', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
else
if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('LoginStatus')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u116'] = 'top';document.getElementById('u74_img').tabIndex = 0;

u74.style.cursor = 'pointer';
$axure.eventManager.click('u74', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u106'));

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Search_results.html');

}
});
gv_vAlignTable['u114'] = 'center';document.getElementById('u33_img').tabIndex = 0;
HookHover('u33', false);

u33.style.cursor = 'pointer';
$axure.eventManager.click('u33', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u98'] = 'top';gv_vAlignTable['u127'] = 'top';document.getElementById('u43_img').tabIndex = 0;
HookHover('u43', false);

u43.style.cursor = 'pointer';
$axure.eventManager.click('u43', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u142'] = 'top';
$axure.eventManager.keyup('u106', function(e) {

if ((GetWidgetText('u106')) == ('')) {

	SetPanelVisibility('u76','hidden','none',500);

}
else
if (true) {

	SetPanelState('u76', 'pd0u76','none','',500,'none','',500);

SetGlobalVariableValue('IncrementalSearchVar', GetWidgetText('u106'));

SetWidgetRichText('u98', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dada</span></p>');

SetWidgetRichText('u99', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dat</span></p>');

SetWidgetRichText('u100', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">gi</span></p>');

SetWidgetRichText('u102', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

SetWidgetRichText('u82', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

	SetPanelVisibility('u76','','none',500);

	BringToFront("u76");
function waitu796b5745765043a58e9fe38835b455f51() {

	SetPanelState('u76', 'pd1u76','none','',500,'none','',500);
}
setTimeout(waitu796b5745765043a58e9fe38835b455f51, 2000);

}
});

$axure.eventManager.blur('u106', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u106'));

}
});
gv_vAlignTable['u40'] = 'center';document.getElementById('u139_img').tabIndex = 0;

u139.style.cursor = 'pointer';
$axure.eventManager.click('u139', function(e) {

if (true) {

	SetPanelState('u122', 'pd1u122','none','',500,'none','',500);

}
});
document.getElementById('u53_img').tabIndex = 0;
HookHover('u53', false);

u53.style.cursor = 'pointer';
$axure.eventManager.click('u53', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
u104.tabIndex = 0;

u104.style.cursor = 'pointer';
$axure.eventManager.click('u104', function(e) {

if (true) {

	SetPanelVisibility('u76','hidden','none',500);

}
});

$axure.eventManager.mouseover('u104', function(e) {
if (!IsTrueMouseOver('u104',e)) return;
if (true) {

	SetPanelVisibility('u92','','none',500);

}
});

$axure.eventManager.mouseout('u104', function(e) {
if (!IsTrueMouseOut('u104',e)) return;
if (true) {

	SetPanelVisibility('u92','hidden','none',500);

}
});
u121.tabIndex = 0;

u121.style.cursor = 'pointer';
$axure.eventManager.click('u121', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u121'] = 'top';document.getElementById('u19_img').tabIndex = 0;
HookHover('u19', false);

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
u109.tabIndex = 0;

u109.style.cursor = 'pointer';
$axure.eventManager.click('u109', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');
function waitud60c4460105243299b524b0b32b428cf1() {

	SetPanelState('u108', 'pd1u108','none','',500,'none','',500);
function waitub3ccdb0e2b0e45289ccb18b7f7d0de481() {
function waitu7d17a4dc47ea4dd0b7636d8a947ae1e31() {
}
setTimeout(waitu7d17a4dc47ea4dd0b7636d8a947ae1e31, 200);
}
setTimeout(waitub3ccdb0e2b0e45289ccb18b7f7d0de481, 200);
}
setTimeout(waitud60c4460105243299b524b0b32b428cf1, 300);

}
});
gv_vAlignTable['u109'] = 'top';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u97'] = 'center';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u134'] = 'center';gv_vAlignTable['u81'] = 'center';gv_vAlignTable['u94'] = 'center';gv_vAlignTable['u102'] = 'top';document.getElementById('u9_img').tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

SetGlobalVariableValue('Title', GetSelectedOption('u2'));

SetGlobalVariableValue('FirstName', GetWidgetText('u5'));

SetGlobalVariableValue('Surname', GetWidgetText('u6'));

SetGlobalVariableValue('Email', GetWidgetText('u8'));

SetWidgetRichText('u16', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('Email')) + '</span></p>');

SetWidgetRichText('u15', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('Title')) + ' ' + (GetGlobalVariableValue('FirstName')) + ' ' + (GetGlobalVariableValue('Surname')) + '</span></p>');

	SetPanelState('u0', 'pd0u0','none','',500,'none','',500);

	MoveWidgetBy('u122', GetNum('0'), GetNum('-135'),'none',500);

}
});
gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u91'] = 'center';document.getElementById('u64_img').tabIndex = 0;

u64.style.cursor = 'pointer';
$axure.eventManager.click('u64', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}

if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('OnLoadVariable')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u24'] = 'center';HookHover('u113', false);
HookHover('u29', false);
document.getElementById('u111_img').tabIndex = 0;

u111.style.cursor = 'pointer';
$axure.eventManager.click('u111', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u141'] = 'top';gv_vAlignTable['u129'] = 'top';document.getElementById('u58_img').tabIndex = 0;

u58.style.cursor = 'pointer';
$axure.eventManager.click('u58', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
document.getElementById('u39_img').tabIndex = 0;
HookHover('u39', false);

u39.style.cursor = 'pointer';
$axure.eventManager.click('u39', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
document.getElementById('u31_img').tabIndex = 0;
HookHover('u31', false);

u31.style.cursor = 'pointer';
$axure.eventManager.click('u31', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
u83.tabIndex = 0;

u83.style.cursor = 'pointer';
$axure.eventManager.click('u83', function(e) {

if (true) {

	SetPanelVisibility('u76','hidden','none',500);

}
});

$axure.eventManager.mouseover('u83', function(e) {
if (!IsTrueMouseOver('u83',e)) return;
if (true) {

	SetPanelVisibility('u79','','none',500);

}
});

$axure.eventManager.mouseout('u83', function(e) {
if (!IsTrueMouseOut('u83',e)) return;
if (true) {

	SetPanelVisibility('u79','hidden','none',500);

}
});
gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u146'] = 'top';gv_vAlignTable['u15'] = 'top';document.getElementById('u49_img').tabIndex = 0;
HookHover('u49', false);

u49.style.cursor = 'pointer';
$axure.eventManager.click('u49', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u124'] = 'center';gv_vAlignTable['u1'] = 'top';gv_vAlignTable['u145'] = 'center';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u59'] = 'center';gv_vAlignTable['u18'] = 'center';document.getElementById('u45_img').tabIndex = 0;
HookHover('u45', false);

u45.style.cursor = 'pointer';
$axure.eventManager.click('u45', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u22'] = 'center';u143.tabIndex = 0;

u143.style.cursor = 'pointer';
$axure.eventManager.click('u143', function(e) {

if (true) {

SetGlobalVariableValue('LoginStatus', 'LoggedOut');

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Logged_out.html');

}
});
gv_vAlignTable['u143'] = 'top';u107.tabIndex = 0;

u107.style.cursor = 'pointer';
$axure.eventManager.click('u107', function(e) {

if (true) {

	self.location.href='index.html';

}
});
gv_vAlignTable['u107'] = 'top';document.getElementById('u35_img').tabIndex = 0;
HookHover('u35', false);

u35.style.cursor = 'pointer';
$axure.eventManager.click('u35', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u136'] = 'top';gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u28'] = 'center';