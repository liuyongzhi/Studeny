﻿for(var i = 0; i < 224; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

SetWidgetSelected('u70');
}

if ((GetGlobalVariableValue('ShoppingBasket')) == ('Empty')) {

	SetPanelState('u82', 'pd0u82','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('1'))) {

SetWidgetRichText('u84', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (1 item)</span></p>');

	SetPanelState('u82', 'pd1u82','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('2'))) {

SetWidgetRichText('u84', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (2 items)</span></p>');

	SetPanelState('u82', 'pd1u82','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('3'))) {

SetWidgetRichText('u84', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (3 items)</span></p>');

	SetPanelState('u82', 'pd1u82','none','',500,'none','',500);

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) {

}

});

function rdo1LoadHome(e) {

}
gv_vAlignTable['u115'] = 'center';u122.tabIndex = 0;

u122.style.cursor = 'pointer';
$axure.eventManager.click('u122', function(e) {

if (true) {

	SetPanelVisibility('u97','hidden','none',500);

}
});

$axure.eventManager.mouseover('u122', function(e) {
if (!IsTrueMouseOver('u122',e)) return;
if (true) {

	SetPanelVisibility('u107','','none',500);

}
});

$axure.eventManager.mouseout('u122', function(e) {
if (!IsTrueMouseOut('u122',e)) return;
if (true) {

	SetPanelVisibility('u107','hidden','none',500);

}
});
u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u21'] = 'top';document.getElementById('u32_img').tabIndex = 0;

u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
u207.tabIndex = 0;

u207.style.cursor = 'pointer';
$axure.eventManager.click('u207', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waitu0e30295b3ce74d9cb13d267f4360bbfe1() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waitu0e30295b3ce74d9cb13d267f4360bbfe1, 300);

}
});
gv_vAlignTable['u207'] = 'top';u130.tabIndex = 0;

u130.style.cursor = 'pointer';
$axure.eventManager.click('u130', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');
function waitud60c4460105243299b524b0b32b428cf1() {

	SetPanelState('u129', 'pd1u129','none','',500,'none','',500);
function waitub3ccdb0e2b0e45289ccb18b7f7d0de481() {
function waitu7d17a4dc47ea4dd0b7636d8a947ae1e31() {
}
setTimeout(waitu7d17a4dc47ea4dd0b7636d8a947ae1e31, 200);
}
setTimeout(waitub3ccdb0e2b0e45289ccb18b7f7d0de481, 200);
}
setTimeout(waitud60c4460105243299b524b0b32b428cf1, 300);

}
});
gv_vAlignTable['u130'] = 'top';u7.tabIndex = 0;

u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u2'] = 'center';document.getElementById('u79_img').tabIndex = 0;

u79.style.cursor = 'pointer';
$axure.eventManager.click('u79', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
u153.tabIndex = 0;

u153.style.cursor = 'pointer';
$axure.eventManager.click('u153', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waitua9d4e74b71f04f63bb74269e5f883dea1() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waitua9d4e74b71f04f63bb74269e5f883dea1, 300);

}
});
gv_vAlignTable['u153'] = 'top';u140.tabIndex = 0;

u140.style.cursor = 'pointer';
$axure.eventManager.click('u140', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u140'] = 'top';u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u17'] = 'top';u222.tabIndex = 0;

u222.style.cursor = 'pointer';
$axure.eventManager.click('u222', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u222'] = 'top';gv_vAlignTable['u135'] = 'center';u151.tabIndex = 0;

u151.style.cursor = 'pointer';
$axure.eventManager.click('u151', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waituef0c66c2faab4ccbb36ce44f3e2ffa851() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waituef0c66c2faab4ccbb36ce44f3e2ffa851, 300);

}
});
gv_vAlignTable['u151'] = 'top';document.getElementById('u42_img').tabIndex = 0;
HookHover('u42', false);

u42.style.cursor = 'pointer';
$axure.eventManager.click('u42', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
u159.tabIndex = 0;

u159.style.cursor = 'pointer';
$axure.eventManager.click('u159', function(e) {

if (true) {

	SetPanelState('u141', 'pd1u141','none','',500,'none','',500);

}
});
gv_vAlignTable['u159'] = 'top';gv_vAlignTable['u55'] = 'center';u14.tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u14'] = 'top';document.getElementById('u48_img').tabIndex = 0;
HookHover('u48', false);

u48.style.cursor = 'pointer';
$axure.eventManager.click('u48', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u27'] = 'top';document.getElementById('u52_img').tabIndex = 0;
HookHover('u52', false);

u52.style.cursor = 'pointer';
$axure.eventManager.click('u52', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u120'] = 'top';u152.tabIndex = 0;

u152.style.cursor = 'pointer';
$axure.eventManager.click('u152', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waitu07a5a95b79844b539d4b7c812cbf52b51() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waitu07a5a95b79844b539d4b7c812cbf52b51, 300);

}
});
gv_vAlignTable['u152'] = 'top';u6.tabIndex = 0;

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u205'] = 'top';document.getElementById('u62_img').tabIndex = 0;
HookHover('u62', false);

u62.style.cursor = 'pointer';
$axure.eventManager.click('u62', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
u11.tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u75'] = 'center';gv_vAlignTable['u133'] = 'center';document.getElementById('u68_img').tabIndex = 0;
HookHover('u68', false);

u68.style.cursor = 'pointer';
$axure.eventManager.click('u68', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
u208.tabIndex = 0;

u208.style.cursor = 'pointer';
$axure.eventManager.click('u208', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waitu2552992396c24e569ab678e6c9e5e01d1() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waitu2552992396c24e569ab678e6c9e5e01d1, 300);

}
});
gv_vAlignTable['u208'] = 'top';gv_vAlignTable['u47'] = 'center';u184.tabIndex = 0;

u184.style.cursor = 'pointer';
$axure.eventManager.click('u184', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waitu0efbe87ef4ae4cfab86dd53bc9ec53a51() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waitu0efbe87ef4ae4cfab86dd53bc9ec53a51, 300);

}
});
gv_vAlignTable['u184'] = 'top';document.getElementById('u72_img').tabIndex = 0;
HookHover('u72', false);

u72.style.cursor = 'pointer';
$axure.eventManager.click('u72', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u103'] = 'top';gv_vAlignTable['u99'] = 'center';document.getElementById('u66_img').tabIndex = 0;
HookHover('u66', false);

u66.style.cursor = 'pointer';
$axure.eventManager.click('u66', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u112'] = 'center';document.getElementById('u44_img').tabIndex = 0;
HookHover('u44', false);

u44.style.cursor = 'pointer';
$axure.eventManager.click('u44', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u119'] = 'top';u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u16'] = 'top';u125.tabIndex = 0;

u125.style.cursor = 'pointer';
$axure.eventManager.click('u125', function(e) {

if (true) {

	SetPanelVisibility('u97','hidden','none',500);

}
});

$axure.eventManager.mouseover('u125', function(e) {
if (!IsTrueMouseOver('u125',e)) return;
if (true) {

	SetPanelVisibility('u113','','none',500);

}
});

$axure.eventManager.mouseout('u125', function(e) {
if (!IsTrueMouseOut('u125',e)) return;
if (true) {

	SetPanelVisibility('u113','hidden','none',500);

}
});
gv_vAlignTable['u41'] = 'center';u172.tabIndex = 0;

u172.style.cursor = 'pointer';
$axure.eventManager.click('u172', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waitu7565e7a925d240b68afc01d845f762261() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waitu7565e7a925d240b68afc01d845f762261, 300);

}
});
gv_vAlignTable['u172'] = 'top';u149.tabIndex = 0;

u149.style.cursor = 'pointer';
$axure.eventManager.click('u149', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waitu540fd18d47044240bc179bf15cc08ee01() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waitu540fd18d47044240bc179bf15cc08ee01, 300);

}
});
gv_vAlignTable['u149'] = 'top';document.getElementById('u54_img').tabIndex = 0;
HookHover('u54', false);

u54.style.cursor = 'pointer';
$axure.eventManager.click('u54', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u118'] = 'center';gv_vAlignTable['u88'] = 'center';u189.tabIndex = 0;

u189.style.cursor = 'pointer';
$axure.eventManager.click('u189', function(e) {

if (true) {

	SetPanelState('u179', 'pd0u179','none','',500,'none','',500);

	MoveWidgetBy('u196', GetNum('0'), GetNum('-119'),'none',500);

}
});
gv_vAlignTable['u189'] = 'top';u174.tabIndex = 0;

u174.style.cursor = 'pointer';
$axure.eventManager.click('u174', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waitub6251bdc8f5b4aeead9862a2e632c5a41() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waitub6251bdc8f5b4aeead9862a2e632c5a41, 300);

}
});
gv_vAlignTable['u174'] = 'top';u128.tabIndex = 0;

u128.style.cursor = 'pointer';
$axure.eventManager.click('u128', function(e) {

if (true) {

	self.location.href='index.html';

}
});
gv_vAlignTable['u128'] = 'top';document.getElementById('u85_img').tabIndex = 0;

u85.style.cursor = 'pointer';
$axure.eventManager.click('u85', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}

if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('OnLoadVariable')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u51'] = 'center';u182.tabIndex = 0;

u182.style.cursor = 'pointer';
$axure.eventManager.click('u182', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waitud3c0a906e6e04bd0bd094d39fb3c44851() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waitud3c0a906e6e04bd0bd094d39fb3c44851, 300);

}
});
gv_vAlignTable['u182'] = 'top';u10.tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u10'] = 'top';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u36'] = 'center';u30.tabIndex = 0;

u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if (true) {

	self.location.href='http://www.lucabenazzi.eu';

}
});
gv_vAlignTable['u219'] = 'center';document.getElementById('u95_img').tabIndex = 0;

u95.style.cursor = 'pointer';
$axure.eventManager.click('u95', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u127'));

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Search_results.html');

}
});
gv_vAlignTable['u61'] = 'center';u195.tabIndex = 0;

u195.style.cursor = 'pointer';
$axure.eventManager.click('u195', function(e) {

if (true) {

	SetPanelState('u179', 'pd1u179','none','',500,'none','',500);

	MoveWidgetBy('u196', GetNum('0'), GetNum('119'),'none',500);

}
});
gv_vAlignTable['u195'] = 'top';u158.tabIndex = 0;

u158.style.cursor = 'pointer';
$axure.eventManager.click('u158', function(e) {

if (true) {

	SetPanelState('u141', 'pd0u141','none','',500,'none','',500);

	MoveWidgetBy('u179', GetNum('0'), GetNum('-162'),'none',500);

	MoveWidgetBy('u196', GetNum('0'), GetNum('-162'),'none',500);

	MoveWidgetBy('u162', GetNum('0'), GetNum('-162'),'none',500);

}
});
gv_vAlignTable['u158'] = 'top';document.getElementById('u74_img').tabIndex = 0;
HookHover('u74', false);

u74.style.cursor = 'pointer';
$axure.eventManager.click('u74', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u223'] = 'top';gv_vAlignTable['u33'] = 'center';u221.tabIndex = 0;

u221.style.cursor = 'pointer';
$axure.eventManager.click('u221', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u221'] = 'top';gv_vAlignTable['u92'] = 'center';document.getElementById('u46_img').tabIndex = 0;
HookHover('u46', false);

u46.style.cursor = 'pointer';
$axure.eventManager.click('u46', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
u126.tabIndex = 0;

u126.style.cursor = 'pointer';
$axure.eventManager.click('u126', function(e) {

if (true) {

	SetPanelVisibility('u97','hidden','none',500);

}
});

$axure.eventManager.mouseover('u126', function(e) {
if (!IsTrueMouseOver('u126',e)) return;
if (true) {

	SetPanelVisibility('u116','','none',500);

}
});

$axure.eventManager.mouseout('u126', function(e) {
if (!IsTrueMouseOut('u126',e)) return;
if (true) {

	SetPanelVisibility('u116','hidden','none',500);

}
});
gv_vAlignTable['u71'] = 'center';u181.tabIndex = 0;

u181.style.cursor = 'pointer';
$axure.eventManager.click('u181', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waitu183dc804c6034ca69a48d5110ff035a11() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waitu183dc804c6034ca69a48d5110ff035a11, 300);

}
});
gv_vAlignTable['u181'] = 'top';gv_vAlignTable['u5'] = 'center';gv_vAlignTable['u214'] = 'top';
$axure.eventManager.keyup('u127', function(e) {

if ((GetWidgetText('u127')) == ('')) {

	SetPanelVisibility('u97','hidden','none',500);

}
else
if (true) {

	SetPanelState('u97', 'pd0u97','none','',500,'none','',500);

SetGlobalVariableValue('IncrementalSearchVar', GetWidgetText('u127'));

SetWidgetRichText('u119', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dada</span></p>');

SetWidgetRichText('u120', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dat</span></p>');

SetWidgetRichText('u121', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">gi</span></p>');

SetWidgetRichText('u123', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

SetWidgetRichText('u103', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

	SetPanelVisibility('u97','','none',500);

	BringToFront("u97");
function waitu796b5745765043a58e9fe38835b455f51() {

	SetPanelState('u97', 'pd1u97','none','',500,'none','',500);
}
setTimeout(waitu796b5745765043a58e9fe38835b455f51, 2000);

}
});

$axure.eventManager.blur('u127', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u127'));

}
});
gv_vAlignTable['u43'] = 'center';document.getElementById('u56_img').tabIndex = 0;
HookHover('u56', false);

u56.style.cursor = 'pointer';
$axure.eventManager.click('u56', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
u150.tabIndex = 0;

u150.style.cursor = 'pointer';
$axure.eventManager.click('u150', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waitu9a5ddfeb42b548aaa530d3f9af55989a1() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waitu9a5ddfeb42b548aaa530d3f9af55989a1, 300);

}
});
gv_vAlignTable['u150'] = 'top';gv_vAlignTable['u106'] = 'center';u154.tabIndex = 0;

u154.style.cursor = 'pointer';
$axure.eventManager.click('u154', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waituc2aeb132ec1e4aca94cafeed149141651() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waituc2aeb132ec1e4aca94cafeed149141651, 300);

}
});
gv_vAlignTable['u154'] = 'top';document.getElementById('u40_img').tabIndex = 0;
HookHover('u40', false);

u40.style.cursor = 'pointer';
$axure.eventManager.click('u40', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u139'] = 'top';gv_vAlignTable['u53'] = 'center';u193.tabIndex = 0;

u193.style.cursor = 'pointer';
$axure.eventManager.click('u193', function(e) {

if (true) {

	SetPanelState('u179', 'pd0u179','none','',500,'none','',500);

}
});
gv_vAlignTable['u193'] = 'top';u104.tabIndex = 0;

u104.style.cursor = 'pointer';
$axure.eventManager.click('u104', function(e) {

if (true) {

	SetPanelVisibility('u97','hidden','none',500);

}
});

$axure.eventManager.mouseover('u104', function(e) {
if (!IsTrueMouseOver('u104',e)) return;
if (true) {

	SetPanelVisibility('u100','','none',500);

}
});

$axure.eventManager.mouseout('u104', function(e) {
if (!IsTrueMouseOut('u104',e)) return;
if (true) {

	SetPanelVisibility('u100','hidden','none',500);

}
});
gv_vAlignTable['u192'] = 'top';gv_vAlignTable['u121'] = 'top';u211.tabIndex = 0;

u211.style.cursor = 'pointer';
$axure.eventManager.click('u211', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waitu0198860c182c4c8ab4bfbbd7a34e00cd1() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waitu0198860c182c4c8ab4bfbbd7a34e00cd1, 300);

}
});
gv_vAlignTable['u211'] = 'top';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u19'] = 'top';u155.tabIndex = 0;

u155.style.cursor = 'pointer';
$axure.eventManager.click('u155', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waitu34cef855c41e4492a06eb49cf7b6b6c91() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waitu34cef855c41e4492a06eb49cf7b6b6c91, 300);

}
});
gv_vAlignTable['u155'] = 'top';u206.tabIndex = 0;

u206.style.cursor = 'pointer';
$axure.eventManager.click('u206', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waitu821e7136c4474450995860bab7b186511() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waitu821e7136c4474450995860bab7b186511, 300);

}
});
gv_vAlignTable['u206'] = 'top';gv_vAlignTable['u109'] = 'center';gv_vAlignTable['u84'] = 'center';HookHover('u50', false);
gv_vAlignTable['u123'] = 'top';gv_vAlignTable['u170'] = 'top';HookHover('u134', false);
u177.tabIndex = 0;

u177.style.cursor = 'pointer';
$axure.eventManager.click('u177', function(e) {

if (true) {

	SetPanelState('u162', 'pd1u162','none','',500,'none','',500);

	MoveWidgetBy('u179', GetNum('0'), GetNum('119'),'none',500);

	MoveWidgetBy('u196', GetNum('0'), GetNum('119'),'none',500);

}
});
gv_vAlignTable['u177'] = 'top';u209.tabIndex = 0;

u209.style.cursor = 'pointer';
$axure.eventManager.click('u209', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waituc1b46c8f55ea4d229db5b272d29d023d1() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waituc1b46c8f55ea4d229db5b272d29d023d1, 300);

}
});
gv_vAlignTable['u209'] = 'top';gv_vAlignTable['u94'] = 'top';document.getElementById('u60_img').tabIndex = 0;
HookHover('u60', false);

u60.style.cursor = 'pointer';
$axure.eventManager.click('u60', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u102'] = 'center';u9.tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u73'] = 'center';gv_vAlignTable['u69'] = 'center';u131.tabIndex = 0;

u131.style.cursor = 'pointer';
$axure.eventManager.click('u131', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');

SetGlobalVariableValue('BookPageViewed', '');

SetGlobalVariableValue('CitySelected', '');

SetGlobalVariableValue('LoginStatus', '');

SetGlobalVariableValue('ReviewVar', '');

SetGlobalVariableValue('EmployeesName', '');

	SetPanelState('u129', 'pd1u129','none','',500,'none','',500);
function waituf022ddcb6b474903a282219d39d908ef1() {

	SetPanelState('u129', 'pd0u129','none','',500,'none','',500);
}
setTimeout(waituf022ddcb6b474903a282219d39d908ef1, 4000);

}
});
gv_vAlignTable['u131'] = 'top';document.getElementById('u64_img').tabIndex = 0;
HookHover('u64', false);

u64.style.cursor = 'pointer';
$axure.eventManager.click('u64', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
document.getElementById('u70_img').tabIndex = 0;
HookHover('u70', false);

u70.style.cursor = 'pointer';
$axure.eventManager.click('u70', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u24'] = 'top';u213.tabIndex = 0;

u213.style.cursor = 'pointer';
$axure.eventManager.click('u213', function(e) {

if (true) {

	SetPanelState('u196', 'pd1u196','none','',500,'none','',500);

}
});
gv_vAlignTable['u213'] = 'top';u210.tabIndex = 0;

u210.style.cursor = 'pointer';
$axure.eventManager.click('u210', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waitu06b99b8449ea474a98828ff0b0393d691() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waitu06b99b8449ea474a98828ff0b0393d691, 300);

}
});
gv_vAlignTable['u210'] = 'top';u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u29'] = 'top';document.getElementById('u132_img').tabIndex = 0;

u132.style.cursor = 'pointer';
$axure.eventManager.click('u132', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
u175.tabIndex = 0;

u175.style.cursor = 'pointer';
$axure.eventManager.click('u175', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waitu318b4f696a0746c2b311a45569ddbb2e1() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waitu318b4f696a0746c2b311a45569ddbb2e1, 300);

}
});
gv_vAlignTable['u175'] = 'top';gv_vAlignTable['u86'] = 'center';document.getElementById('u58_img').tabIndex = 0;
HookHover('u58', false);

u58.style.cursor = 'pointer';
$axure.eventManager.click('u58', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
u183.tabIndex = 0;

u183.style.cursor = 'pointer';
$axure.eventManager.click('u183', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waituf8fcfc7a42214466b0cba1056c8e3dc11() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waituf8fcfc7a42214466b0cba1056c8e3dc11, 300);

}
});
gv_vAlignTable['u183'] = 'top';u173.tabIndex = 0;

u173.style.cursor = 'pointer';
$axure.eventManager.click('u173', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waitu5e9c34df5c584dbfbf722f795dc8d0fc1() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waitu5e9c34df5c584dbfbf722f795dc8d0fc1, 300);

}
});
gv_vAlignTable['u173'] = 'top';gv_vAlignTable['u39'] = 'center';u171.tabIndex = 0;

u171.style.cursor = 'pointer';
$axure.eventManager.click('u171', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waitu23dcedcd6c544a769f6eb9fed6a406f71() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waitu23dcedcd6c544a769f6eb9fed6a406f71, 300);

}
});
gv_vAlignTable['u171'] = 'top';gv_vAlignTable['u0'] = 'top';gv_vAlignTable['u63'] = 'center';document.getElementById('u83_img').tabIndex = 0;

u83.style.cursor = 'pointer';
$axure.eventManager.click('u83', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}
});
gv_vAlignTable['u178'] = 'top';u8.tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u8'] = 'top';u3.tabIndex = 0;

u3.style.cursor = 'pointer';
$axure.eventManager.click('u3', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u96'] = 'center';u146.tabIndex = 0;

u146.style.cursor = 'pointer';
$axure.eventManager.click('u146', function(e) {

if (true) {

	SetPanelState('u141', 'pd0u141','none','',500,'none','',500);

}
});
gv_vAlignTable['u146'] = 'top';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u49'] = 'center';u124.tabIndex = 0;

u124.style.cursor = 'pointer';
$axure.eventManager.click('u124', function(e) {

if (true) {

	SetPanelVisibility('u97','hidden','none',500);

}
});

$axure.eventManager.mouseover('u124', function(e) {
if (!IsTrueMouseOver('u124',e)) return;
if (true) {

	SetPanelVisibility('u110','','none',500);

}
});

$axure.eventManager.mouseout('u124', function(e) {
if (!IsTrueMouseOut('u124',e)) return;
if (true) {

	SetPanelVisibility('u110','hidden','none',500);

}
});
gv_vAlignTable['u80'] = 'center';gv_vAlignTable['u93'] = 'top';u167.tabIndex = 0;

u167.style.cursor = 'pointer';
$axure.eventManager.click('u167', function(e) {

if (true) {

	SetPanelState('u162', 'pd0u162','none','',500,'none','',500);

	MoveWidgetBy('u179', GetNum('0'), GetNum('-119'),'none',500);

	MoveWidgetBy('u196', GetNum('0'), GetNum('-119'),'none',500);

}
});
gv_vAlignTable['u167'] = 'top';u12.tabIndex = 0;

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u12'] = 'top';u201.tabIndex = 0;

u201.style.cursor = 'pointer';
$axure.eventManager.click('u201', function(e) {

if (true) {

	SetPanelState('u196', 'pd0u196','none','',500,'none','',500);

}
});
gv_vAlignTable['u201'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u59'] = 'center';u137.tabIndex = 0;

u137.style.cursor = 'pointer';
$axure.eventManager.click('u137', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('My_details.html');

}
else
if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('LoginStatus')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u137'] = 'top';gv_vAlignTable['u90'] = 'center';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u18'] = 'top';u161.tabIndex = 0;

u161.style.cursor = 'pointer';
$axure.eventManager.click('u161', function(e) {

if (true) {

	SetPanelState('u141', 'pd1u141','none','',500,'none','',500);

	MoveWidgetBy('u179', GetNum('0'), GetNum('162'),'none',500);

	MoveWidgetBy('u196', GetNum('0'), GetNum('162'),'none',500);

	MoveWidgetBy('u162', GetNum('0'), GetNum('162'),'none',500);

}
});
gv_vAlignTable['u161'] = 'top';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u77'] = 'center';u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u220'] = 'top';u136.tabIndex = 0;

u136.style.cursor = 'pointer';
$axure.eventManager.click('u136', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
u180.tabIndex = 0;

u180.style.cursor = 'pointer';
$axure.eventManager.click('u180', function(e) {

if (true) {

	BringToFront("u217");

	SetPanelVisibility('u217','','none',500);
function waitu4dc71919636d43bb8d7b2ea150f7e23d1() {

	SetPanelVisibility('u217','hidden','none',500);

    objIframe = document.getElementById("u216");
    var reload = FrameWindowNeedsReload(objIframe, $axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    if (!reload) {
	    objIframe.src=$axure.globalVariableProvider.getLinkUrl('CategoryList.html');
    } else {
        objIframe.src="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl('CategoryList.html'));
    }
}
setTimeout(waitu4dc71919636d43bb8d7b2ea150f7e23d1, 300);

}
});
gv_vAlignTable['u180'] = 'top';gv_vAlignTable['u28'] = 'top';