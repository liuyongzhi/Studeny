﻿for(var i = 0; i < 222; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

SetWidgetSelected('u103');
}

if ((GetGlobalVariableValue('ShoppingBasket')) == ('Empty')) {

	SetPanelState('u117', 'pd0u117','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('1'))) {

SetWidgetRichText('u119', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (1 item)</span></p>');

	SetPanelState('u117', 'pd1u117','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('2'))) {

SetWidgetRichText('u119', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (2 items)</span></p>');

	SetPanelState('u117', 'pd1u117','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('3'))) {

SetWidgetRichText('u119', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (3 items)</span></p>');

	SetPanelState('u117', 'pd1u117','none','',500,'none','',500);

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) {

}

});

function rdo1LoadHome(e) {

}
gv_vAlignTable['u115'] = 'center';u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u137'] = 'center';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u156'] = 'top';u207.tabIndex = 0;

u207.style.cursor = 'pointer';
$axure.eventManager.click('u207', function(e) {

if (true) {

	SetPanelVisibility('u177','hidden','none',500);

	SetPanelVisibility('u194','hidden','none',500);

	SetPanelState('u177', 'pd0u177','none','',500,'none','',500);

	SetPanelState('u42', 'pd0u42','none','',500,'none','',500);

}
});
gv_vAlignTable['u207'] = 'top';document.getElementById('u130_img').tabIndex = 0;

u130.style.cursor = 'pointer';
$axure.eventManager.click('u130', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u162'));

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Search_results.html');

}
});
u7.tabIndex = 0;

u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u7'] = 'top';u45.tabIndex = 0;

u45.style.cursor = 'pointer';
$axure.eventManager.click('u45', function(e) {

if (true) {

	SetPanelState('u42', 'pd4u42','none','',500,'none','',500);

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd3u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitu954af60d853a4a0d9fdfd63b1a4212c71() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitu015c5148c43f4d4ca4fb6180c949a88c1() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitu3d95514f37cd49dfa9205d7f37fa31a51() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waituee0c049b11604b2da13493b650093fe51() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitub6f85bb26772443d90322edb20f2f6131() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd3u181','none','',500,'none','',500);
}
setTimeout(waitub6f85bb26772443d90322edb20f2f6131, 10);
}
setTimeout(waituee0c049b11604b2da13493b650093fe51, 10);
}
setTimeout(waitu3d95514f37cd49dfa9205d7f37fa31a51, 10);
}
setTimeout(waitu015c5148c43f4d4ca4fb6180c949a88c1, 10);
}
setTimeout(waitu954af60d853a4a0d9fdfd63b1a4212c71, 10);

}
});
gv_vAlignTable['u45'] = 'top';document.getElementById('u79_img').tabIndex = 0;
HookHover('u79', false);

u79.style.cursor = 'pointer';
$axure.eventManager.click('u79', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u153'] = 'center';u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
gv_vAlignTable['u17'] = 'top';u159.tabIndex = 0;

u159.style.cursor = 'pointer';
$axure.eventManager.click('u159', function(e) {

if (true) {

	SetPanelVisibility('u132','hidden','none',500);

}
});

$axure.eventManager.mouseover('u159', function(e) {
if (!IsTrueMouseOver('u159',e)) return;
if (true) {

	SetPanelVisibility('u145','','none',500);

}
});

$axure.eventManager.mouseout('u159', function(e) {
if (!IsTrueMouseOut('u159',e)) return;
if (true) {

	SetPanelVisibility('u145','hidden','none',500);

}
});
u55.tabIndex = 0;

u55.style.cursor = 'pointer';
$axure.eventManager.click('u55', function(e) {

if (true) {

	SetPanelState('u42', 'pd2u42','none','',500,'none','',500);

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd1u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitu3f6e7bfda8e546deb67352b565eed9681() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitub1e082c67ab74fc393e537066bc0d41a1() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitu3e3a9bd8ad1e4f7fb2b38cfd5fa57fd21() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitu6d37a5303c274bb1b7a1f745c6da5da81() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitu9b6dc164bf604526bab6eac8e32d9b481() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd1u181','none','',500,'none','',500);
}
setTimeout(waitu9b6dc164bf604526bab6eac8e32d9b481, 10);
}
setTimeout(waitu6d37a5303c274bb1b7a1f745c6da5da81, 10);
}
setTimeout(waitu3e3a9bd8ad1e4f7fb2b38cfd5fa57fd21, 10);
}
setTimeout(waitub1e082c67ab74fc393e537066bc0d41a1, 10);
}
setTimeout(waitu3f6e7bfda8e546deb67352b565eed9681, 10);

}
});
gv_vAlignTable['u55'] = 'top';document.getElementById('u101_img').tabIndex = 0;
HookHover('u101', false);

u101.style.cursor = 'pointer';
$axure.eventManager.click('u101', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
u14.tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u5'] = 'top';document.getElementById('u105_img').tabIndex = 0;
HookHover('u105', false);

u105.style.cursor = 'pointer';
$axure.eventManager.click('u105', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
u27.tabIndex = 0;

u27.style.cursor = 'pointer';
$axure.eventManager.click('u27', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u102'] = 'center';gv_vAlignTable['u2'] = 'top';u52.tabIndex = 0;

u52.style.cursor = 'pointer';
$axure.eventManager.click('u52', function(e) {

if (true) {

	SetPanelState('u42', 'pd1u42','none','',500,'none','',500);

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd0u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitu5498d3ad79f449f7b13fa41128165bce1() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitu8be82378e42d4d29abe6d810a017ba181() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitud7d08f10c7ba40a0a39c2bc3ae43817b1() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waituc19415090e054152a2b9d25ad16611261() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitu987ae78507b24feca3d6e245664d3f9c1() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd0u181','none','',500,'none','',500);
}
setTimeout(waitu987ae78507b24feca3d6e245664d3f9c1, 10);
}
setTimeout(waituc19415090e054152a2b9d25ad16611261, 10);
}
setTimeout(waitud7d08f10c7ba40a0a39c2bc3ae43817b1, 10);
}
setTimeout(waitu8be82378e42d4d29abe6d810a017ba181, 10);
}
setTimeout(waitu5498d3ad79f449f7b13fa41128165bce1, 10);

}
});
gv_vAlignTable['u52'] = 'top';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u20'] = 'top';u67.tabIndex = 0;

u67.style.cursor = 'pointer';
$axure.eventManager.click('u67', function(e) {

if (true) {

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	SetPanelState('u42', 'pd2u42','none','',500,'none','',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd1u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitue47698b563db4965a0511bb6cd449a281() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waituae3d8c880ed9483b9258d42dfa34ea2b1() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitu1858a3342dd44aa08012a57ee3f2ac5b1() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitu375045eca9e3495db40c2e5f994f90fc1() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waituc14c7499e1a9494299140b924f0f2e591() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd1u181','none','',500,'none','',500);
}
setTimeout(waituc14c7499e1a9494299140b924f0f2e591, 10);
}
setTimeout(waitu375045eca9e3495db40c2e5f994f90fc1, 10);
}
setTimeout(waitu1858a3342dd44aa08012a57ee3f2ac5b1, 10);
}
setTimeout(waituae3d8c880ed9483b9258d42dfa34ea2b1, 10);
}
setTimeout(waitue47698b563db4965a0511bb6cd449a281, 10);

}
});
gv_vAlignTable['u67'] = 'top';document.getElementById('u120_img').tabIndex = 0;

u120.style.cursor = 'pointer';
$axure.eventManager.click('u120', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}

if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('OnLoadVariable')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u110'] = 'center';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u108'] = 'center';gv_vAlignTable['u37'] = 'center';u62.tabIndex = 0;

u62.style.cursor = 'pointer';
$axure.eventManager.click('u62', function(e) {

if (true) {

	SetPanelState('u42', 'pd3u42','none','',500,'none','',500);

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd2u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitu14657c5ffef9428e8237145fd2b277321() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitu14e20aa31fc049e8b271ac73877095031() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitu5741d00b8d9344e9ae55a42d36c1c9f11() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitu172d032b6e704fe5a07ed7df29a77ec41() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waituf83e899254af4bf59c48bbfa4a13e5fd1() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd2u181','none','',500,'none','',500);
}
setTimeout(waituf83e899254af4bf59c48bbfa4a13e5fd1, 10);
}
setTimeout(waitu172d032b6e704fe5a07ed7df29a77ec41, 10);
}
setTimeout(waitu5741d00b8d9344e9ae55a42d36c1c9f11, 10);
}
setTimeout(waitu14e20aa31fc049e8b271ac73877095031, 10);
}
setTimeout(waitu14657c5ffef9428e8237145fd2b277321, 10);

}
});
gv_vAlignTable['u62'] = 'top';u11.tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u11'] = 'top';document.getElementById('u75_img').tabIndex = 0;
HookHover('u75', false);

u75.style.cursor = 'pointer';
$axure.eventManager.click('u75', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u200'] = 'center';u34.tabIndex = 0;

u34.style.cursor = 'pointer';
$axure.eventManager.click('u34', function(e) {

if (true) {

	self.location.href='http://www.lucabenazzi.eu';

}
});
u68.tabIndex = 0;

u68.style.cursor = 'pointer';
$axure.eventManager.click('u68', function(e) {

if (true) {

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	SetPanelState('u42', 'pd3u42','none','',500,'none','',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd2u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitufa44687dd11249b4bd025d1f611a0e581() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitu094ce85c5a634514aa1fa02c673b02951() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitu65a812e10cbf4d8eaedcb8cc218a0d721() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitu8574b32da6ab4703b79e04e69712464a1() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitua95457e6c1724415b5ca87a7b48979c61() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd2u181','none','',500,'none','',500);
}
setTimeout(waitua95457e6c1724415b5ca87a7b48979c61, 10);
}
setTimeout(waitu8574b32da6ab4703b79e04e69712464a1, 10);
}
setTimeout(waitu65a812e10cbf4d8eaedcb8cc218a0d721, 10);
}
setTimeout(waitu094ce85c5a634514aa1fa02c673b02951, 10);
}
setTimeout(waitufa44687dd11249b4bd025d1f611a0e581, 10);

}
});
gv_vAlignTable['u68'] = 'top';document.getElementById('u89_img').tabIndex = 0;
HookHover('u89', false);

u89.style.cursor = 'pointer';
$axure.eventManager.click('u89', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
u208.tabIndex = 0;

u208.style.cursor = 'pointer';
$axure.eventManager.click('u208', function(e) {

if (true) {

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	SetPanelState('u42', 'pd4u42','none','',500,'none','',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd3u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitu8b50e11a7e3b43bab334b55845209c741() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waituce9ee692adc74b5fb503876e673f7d4f1() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waituca791e723f0c49b6bc39c0e0db9638801() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitub105766daaf244219b4c7a61684b736c1() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitu70c8c50f4ec1467aaad895195c0fb9241() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd3u181','none','',500,'none','',500);
}
setTimeout(waitu70c8c50f4ec1467aaad895195c0fb9241, 10);
}
setTimeout(waitub105766daaf244219b4c7a61684b736c1, 10);
}
setTimeout(waituca791e723f0c49b6bc39c0e0db9638801, 10);
}
setTimeout(waituce9ee692adc74b5fb503876e673f7d4f1, 10);
}
setTimeout(waitu8b50e11a7e3b43bab334b55845209c741, 10);

}
});
gv_vAlignTable['u208'] = 'top';gv_vAlignTable['u184'] = 'center';gv_vAlignTable['u72'] = 'center';document.getElementById('u103_img').tabIndex = 0;
HookHover('u103', false);

u103.style.cursor = 'pointer';
$axure.eventManager.click('u103', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
document.getElementById('u99_img').tabIndex = 0;
HookHover('u99', false);

u99.style.cursor = 'pointer';
$axure.eventManager.click('u99', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u112'] = 'center';u44.tabIndex = 0;

u44.style.cursor = 'pointer';
$axure.eventManager.click('u44', function(e) {

if (true) {

	SetPanelState('u42', 'pd3u42','none','',500,'none','',500);

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd2u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitub27f63235bc748aabf9f1fa092aa72de1() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitu84e1fa1e084646599b8c26b63db5eb3d1() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitua502542230b643fcb02623a47249b5401() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitu8edbe15d3caa4f19a78e81c1848821271() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitu4318af6d4c0d4b6cb41facc3f73c85fe1() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd2u181','none','',500,'none','',500);
}
setTimeout(waitu4318af6d4c0d4b6cb41facc3f73c85fe1, 10);
}
setTimeout(waitu8edbe15d3caa4f19a78e81c1848821271, 10);
}
setTimeout(waitua502542230b643fcb02623a47249b5401, 10);
}
setTimeout(waitu84e1fa1e084646599b8c26b63db5eb3d1, 10);
}
setTimeout(waitub27f63235bc748aabf9f1fa092aa72de1, 10);

}
});
gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u179'] = 'center';u57.tabIndex = 0;

u57.style.cursor = 'pointer';
$axure.eventManager.click('u57', function(e) {

if (true) {

	SetPanelState('u42', 'pd4u42','none','',500,'none','',500);

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd3u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitue05c77cc015c4eb3ae96d89f0f08362b1() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitubf40ec8614f246e3b2b4454b33d7fb5e1() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitu94fcce226cee4317b8f7803ee7064a6d1() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitu17db1b423a014399b981e46a663598e71() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitubc615fa1100e4da9b0da94c36bb927781() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd3u181','none','',500,'none','',500);
}
setTimeout(waitubc615fa1100e4da9b0da94c36bb927781, 10);
}
setTimeout(waitu17db1b423a014399b981e46a663598e71, 10);
}
setTimeout(waitu94fcce226cee4317b8f7803ee7064a6d1, 10);
}
setTimeout(waitubf40ec8614f246e3b2b4454b33d7fb5e1, 10);
}
setTimeout(waitue05c77cc015c4eb3ae96d89f0f08362b1, 10);

}
});
gv_vAlignTable['u57'] = 'top';u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u212'] = 'center';gv_vAlignTable['u125'] = 'center';u172.tabIndex = 0;

u172.style.cursor = 'pointer';
$axure.eventManager.click('u172', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('My_details.html');

}
else
if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('LoginStatus')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u172'] = 'top';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u88'] = 'center';u176.tabIndex = 0;

u176.style.cursor = 'pointer';
$axure.eventManager.click('u176', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u176'] = 'top';u26.tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u174'] = 'top';gv_vAlignTable['u128'] = 'top';HookHover('u85', false);
u51.tabIndex = 0;

u51.style.cursor = 'pointer';
$axure.eventManager.click('u51', function(e) {

if (true) {

	SetPanelState('u42', 'pd4u42','none','',500,'none','',500);

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd3u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitub9f12925aeb044f29fd36de29424e77c1() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitua7c324958b134126b15ddb56efe9d3b61() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitua964d7976b8f4f12b72c4bd1fd112fc01() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitu804a8b0673cc4102b749cd77ba763adc1() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitu1c51f22579d04df289f243fe0fa7bbc21() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd3u181','none','',500,'none','',500);
}
setTimeout(waitu1c51f22579d04df289f243fe0fa7bbc21, 10);
}
setTimeout(waitu804a8b0673cc4102b749cd77ba763adc1, 10);
}
setTimeout(waitua964d7976b8f4f12b72c4bd1fd112fc01, 10);
}
setTimeout(waitua7c324958b134126b15ddb56efe9d3b61, 10);
}
setTimeout(waitub9f12925aeb044f29fd36de29424e77c1, 10);

}
});
gv_vAlignTable['u51'] = 'top';u10.tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u204'] = 'top';gv_vAlignTable['u144'] = 'center';gv_vAlignTable['u31'] = 'top';u166.tabIndex = 0;

u166.style.cursor = 'pointer';
$axure.eventManager.click('u166', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');

SetGlobalVariableValue('BookPageViewed', '');

SetGlobalVariableValue('CitySelected', '');

SetGlobalVariableValue('LoginStatus', '');

SetGlobalVariableValue('ReviewVar', '');

SetGlobalVariableValue('EmployeesName', '');

	SetPanelState('u164', 'pd1u164','none','',500,'none','',500);
function waituf022ddcb6b474903a282219d39d908ef1() {

	SetPanelState('u164', 'pd0u164','none','',500,'none','',500);
}
setTimeout(waituf022ddcb6b474903a282219d39d908ef1, 4000);

}
});
gv_vAlignTable['u166'] = 'top';gv_vAlignTable['u82'] = 'center';document.getElementById('u36_img').tabIndex = 0;

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
u219.tabIndex = 0;

u219.style.cursor = 'pointer';
$axure.eventManager.click('u219', function(e) {

if (true) {

	SetPanelVisibility('u177','hidden','none',500);

	SetPanelVisibility('u194','hidden','none',500);

	SetPanelState('u177', 'pd0u177','none','',500,'none','',500);

	SetPanelState('u42', 'pd0u42','none','',500,'none','',500);

}
});
gv_vAlignTable['u219'] = 'top';document.getElementById('u95_img').tabIndex = 0;
HookHover('u95', false);

u95.style.cursor = 'pointer';
$axure.eventManager.click('u95', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
u61.tabIndex = 0;

u61.style.cursor = 'pointer';
$axure.eventManager.click('u61', function(e) {

if (true) {

	SetPanelState('u42', 'pd2u42','none','',500,'none','',500);

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd1u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitud901b4e20d8d4f3f9f6f2bef523dc6d01() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waituda1232ac27b8452aa5476a27630aa6991() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waituc3188e46bd1a4754808bd75a038eaaf61() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitu131a05e91fa1486a8b09a2f0d47442401() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitu1b8d411afbe3465896c03f309635b7901() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd1u181','none','',500,'none','',500);
}
setTimeout(waitu1b8d411afbe3465896c03f309635b7901, 10);
}
setTimeout(waitu131a05e91fa1486a8b09a2f0d47442401, 10);
}
setTimeout(waituc3188e46bd1a4754808bd75a038eaaf61, 10);
}
setTimeout(waituda1232ac27b8452aa5476a27630aa6991, 10);
}
setTimeout(waitud901b4e20d8d4f3f9f6f2bef523dc6d01, 10);

}
});
gv_vAlignTable['u61'] = 'top';gv_vAlignTable['u158'] = 'top';gv_vAlignTable['u74'] = 'top';gv_vAlignTable['u123'] = 'center';document.getElementById('u114_img').tabIndex = 0;

u114.style.cursor = 'pointer';
$axure.eventManager.click('u114', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u33'] = 'top';u160.tabIndex = 0;

u160.style.cursor = 'pointer';
$axure.eventManager.click('u160', function(e) {

if (true) {

	SetPanelVisibility('u132','hidden','none',500);

}
});

$axure.eventManager.mouseover('u160', function(e) {
if (!IsTrueMouseOver('u160',e)) return;
if (true) {

	SetPanelVisibility('u148','','none',500);

}
});

$axure.eventManager.mouseout('u160', function(e) {
if (!IsTrueMouseOut('u160',e)) return;
if (true) {

	SetPanelVisibility('u148','hidden','none',500);

}
});
u157.tabIndex = 0;

u157.style.cursor = 'pointer';
$axure.eventManager.click('u157', function(e) {

if (true) {

	SetPanelVisibility('u132','hidden','none',500);

}
});

$axure.eventManager.mouseover('u157', function(e) {
if (!IsTrueMouseOver('u157',e)) return;
if (true) {

	SetPanelVisibility('u142','','none',500);

}
});

$axure.eventManager.mouseout('u157', function(e) {
if (!IsTrueMouseOut('u157',e)) return;
if (true) {

	SetPanelVisibility('u142','hidden','none',500);

}
});
u221.tabIndex = 0;

u221.style.cursor = 'pointer';
$axure.eventManager.click('u221', function(e) {

if (true) {

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	SetPanelState('u42', 'pd4u42','none','',500,'none','',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd3u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitu6d41be3cb9c24bc3aaf4abdf793608251() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitu7393d66dbd42435e9bc33a71af99230a1() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitu11d6ff34864440938e987e0e3cbf146e1() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waituf26978e600d44342bf0ef9758c19db521() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitu00ea401c3a2f4ad0b9c2cf7014323d181() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd3u181','none','',500,'none','',500);
}
setTimeout(waitu00ea401c3a2f4ad0b9c2cf7014323d181, 10);
}
setTimeout(waituf26978e600d44342bf0ef9758c19db521, 10);
}
setTimeout(waitu11d6ff34864440938e987e0e3cbf146e1, 10);
}
setTimeout(waitu7393d66dbd42435e9bc33a71af99230a1, 10);
}
setTimeout(waitu6d41be3cb9c24bc3aaf4abdf793608251, 10);

}
});
gv_vAlignTable['u221'] = 'top';gv_vAlignTable['u92'] = 'center';u46.tabIndex = 0;

u46.style.cursor = 'pointer';
$axure.eventManager.click('u46', function(e) {

if (true) {

	SetPanelState('u42', 'pd1u42','none','',500,'none','',500);

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd0u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitu820221ab7d0245a685e1075d31a400691() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitu03755be1744d47c0bb881dbd75f7ff791() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitu1e4f6fad0bbc49208563180a1c5e3a3d1() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitu0db362eed79743df8f9fb5250a6eb73b1() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitu87bef2727a5148ef9446aa017a9755e91() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd0u181','none','',500,'none','',500);
}
setTimeout(waitu87bef2727a5148ef9446aa017a9755e91, 10);
}
setTimeout(waitu0db362eed79743df8f9fb5250a6eb73b1, 10);
}
setTimeout(waitu1e4f6fad0bbc49208563180a1c5e3a3d1, 10);
}
setTimeout(waitu03755be1744d47c0bb881dbd75f7ff791, 10);
}
setTimeout(waitu820221ab7d0245a685e1075d31a400691, 10);

}
});
gv_vAlignTable['u46'] = 'top';u202.tabIndex = 0;

u202.style.cursor = 'pointer';
$axure.eventManager.click('u202', function(e) {

if (true) {

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	SetPanelState('u42', 'pd1u42','none','',500,'none','',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd0u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitu0874707381834af18e59c5304e8f62121() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitua4517288a45b41d0a94d045f35e6e2b71() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitu61db49abe73b445c981ce127ffb91e371() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitu2cf4912162e543fa9242807cd9aded471() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitu9fd085948663411f9352e437a63ec05b1() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd0u181','none','',500,'none','',500);
}
setTimeout(waitu9fd085948663411f9352e437a63ec05b1, 10);
}
setTimeout(waitu2cf4912162e543fa9242807cd9aded471, 10);
}
setTimeout(waitu61db49abe73b445c981ce127ffb91e371, 10);
}
setTimeout(waitua4517288a45b41d0a94d045f35e6e2b71, 10);
}
setTimeout(waitu0874707381834af18e59c5304e8f62121, 10);

}
});
gv_vAlignTable['u202'] = 'top';gv_vAlignTable['u198'] = 'top';u203.tabIndex = 0;

u203.style.cursor = 'pointer';
$axure.eventManager.click('u203', function(e) {

if (true) {

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	SetPanelState('u42', 'pd3u42','none','',500,'none','',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd2u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitudfc6562307f844b381aa7e8ec02224a61() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitu50024273b1924c0aa732ede1f91ee73d1() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitu75d0c3e0b2e7404aaaf389012eb6e1cd1() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitue1fa4c50578349a688a3763f7e77f4161() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waituba7c1569cfb143ada0a51f93da88bdad1() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd2u181','none','',500,'none','',500);
}
setTimeout(waituba7c1569cfb143ada0a51f93da88bdad1, 10);
}
setTimeout(waitue1fa4c50578349a688a3763f7e77f4161, 10);
}
setTimeout(waitu75d0c3e0b2e7404aaaf389012eb6e1cd1, 10);
}
setTimeout(waitu50024273b1924c0aa732ede1f91ee73d1, 10);
}
setTimeout(waitudfc6562307f844b381aa7e8ec02224a61, 10);

}
});
gv_vAlignTable['u203'] = 'top';gv_vAlignTable['u98'] = 'center';u214.tabIndex = 0;

u214.style.cursor = 'pointer';
$axure.eventManager.click('u214', function(e) {

if (true) {

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	SetPanelState('u42', 'pd3u42','none','',500,'none','',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd2u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitu16c2c8c8f3b04575af52b6126e78439d1() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitu872d5d8b1c3441bea3dba14b3f46f1db1() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitud0e417c732cb4895815450343200a9121() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitud204cd58613c4d3baeb17f00030699141() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitu404ce64ffbf24b069a865bc07d67ca8a1() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd2u181','none','',500,'none','',500);
}
setTimeout(waitu404ce64ffbf24b069a865bc07d67ca8a1, 10);
}
setTimeout(waitud204cd58613c4d3baeb17f00030699141, 10);
}
setTimeout(waitud0e417c732cb4895815450343200a9121, 10);
}
setTimeout(waitu872d5d8b1c3441bea3dba14b3f46f1db1, 10);
}
setTimeout(waitu16c2c8c8f3b04575af52b6126e78439d1, 10);

}
});
gv_vAlignTable['u214'] = 'top';gv_vAlignTable['u127'] = 'center';u43.tabIndex = 0;

u43.style.cursor = 'pointer';
$axure.eventManager.click('u43', function(e) {

if (true) {

	SetPanelState('u42', 'pd2u42','none','',500,'none','',500);

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd1u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitu53fce418191244ffb04f9dc4bf77ee781() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitu320bcad78a754e6c9341ca76cd0dc8951() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitue829cc6f220c4179ac74b396f80d49861() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitu8ab9a4649efb43a999aed4c8f09d69fe1() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitu02c80a52aa4543958b7f4a4f0d720b551() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd1u181','none','',500,'none','',500);
}
setTimeout(waitu02c80a52aa4543958b7f4a4f0d720b551, 10);
}
setTimeout(waitu8ab9a4649efb43a999aed4c8f09d69fe1, 10);
}
setTimeout(waitue829cc6f220c4179ac74b396f80d49861, 10);
}
setTimeout(waitu320bcad78a754e6c9341ca76cd0dc8951, 10);
}
setTimeout(waitu53fce418191244ffb04f9dc4bf77ee781, 10);

}
});
gv_vAlignTable['u43'] = 'top';HookHover('u169', false);
u56.tabIndex = 0;

u56.style.cursor = 'pointer';
$axure.eventManager.click('u56', function(e) {

if (true) {

	SetPanelState('u42', 'pd3u42','none','',500,'none','',500);

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd2u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitub643c9e91c5146698e07fb618e01569b1() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitu4d0f79c74ed84b8e9238c15b3797e6a01() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitu028be8096bdf4dc482b338873075f1951() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitubf641b332b87497cac605ee2ba3398c41() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitu61c9bbd885d8413985fceab7af02164a1() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd2u181','none','',500,'none','',500);
}
setTimeout(waitu61c9bbd885d8413985fceab7af02164a1, 10);
}
setTimeout(waitubf641b332b87497cac605ee2ba3398c41, 10);
}
setTimeout(waitu028be8096bdf4dc482b338873075f1951, 10);
}
setTimeout(waitu4d0f79c74ed84b8e9238c15b3797e6a01, 10);
}
setTimeout(waitub643c9e91c5146698e07fb618e01569b1, 10);

}
});
gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u150'] = 'center';gv_vAlignTable['u187'] = 'center';gv_vAlignTable['u106'] = 'center';gv_vAlignTable['u168'] = 'center';gv_vAlignTable['u154'] = 'top';gv_vAlignTable['u40'] = 'center';u139.tabIndex = 0;

u139.style.cursor = 'pointer';
$axure.eventManager.click('u139', function(e) {

if (true) {

	SetPanelVisibility('u132','hidden','none',500);

}
});

$axure.eventManager.mouseover('u139', function(e) {
if (!IsTrueMouseOver('u139',e)) return;
if (true) {

	SetPanelVisibility('u135','','none',500);

}
});

$axure.eventManager.mouseout('u139', function(e) {
if (!IsTrueMouseOut('u139',e)) return;
if (true) {

	SetPanelVisibility('u135','hidden','none',500);

}
});
document.getElementById('u87_img').tabIndex = 0;
HookHover('u87', false);

u87.style.cursor = 'pointer';
$axure.eventManager.click('u87', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u193'] = 'top';gv_vAlignTable['u104'] = 'center';gv_vAlignTable['u192'] = 'center';gv_vAlignTable['u121'] = 'center';gv_vAlignTable['u182'] = 'top';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u155'] = 'top';gv_vAlignTable['u206'] = 'center';document.getElementById('u109_img').tabIndex = 0;
HookHover('u109', false);

u109.style.cursor = 'pointer';
$axure.eventManager.click('u109', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u84'] = 'center';u50.tabIndex = 0;

u50.style.cursor = 'pointer';
$axure.eventManager.click('u50', function(e) {

if (true) {

	SetPanelState('u42', 'pd3u42','none','',500,'none','',500);

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd2u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitu094574e23cc3466a8e2468f81ef84bfe1() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitub003d34f4c344d67bfd57f98225c4f271() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitu43dc700161a94922960dc49b518112451() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitu55972c0385d14b708392962e1b0d05fa1() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitucf8b9e2dfc9a45688f14ddaf1c6002e61() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd2u181','none','',500,'none','',500);
}
setTimeout(waitucf8b9e2dfc9a45688f14ddaf1c6002e61, 10);
}
setTimeout(waitu55972c0385d14b708392962e1b0d05fa1, 10);
}
setTimeout(waitu43dc700161a94922960dc49b518112451, 10);
}
setTimeout(waitub003d34f4c344d67bfd57f98225c4f271, 10);
}
setTimeout(waitu094574e23cc3466a8e2468f81ef84bfe1, 10);

}
});
gv_vAlignTable['u50'] = 'top';document.getElementById('u97_img').tabIndex = 0;
HookHover('u97', false);

u97.style.cursor = 'pointer';
$axure.eventManager.click('u97', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
gv_vAlignTable['u100'] = 'center';gv_vAlignTable['u170'] = 'center';gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u134'] = 'center';document.getElementById('u81_img').tabIndex = 0;
HookHover('u81', false);

u81.style.cursor = 'pointer';
$axure.eventManager.click('u81', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
u209.tabIndex = 0;

u209.style.cursor = 'pointer';
$axure.eventManager.click('u209', function(e) {

if (true) {

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	SetPanelState('u42', 'pd2u42','none','',500,'none','',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd1u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitu0b3bb1dfcbe2445aa2178d0d0f2510fb1() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitu3d2eac22c0674b60a307167a5beef9b61() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitu3136e051c63f492dbd11ec605daa0e811() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitudaeb7e4b45544857818883d9210485ab1() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitue03fe9692d564439a4d89f283a9b1c2a1() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd1u181','none','',500,'none','',500);
}
setTimeout(waitue03fe9692d564439a4d89f283a9b1c2a1, 10);
}
setTimeout(waitudaeb7e4b45544857818883d9210485ab1, 10);
}
setTimeout(waitu3136e051c63f492dbd11ec605daa0e811, 10);
}
setTimeout(waitu3d2eac22c0674b60a307167a5beef9b61, 10);
}
setTimeout(waitu0b3bb1dfcbe2445aa2178d0d0f2510fb1, 10);

}
});
gv_vAlignTable['u209'] = 'top';gv_vAlignTable['u94'] = 'center';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u190'] = 'center';gv_vAlignTable['u185'] = 'top';gv_vAlignTable['u9'] = 'center';u73.tabIndex = 0;

u73.style.cursor = 'pointer';
$axure.eventManager.click('u73', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u147'] = 'center';u163.tabIndex = 0;

u163.style.cursor = 'pointer';
$axure.eventManager.click('u163', function(e) {

if (true) {

	self.location.href='index.html';

}
});
gv_vAlignTable['u163'] = 'top';document.getElementById('u91_img').tabIndex = 0;
HookHover('u91', false);

u91.style.cursor = 'pointer';
$axure.eventManager.click('u91', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u131'] = 'center';u64.tabIndex = 0;

u64.style.cursor = 'pointer';
$axure.eventManager.click('u64', function(e) {

if (true) {

	SetPanelState('u42', 'pd1u42','none','',500,'none','',500);

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd0u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitu224580d2c6f24b4aaa3d9116de24eb9f1() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waituf2ae4ef6371e43ffb01bcc18137827f81() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitu1194232ab0324189910b30004daf16de1() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitu160a93f97eb1476dbbf3dd6f024d21e71() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitu0c8872b66d6a4f9e96d997da9f98ff791() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd0u181','none','',500,'none','',500);
}
setTimeout(waitu0c8872b66d6a4f9e96d997da9f98ff791, 10);
}
setTimeout(waitu160a93f97eb1476dbbf3dd6f024d21e71, 10);
}
setTimeout(waitu1194232ab0324189910b30004daf16de1, 10);
}
setTimeout(waituf2ae4ef6371e43ffb01bcc18137827f81, 10);
}
setTimeout(waitu224580d2c6f24b4aaa3d9116de24eb9f1, 10);

}
});
gv_vAlignTable['u64'] = 'top';u70.tabIndex = 0;

u70.style.cursor = 'pointer';
$axure.eventManager.click('u70', function(e) {

if (true) {

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	SetPanelState('u42', 'pd1u42','none','',500,'none','',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd0u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitu4accd7794388465bb6ce74e985bcbd021() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitufccaef7fec8f479baf6bb573398df8501() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitu8afe336f955b4ba49a7b9cd8c9fdc9ea1() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitu6044a2b488ea4701bf46fd9dcc035d641() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitu6bec0fe3e3654a49b30dea35164b7dd81() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd0u181','none','',500,'none','',500);
}
setTimeout(waitu6bec0fe3e3654a49b30dea35164b7dd81, 10);
}
setTimeout(waitu6044a2b488ea4701bf46fd9dcc035d641, 10);
}
setTimeout(waitu8afe336f955b4ba49a7b9cd8c9fdc9ea1, 10);
}
setTimeout(waitufccaef7fec8f479baf6bb573398df8501, 10);
}
setTimeout(waitu4accd7794388465bb6ce74e985bcbd021, 10);

}
});
gv_vAlignTable['u70'] = 'top';u24.tabIndex = 0;

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u188'] = 'top';u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u23'] = 'top';u213.tabIndex = 0;

u213.style.cursor = 'pointer';
$axure.eventManager.click('u213', function(e) {

if (true) {

	SetPanelVisibility('u177','hidden','none',500);

	SetPanelVisibility('u194','hidden','none',500);

	SetPanelState('u177', 'pd0u177','none','',500,'none','',500);

	SetPanelState('u42', 'pd0u42','none','',500,'none','',500);

}
});
gv_vAlignTable['u213'] = 'top';gv_vAlignTable['u210'] = 'top';u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u29'] = 'top';gv_vAlignTable['u141'] = 'center';gv_vAlignTable['u175'] = 'top';gv_vAlignTable['u217'] = 'center';gv_vAlignTable['u129'] = 'top';gv_vAlignTable['u86'] = 'center';u58.tabIndex = 0;

u58.style.cursor = 'pointer';
$axure.eventManager.click('u58', function(e) {

if (true) {

	SetPanelState('u42', 'pd1u42','none','',500,'none','',500);

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd0u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitua788b868e566435385f6527bd7a0a4001() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitu696fe0ef7b7a433ab2399cf6cc6690e81() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitubb2a8374a30441da9357cd719afa3d5a1() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitu91dcc48272384db1b8945aeff29219231() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitu0d86e1ff16e146d889ec371db8b83fda1() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd0u181','none','',500,'none','',500);
}
setTimeout(waitu0d86e1ff16e146d889ec371db8b83fda1, 10);
}
setTimeout(waitu91dcc48272384db1b8945aeff29219231, 10);
}
setTimeout(waitubb2a8374a30441da9357cd719afa3d5a1, 10);
}
setTimeout(waitu696fe0ef7b7a433ab2399cf6cc6690e81, 10);
}
setTimeout(waitua788b868e566435385f6527bd7a0a4001, 10);

}
});
gv_vAlignTable['u58'] = 'top';u171.tabIndex = 0;

u171.style.cursor = 'pointer';
$axure.eventManager.click('u171', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u119'] = 'center';u63.tabIndex = 0;

u63.style.cursor = 'pointer';
$axure.eventManager.click('u63', function(e) {

if (true) {

	SetPanelState('u42', 'pd4u42','none','',500,'none','',500);

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd3u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitu8e80e53a08f54db09bfb6b22aa2225351() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitu8f19465634e64c90b3d8adc07aba777e1() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitu99e3376dbf2b4ad8b67d7a9011b92d721() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitu3e498b42f19c48939d16ad6babc593d21() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitu28be9114823e4236902c1b4e5c814d5f1() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd3u181','none','',500,'none','',500);
}
setTimeout(waitu28be9114823e4236902c1b4e5c814d5f1, 10);
}
setTimeout(waitu3e498b42f19c48939d16ad6babc593d21, 10);
}
setTimeout(waitu99e3376dbf2b4ad8b67d7a9011b92d721, 10);
}
setTimeout(waitu8f19465634e64c90b3d8adc07aba777e1, 10);
}
setTimeout(waitu8e80e53a08f54db09bfb6b22aa2225351, 10);

}
});
gv_vAlignTable['u63'] = 'top';document.getElementById('u83_img').tabIndex = 0;
HookHover('u83', false);

u83.style.cursor = 'pointer';
$axure.eventManager.click('u83', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u96'] = 'center';gv_vAlignTable['u196'] = 'center';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u15'] = 'top';u49.tabIndex = 0;

u49.style.cursor = 'pointer';
$axure.eventManager.click('u49', function(e) {

if (true) {

	SetPanelState('u42', 'pd2u42','none','',500,'none','',500);

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd1u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitua7cbd119dc164e8fb0ffbe756ac25ec31() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waituc1a83dbde6c248128b1efe4a9bdc0c5d1() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitu098adb1358ee46de88d9f688c64a1aa41() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitu5d8834db995d454bae35f4536a39a17c1() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitub8225dbf81824406a6ff3ca2c0dcc9311() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd1u181','none','',500,'none','',500);
}
setTimeout(waitub8225dbf81824406a6ff3ca2c0dcc9311, 10);
}
setTimeout(waitu5d8834db995d454bae35f4536a39a17c1, 10);
}
setTimeout(waitu098adb1358ee46de88d9f688c64a1aa41, 10);
}
setTimeout(waituc1a83dbde6c248128b1efe4a9bdc0c5d1, 10);
}
setTimeout(waitua7cbd119dc164e8fb0ffbe756ac25ec31, 10);

}
});
gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u80'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u138'] = 'top';document.getElementById('u93_img').tabIndex = 0;
HookHover('u93', false);

u93.style.cursor = 'pointer';
$axure.eventManager.click('u93', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
document.getElementById('u167_img').tabIndex = 0;

u167.style.cursor = 'pointer';
$axure.eventManager.click('u167', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
u12.tabIndex = 0;

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u12'] = 'top';u201.tabIndex = 0;

u201.style.cursor = 'pointer';
$axure.eventManager.click('u201', function(e) {

if (true) {

	SetPanelVisibility('u177','hidden','none',500);

	SetPanelVisibility('u194','hidden','none',500);

	SetPanelState('u177', 'pd0u177','none','',500,'none','',500);

	SetPanelState('u42', 'pd0u42','none','',500,'none','',500);

}
});
gv_vAlignTable['u201'] = 'top';u165.tabIndex = 0;

u165.style.cursor = 'pointer';
$axure.eventManager.click('u165', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');
function waitud60c4460105243299b524b0b32b428cf1() {

	SetPanelState('u164', 'pd1u164','none','',500,'none','',500);
function waitub3ccdb0e2b0e45289ccb18b7f7d0de481() {
function waitu7d17a4dc47ea4dd0b7636d8a947ae1e31() {
}
setTimeout(waitu7d17a4dc47ea4dd0b7636d8a947ae1e31, 200);
}
setTimeout(waitub3ccdb0e2b0e45289ccb18b7f7d0de481, 200);
}
setTimeout(waitud60c4460105243299b524b0b32b428cf1, 300);

}
});
gv_vAlignTable['u165'] = 'top';u25.tabIndex = 0;

u25.style.cursor = 'pointer';
$axure.eventManager.click('u25', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u25'] = 'top';u215.tabIndex = 0;

u215.style.cursor = 'pointer';
$axure.eventManager.click('u215', function(e) {

if (true) {

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	SetPanelState('u42', 'pd1u42','none','',500,'none','',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd0u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitu8465fa0fcf5941348f34ee74f569e4401() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitu7eb55a2521dc494396e6bed7fbf3bddd1() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitu9dff1b95defd4f379551875c6346ca671() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waituc78a580f96354a789cdbc433f56088cc1() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitueecfa068e31d4426ae255fa48635f70c1() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd0u181','none','',500,'none','',500);
}
setTimeout(waitueecfa068e31d4426ae255fa48635f70c1, 10);
}
setTimeout(waituc78a580f96354a789cdbc433f56088cc1, 10);
}
setTimeout(waitu9dff1b95defd4f379551875c6346ca671, 10);
}
setTimeout(waitu7eb55a2521dc494396e6bed7fbf3bddd1, 10);
}
setTimeout(waitu8465fa0fcf5941348f34ee74f569e4401, 10);

}
});
gv_vAlignTable['u215'] = 'top';document.getElementById('u118_img').tabIndex = 0;

u118.style.cursor = 'pointer';
$axure.eventManager.click('u118', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}
});
gv_vAlignTable['u90'] = 'center';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u18'] = 'top';u161.tabIndex = 0;

u161.style.cursor = 'pointer';
$axure.eventManager.click('u161', function(e) {

if (true) {

	SetPanelVisibility('u132','hidden','none',500);

}
});

$axure.eventManager.mouseover('u161', function(e) {
if (!IsTrueMouseOver('u161',e)) return;
if (true) {

	SetPanelVisibility('u151','','none',500);

}
});

$axure.eventManager.mouseout('u161', function(e) {
if (!IsTrueMouseOut('u161',e)) return;
if (true) {

	SetPanelVisibility('u151','hidden','none',500);

}
});
document.getElementById('u77_img').tabIndex = 0;
HookHover('u77', false);

u77.style.cursor = 'pointer';
$axure.eventManager.click('u77', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u22'] = 'top';u220.tabIndex = 0;

u220.style.cursor = 'pointer';
$axure.eventManager.click('u220', function(e) {

if (true) {

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	SetPanelState('u42', 'pd2u42','none','',500,'none','',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd1u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitud696c392563944d3adbfd1ef0ca5d1cf1() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waitu2efeac994da747148d440aef4fe1c27d1() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waitu8d6885270afd484a9071238ab175480b1() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitu416ed57dbda642d8a51fed56a71d9bd61() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitu7e9fef0b7ae14bc2915820c17832327a1() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd1u181','none','',500,'none','',500);
}
setTimeout(waitu7e9fef0b7ae14bc2915820c17832327a1, 10);
}
setTimeout(waitu416ed57dbda642d8a51fed56a71d9bd61, 10);
}
setTimeout(waitu8d6885270afd484a9071238ab175480b1, 10);
}
setTimeout(waitu2efeac994da747148d440aef4fe1c27d1, 10);
}
setTimeout(waitud696c392563944d3adbfd1ef0ca5d1cf1, 10);

}
});
gv_vAlignTable['u220'] = 'top';document.getElementById('u107_img').tabIndex = 0;
HookHover('u107', false);

u107.style.cursor = 'pointer';
$axure.eventManager.click('u107', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});

$axure.eventManager.keyup('u162', function(e) {

if ((GetWidgetText('u162')) == ('')) {

	SetPanelVisibility('u132','hidden','none',500);

}
else
if (true) {

	SetPanelState('u132', 'pd0u132','none','',500,'none','',500);

SetGlobalVariableValue('IncrementalSearchVar', GetWidgetText('u162'));

SetWidgetRichText('u154', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dada</span></p>');

SetWidgetRichText('u155', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dat</span></p>');

SetWidgetRichText('u156', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">gi</span></p>');

SetWidgetRichText('u158', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

SetWidgetRichText('u138', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

	SetPanelVisibility('u132','','none',500);

	BringToFront("u132");
function waitu796b5745765043a58e9fe38835b455f51() {

	SetPanelState('u132', 'pd1u132','none','',500,'none','',500);
}
setTimeout(waitu796b5745765043a58e9fe38835b455f51, 2000);

}
});

$axure.eventManager.blur('u162', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u162'));

}
});
u69.tabIndex = 0;

u69.style.cursor = 'pointer';
$axure.eventManager.click('u69', function(e) {

if (true) {

	SetPanelVisibility('u177','','none',500);

	BringToFront("u177");

	SetPanelVisibility('u194','hidden','none',500);

	SetPanelState('u42', 'pd4u42','none','',500,'none','',500);

	MoveWidgetTo('u194', GetNum('930'), GetNum('460'),'none',500);

	SetPanelState('u197', 'pd3u197','none','',500,'none','',500);

	SetPanelVisibility('u194','','none',500);

	BringToFront("u194");
function waitu117781f2d9df4fe4aa7db45ccc0e00461() {

	MoveWidgetTo('u194', GetNum('755'), GetNum('434'),'none',500);

	MoveWidgetTo('u177', GetNum('257'), GetNum('-50'),'none',500);
function waituc005658edd8548dc97954f82eb59789a1() {

	MoveWidgetTo('u194', GetNum('580'), GetNum('392'),'none',500);

	MoveWidgetTo('u177', GetNum('220'), GetNum('-195'),'none',500);
function waituce1673643ccc4fb79079d1fc1415c7fc1() {

	MoveWidgetTo('u194', GetNum('420'), GetNum('275'),'none',500);

	MoveWidgetTo('u177', GetNum('182'), GetNum('-340'),'none',500);
function waitud9388c7e30ec484b94e2a598a3b0226d1() {

	MoveWidgetTo('u194', GetNum('346'), GetNum('150'),'none',500);

	MoveWidgetTo('u177', GetNum('143'), GetNum('-489'),'none',500);
function waitu1bf9cd16a94d4ec1919f3e75e6bb18d81() {

	MoveWidgetTo('u194', GetNum('295'), GetNum('31'),'none',500);

	SetPanelVisibility('u177','hidden','none',500);

	MoveWidgetTo('u177', GetNum('295'), GetNum('31'),'none',500);

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelState('u181', 'pd3u181','none','',500,'none','',500);
}
setTimeout(waitu1bf9cd16a94d4ec1919f3e75e6bb18d81, 10);
}
setTimeout(waitud9388c7e30ec484b94e2a598a3b0226d1, 10);
}
setTimeout(waituce1673643ccc4fb79079d1fc1415c7fc1, 10);
}
setTimeout(waituc005658edd8548dc97954f82eb59789a1, 10);
}
setTimeout(waitu117781f2d9df4fe4aa7db45ccc0e00461, 10);

}
});
gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u218'] = 'top';gv_vAlignTable['u180'] = 'top';u28.tabIndex = 0;

u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u28'] = 'top';