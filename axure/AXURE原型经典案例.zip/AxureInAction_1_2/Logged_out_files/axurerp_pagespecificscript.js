﻿for(var i = 0; i < 137; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if ((GetGlobalVariableValue('ShoppingBasket')) == ('Empty')) {

	SetPanelState('u76', 'pd0u76','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('1'))) {

SetWidgetRichText('u78', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (1 item)</span></p>');

	SetPanelState('u76', 'pd1u76','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('2'))) {

SetWidgetRichText('u78', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (2 items)</span></p>');

	SetPanelState('u76', 'pd1u76','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('3'))) {

SetWidgetRichText('u78', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (3 items)</span></p>');

	SetPanelState('u76', 'pd1u76','none','',500,'none','',500);

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) {

}

});

function rdo1LoadHome(e) {

}
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u86'] = 'center';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u113'] = 'top';gv_vAlignTable['u25'] = 'top';u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u55'] = 'center';document.getElementById('u46_img').tabIndex = 0;
HookHover('u46', false);

u46.style.cursor = 'pointer';
$axure.eventManager.click('u46', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
document.getElementById('u77_img').tabIndex = 0;

u77.style.cursor = 'pointer';
$axure.eventManager.click('u77', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}
});
gv_vAlignTable['u93'] = 'center';u8.tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u23'] = 'top';document.getElementById('u62_img').tabIndex = 0;
HookHover('u62', false);

u62.style.cursor = 'pointer';
$axure.eventManager.click('u62', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u87'] = 'top';gv_vAlignTable['u1'] = 'center';u119.tabIndex = 0;

u119.style.cursor = 'pointer';
$axure.eventManager.click('u119', function(e) {

if (true) {

	SetPanelVisibility('u91','hidden','none',500);

}
});

$axure.eventManager.mouseover('u119', function(e) {
if (!IsTrueMouseOver('u119',e)) return;
if (true) {

	SetPanelVisibility('u107','','none',500);

}
});

$axure.eventManager.mouseout('u119', function(e) {
if (!IsTrueMouseOut('u119',e)) return;
if (true) {

	SetPanelVisibility('u107','hidden','none',500);

}
});
document.getElementById('u38_img').tabIndex = 0;
HookHover('u38', false);

u38.style.cursor = 'pointer';
$axure.eventManager.click('u38', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
u7.tabIndex = 0;

u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u7'] = 'top';document.getElementById('u66_img').tabIndex = 0;
HookHover('u66', false);

u66.style.cursor = 'pointer';
$axure.eventManager.click('u66', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u112'] = 'center';gv_vAlignTable['u115'] = 'top';u130.tabIndex = 0;

u130.style.cursor = 'pointer';
$axure.eventManager.click('u130', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
document.getElementById('u60_img').tabIndex = 0;
HookHover('u60', false);

u60.style.cursor = 'pointer';
$axure.eventManager.click('u60', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u133'] = 'top';document.getElementById('u89_img').tabIndex = 0;

u89.style.cursor = 'pointer';
$axure.eventManager.click('u89', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u121'));

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Search_results.html');

}
});
u122.tabIndex = 0;

u122.style.cursor = 'pointer';
$axure.eventManager.click('u122', function(e) {

if (true) {

	self.location.href='index.html';

}
});
gv_vAlignTable['u122'] = 'top';document.getElementById('u34_img').tabIndex = 0;
HookHover('u34', false);

u34.style.cursor = 'pointer';
$axure.eventManager.click('u34', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u17'] = 'top';document.getElementById('u64_img').tabIndex = 0;
HookHover('u64', false);

u64.style.cursor = 'pointer';
$axure.eventManager.click('u64', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u100'] = 'center';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u49'] = 'center';document.getElementById('u79_img').tabIndex = 0;

u79.style.cursor = 'pointer';
$axure.eventManager.click('u79', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}

if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('OnLoadVariable')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u97'] = 'top';gv_vAlignTable['u135'] = 'top';u118.tabIndex = 0;

u118.style.cursor = 'pointer';
$axure.eventManager.click('u118', function(e) {

if (true) {

	SetPanelVisibility('u91','hidden','none',500);

}
});

$axure.eventManager.mouseover('u118', function(e) {
if (!IsTrueMouseOver('u118',e)) return;
if (true) {

	SetPanelVisibility('u104','','none',500);

}
});

$axure.eventManager.mouseout('u118', function(e) {
if (!IsTrueMouseOut('u118',e)) return;
if (true) {

	SetPanelVisibility('u104','hidden','none',500);

}
});
u124.tabIndex = 0;

u124.style.cursor = 'pointer';
$axure.eventManager.click('u124', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');
function waitud60c4460105243299b524b0b32b428cf1() {

	SetPanelState('u123', 'pd1u123','none','',500,'none','',500);
function waitub3ccdb0e2b0e45289ccb18b7f7d0de481() {
function waitu7d17a4dc47ea4dd0b7636d8a947ae1e31() {
}
setTimeout(waitu7d17a4dc47ea4dd0b7636d8a947ae1e31, 200);
}
setTimeout(waitub3ccdb0e2b0e45289ccb18b7f7d0de481, 200);
}
setTimeout(waitud60c4460105243299b524b0b32b428cf1, 300);

}
});
gv_vAlignTable['u124'] = 'top';u11.tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u71'] = 'center';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u45'] = 'center';document.getElementById('u36_img').tabIndex = 0;
HookHover('u36', false);

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
document.getElementById('u58_img').tabIndex = 0;
HookHover('u58', false);

u58.style.cursor = 'pointer';
$axure.eventManager.click('u58', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u37'] = 'center';document.getElementById('u126_img').tabIndex = 0;

u126.style.cursor = 'pointer';
$axure.eventManager.click('u126', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
u2.tabIndex = 0;

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u129'] = 'center';u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u13'] = 'top';document.getElementById('u52_img').tabIndex = 0;
HookHover('u52', false);

u52.style.cursor = 'pointer';
$axure.eventManager.click('u52', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u43'] = 'center';u3.tabIndex = 0;

u3.style.cursor = 'pointer';
$axure.eventManager.click('u3', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u47'] = 'center';document.getElementById('u68_img').tabIndex = 0;
HookHover('u68', false);

u68.style.cursor = 'pointer';
$axure.eventManager.click('u68', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u90'] = 'center';document.getElementById('u73_img').tabIndex = 0;

u73.style.cursor = 'pointer';
$axure.eventManager.click('u73', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u84'] = 'center';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u20'] = 'top';document.getElementById('u50_img').tabIndex = 0;
HookHover('u50', false);

u50.style.cursor = 'pointer';
$axure.eventManager.click('u50', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
HookHover('u128', false);
gv_vAlignTable['u106'] = 'center';document.getElementById('u28_img').tabIndex = 0;

u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u24'] = 'top';document.getElementById('u54_img').tabIndex = 0;
HookHover('u54', false);

u54.style.cursor = 'pointer';
$axure.eventManager.click('u54', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u78'] = 'center';u120.tabIndex = 0;

u120.style.cursor = 'pointer';
$axure.eventManager.click('u120', function(e) {

if (true) {

	SetPanelVisibility('u91','hidden','none',500);

}
});

$axure.eventManager.mouseover('u120', function(e) {
if (!IsTrueMouseOver('u120',e)) return;
if (true) {

	SetPanelVisibility('u110','','none',500);

}
});

$axure.eventManager.mouseout('u120', function(e) {
if (!IsTrueMouseOut('u120',e)) return;
if (true) {

	SetPanelVisibility('u110','hidden','none',500);

}
});
u131.tabIndex = 0;

u131.style.cursor = 'pointer';
$axure.eventManager.click('u131', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('My_details.html');

}
else
if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('LoginStatus')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u131'] = 'top';gv_vAlignTable['u114'] = 'top';u4.tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u103'] = 'center';u6.tabIndex = 0;

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u96'] = 'center';gv_vAlignTable['u61'] = 'center';u136.tabIndex = 0;

u136.style.cursor = 'pointer';
$axure.eventManager.click('u136', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u136'] = 'top';gv_vAlignTable['u35'] = 'center';u26.tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href='http://www.lucabenazzi.eu';

}
});
gv_vAlignTable['u65'] = 'center';document.getElementById('u56_img').tabIndex = 0;
HookHover('u56', false);

u56.style.cursor = 'pointer';
$axure.eventManager.click('u56', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
u116.tabIndex = 0;

u116.style.cursor = 'pointer';
$axure.eventManager.click('u116', function(e) {

if (true) {

	SetPanelVisibility('u91','hidden','none',500);

}
});

$axure.eventManager.mouseover('u116', function(e) {
if (!IsTrueMouseOver('u116',e)) return;
if (true) {

	SetPanelVisibility('u101','','none',500);

}
});

$axure.eventManager.mouseout('u116', function(e) {
if (!IsTrueMouseOut('u116',e)) return;
if (true) {

	SetPanelVisibility('u101','hidden','none',500);

}
});
gv_vAlignTable['u127'] = 'center';gv_vAlignTable['u109'] = 'center';gv_vAlignTable['u82'] = 'center';u5.tabIndex = 0;

u5.style.cursor = 'pointer';
$axure.eventManager.click('u5', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u5'] = 'top';u134.tabIndex = 0;

u134.style.cursor = 'pointer';
$axure.eventManager.click('u134', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u134'] = 'top';u12.tabIndex = 0;

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u12'] = 'top';u9.tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
gv_vAlignTable['u9'] = 'top';document.getElementById('u42_img').tabIndex = 0;
HookHover('u42', false);

u42.style.cursor = 'pointer';
$axure.eventManager.click('u42', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u63'] = 'center';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u18'] = 'top';document.getElementById('u48_img').tabIndex = 0;
HookHover('u48', false);

u48.style.cursor = 'pointer';
$axure.eventManager.click('u48', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u57'] = 'center';u125.tabIndex = 0;

u125.style.cursor = 'pointer';
$axure.eventManager.click('u125', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');

SetGlobalVariableValue('BookPageViewed', '');

SetGlobalVariableValue('CitySelected', '');

SetGlobalVariableValue('LoginStatus', '');

SetGlobalVariableValue('ReviewVar', '');

SetGlobalVariableValue('EmployeesName', '');

	SetPanelState('u123', 'pd1u123','none','',500,'none','',500);
function waituf022ddcb6b474903a282219d39d908ef1() {

	SetPanelState('u123', 'pd0u123','none','',500,'none','',500);
}
setTimeout(waituf022ddcb6b474903a282219d39d908ef1, 4000);

}
});
gv_vAlignTable['u125'] = 'top';u10.tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u10'] = 'top';document.getElementById('u40_img').tabIndex = 0;
HookHover('u40', false);

u40.style.cursor = 'pointer';
$axure.eventManager.click('u40', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
u14.tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u14'] = 'top';HookHover('u44', false);
gv_vAlignTable['u117'] = 'top';gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u59'] = 'center';u98.tabIndex = 0;

u98.style.cursor = 'pointer';
$axure.eventManager.click('u98', function(e) {

if (true) {

	SetPanelVisibility('u91','hidden','none',500);

}
});

$axure.eventManager.mouseover('u98', function(e) {
if (!IsTrueMouseOver('u98',e)) return;
if (true) {

	SetPanelVisibility('u94','','none',500);

}
});

$axure.eventManager.mouseout('u98', function(e) {
if (!IsTrueMouseOut('u98',e)) return;
if (true) {

	SetPanelVisibility('u94','hidden','none',500);

}
});
gv_vAlignTable['u80'] = 'center';
$axure.eventManager.keyup('u121', function(e) {

if ((GetWidgetText('u121')) == ('')) {

	SetPanelVisibility('u91','hidden','none',500);

}
else
if (true) {

	SetPanelState('u91', 'pd0u91','none','',500,'none','',500);

SetGlobalVariableValue('IncrementalSearchVar', GetWidgetText('u121'));

SetWidgetRichText('u113', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dada</span></p>');

SetWidgetRichText('u114', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dat</span></p>');

SetWidgetRichText('u115', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">gi</span></p>');

SetWidgetRichText('u117', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

SetWidgetRichText('u97', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

	SetPanelVisibility('u91','','none',500);

	BringToFront("u91");
function waitu796b5745765043a58e9fe38835b455f51() {

	SetPanelState('u91', 'pd1u91','none','',500,'none','',500);
}
setTimeout(waitu796b5745765043a58e9fe38835b455f51, 2000);

}
});

$axure.eventManager.blur('u121', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u121'));

}
});
