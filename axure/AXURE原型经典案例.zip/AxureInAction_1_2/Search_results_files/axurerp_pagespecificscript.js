﻿for(var i = 0; i < 261; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

SetWidgetRichText('u253', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:21px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Search results for </span><span style="font-family:Verdana;font-size:21px;font-weight:normal;font-style:italic;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('SearchVar')) + '</span></p>');

SetWidgetRichText('u122', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:italic;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('SearchVar')) + '</span></p>');

SetWidgetRichText('u133', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:italic;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('SearchVar')) + '</span></p>');

SetWidgetRichText('u116', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:italic;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('SearchVar')) + '</span></p>');

SetWidgetRichText('u112', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:italic;text-decoration:underline;color:#000000;">' + (GetGlobalVariableValue('SearchVar')) + '</span><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:underline;color:#0000FF;"> ipsum</span><span style="font-family:Verdana;font-size:11px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000FF;">&nbsp;</span><span style="font-family:Verdana;font-size:11px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000FF;">(Home &gt; Books &gt; Science &gt; Biology)</span></p>');

SetWidgetRichText('u45', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:italic;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('SearchVar')) + '</span></p>');

SetWidgetRichText('u100', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:italic;text-decoration:underline;color:#000000;">' + (GetGlobalVariableValue('SearchVar')) + '</span><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:underline;color:#0000FF;"> ipsum</span><span style="font-family:Verdana;font-size:11px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000FF;">&nbsp;</span><span style="font-family:Verdana;font-size:11px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000FF;">(Home &gt; Books &gt; Science &gt; Biology)</span></p>');

SetWidgetRichText('u89', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:italic;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('SearchVar')) + '</span></p>');

SetWidgetRichText('u94', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:italic;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('SearchVar')) + '</span></p>');

SetWidgetRichText('u141', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:italic;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('SearchVar')) + '</span></p>');

}

if ((GetGlobalVariableValue('ShoppingBasket')) == ('Empty')) {

	SetPanelState('u196', 'pd0u196','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('1'))) {

SetWidgetRichText('u198', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (1 item)</span></p>');

	SetPanelState('u196', 'pd1u196','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('2'))) {

SetWidgetRichText('u198', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (2 items)</span></p>');

	SetPanelState('u196', 'pd1u196','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('3'))) {

SetWidgetRichText('u198', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (3 items)</span></p>');

	SetPanelState('u196', 'pd1u196','none','',500,'none','',500);

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) {

}

});

function rdo1LoadHome(e) {

}
gv_vAlignTable['u115'] = 'top';gv_vAlignTable['u122'] = 'top';gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u53'] = 'top';gv_vAlignTable['u32'] = 'center';document.getElementById('u156_img').tabIndex = 0;
HookHover('u156', false);

u156.style.cursor = 'pointer';
$axure.eventManager.click('u156', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u207'] = 'top';gv_vAlignTable['u130'] = 'top';u7.tabIndex = 0;

u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u45'] = 'top';gv_vAlignTable['u99'] = 'center';u236.tabIndex = 0;

u236.style.cursor = 'pointer';
$axure.eventManager.click('u236', function(e) {

if (true) {

	SetPanelVisibility('u211','hidden','none',500);

}
});

$axure.eventManager.mouseover('u236', function(e) {
if (!IsTrueMouseOver('u236',e)) return;
if (true) {

	SetPanelVisibility('u221','','none',500);

}
});

$axure.eventManager.mouseout('u236', function(e) {
if (!IsTrueMouseOut('u236',e)) return;
if (true) {

	SetPanelVisibility('u221','hidden','none',500);

}
});
u4.tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u140'] = 'top';u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u135'] = 'center';gv_vAlignTable['u151'] = 'top';gv_vAlignTable['u103'] = 'center';gv_vAlignTable['u256'] = 'center';gv_vAlignTable['u159'] = 'center';gv_vAlignTable['u229'] = 'center';gv_vAlignTable['u55'] = 'center';u101.tabIndex = 0;

u101.style.cursor = 'pointer';
$axure.eventManager.click('u101', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u101'] = 'top';document.getElementById('u186_img').tabIndex = 0;
HookHover('u186', false);

u186.style.cursor = 'pointer';
$axure.eventManager.click('u186', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
u14.tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u14'] = 'top';u5.tabIndex = 0;

u5.style.cursor = 'pointer';
$axure.eventManager.click('u5', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u105'] = 'center';document.getElementById('u246_img').tabIndex = 0;

u246.style.cursor = 'pointer';
$axure.eventManager.click('u246', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u235'] = 'top';u138.tabIndex = 0;

u138.style.cursor = 'pointer';
$axure.eventManager.click('u138', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u138'] = 'top';u2.tabIndex = 0;

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u52'] = 'center';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u20'] = 'top';document.getElementById('u67_img').tabIndex = 0;

u67.style.cursor = 'pointer';
$axure.eventManager.click('u67', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
u11.tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u120'] = 'top';gv_vAlignTable['u189'] = 'center';document.getElementById('u110_img').tabIndex = 0;

u110.style.cursor = 'pointer';
$axure.eventManager.click('u110', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
u6.tabIndex = 0;

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u48'] = 'center';document.getElementById('u108_img').tabIndex = 0;

u108.style.cursor = 'pointer';
$axure.eventManager.click('u108', function(e) {

if (true) {

	SetPanelState('u34', 'pd2u34','none','',500,'none','',500);

}
});
document.getElementById('u37_img').tabIndex = 0;

u37.style.cursor = 'pointer';
$axure.eventManager.click('u37', function(e) {

if (true) {

	SetPanelState('u34', 'pd0u34','none','',500,'none','',500);

}
});
u238.tabIndex = 0;

u238.style.cursor = 'pointer';
$axure.eventManager.click('u238', function(e) {

if (true) {

	SetPanelVisibility('u211','hidden','none',500);

}
});

$axure.eventManager.mouseover('u238', function(e) {
if (!IsTrueMouseOver('u238',e)) return;
if (true) {

	SetPanelVisibility('u224','','none',500);

}
});

$axure.eventManager.mouseout('u238', function(e) {
if (!IsTrueMouseOut('u238',e)) return;
if (true) {

	SetPanelVisibility('u224','hidden','none',500);

}
});
u251.tabIndex = 0;

u251.style.cursor = 'pointer';
$axure.eventManager.click('u251', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('My_details.html');

}
else
if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('LoginStatus')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u251'] = 'top';gv_vAlignTable['u62'] = 'center';gv_vAlignTable['u141'] = 'top';
$axure.eventManager.keyup('u241', function(e) {

if ((GetWidgetText('u241')) == ('')) {

	SetPanelVisibility('u211','hidden','none',500);

}
else
if (true) {

	SetPanelState('u211', 'pd0u211','none','',500,'none','',500);

SetGlobalVariableValue('IncrementalSearchVar', GetWidgetText('u241'));

SetWidgetRichText('u233', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dada</span></p>');

SetWidgetRichText('u234', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dat</span></p>');

SetWidgetRichText('u235', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">gi</span></p>');

SetWidgetRichText('u237', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

SetWidgetRichText('u217', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

	SetPanelVisibility('u211','','none',500);

	BringToFront("u211");
function waitu796b5745765043a58e9fe38835b455f51() {

	SetPanelState('u211', 'pd1u211','none','',500,'none','',500);
}
setTimeout(waitu796b5745765043a58e9fe38835b455f51, 2000);

}
});

$axure.eventManager.blur('u241', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u241'));

}
});
document.getElementById('u75_img').tabIndex = 0;

u75.style.cursor = 'pointer';
$axure.eventManager.click('u75', function(e) {

if (true) {

	SetPanelState('u34', 'pd3u34','none','',500,'none','',500);

}
});
gv_vAlignTable['u133'] = 'top';gv_vAlignTable['u200'] = 'center';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u89'] = 'top';gv_vAlignTable['u208'] = 'top';document.getElementById('u47_img').tabIndex = 0;

u47.style.cursor = 'pointer';
$axure.eventManager.click('u47', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u213'] = 'center';document.getElementById('u184_img').tabIndex = 0;
HookHover('u184', false);

u184.style.cursor = 'pointer';
$axure.eventManager.click('u184', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u161'] = 'center';gv_vAlignTable['u72'] = 'top';u112.tabIndex = 0;

u112.style.cursor = 'pointer';
$axure.eventManager.click('u112', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u112'] = 'top';gv_vAlignTable['u216'] = 'center';HookHover('u164', false);
gv_vAlignTable['u233'] = 'top';gv_vAlignTable['u146'] = 'top';gv_vAlignTable['u44'] = 'top';gv_vAlignTable['u179'] = 'center';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u253'] = 'top';gv_vAlignTable['u191'] = 'center';u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u16'] = 'top';document.getElementById('u41_img').tabIndex = 0;

u41.style.cursor = 'pointer';
$axure.eventManager.click('u41', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
document.getElementById('u172_img').tabIndex = 0;
HookHover('u172', false);

u172.style.cursor = 'pointer';
$axure.eventManager.click('u172', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u149'] = 'center';u218.tabIndex = 0;

u218.style.cursor = 'pointer';
$axure.eventManager.click('u218', function(e) {

if (true) {

	SetPanelVisibility('u211','hidden','none',500);

}
});

$axure.eventManager.mouseover('u218', function(e) {
if (!IsTrueMouseOver('u218',e)) return;
if (true) {

	SetPanelVisibility('u214','','none',500);

}
});

$axure.eventManager.mouseout('u218', function(e) {
if (!IsTrueMouseOut('u218',e)) return;
if (true) {

	SetPanelVisibility('u214','hidden','none',500);

}
});
document.getElementById('u54_img').tabIndex = 0;

u54.style.cursor = 'pointer';
$axure.eventManager.click('u54', function(e) {

if (true) {

	SetPanelState('u34', 'pd2u34','none','',500,'none','',500);

}
});
gv_vAlignTable['u118'] = 'center';document.getElementById('u197_img').tabIndex = 0;

u197.style.cursor = 'pointer';
$axure.eventManager.click('u197', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}
});
gv_vAlignTable['u88'] = 'top';gv_vAlignTable['u187'] = 'center';gv_vAlignTable['u38'] = 'center';document.getElementById('u176_img').tabIndex = 0;
HookHover('u176', false);

u176.style.cursor = 'pointer';
$axure.eventManager.click('u176', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
u26.tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href='http://www.lucabenazzi.eu';

}
});
document.getElementById('u174_img').tabIndex = 0;
HookHover('u174', false);

u174.style.cursor = 'pointer';
$axure.eventManager.click('u174', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
u119.tabIndex = 0;

u119.style.cursor = 'pointer';
$axure.eventManager.click('u119', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u119'] = 'top';u254.tabIndex = 0;

u254.style.cursor = 'pointer';
$axure.eventManager.click('u254', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u254'] = 'top';gv_vAlignTable['u85'] = 'center';document.getElementById('u51_img').tabIndex = 0;

u51.style.cursor = 'pointer';
$axure.eventManager.click('u51', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
document.getElementById('u182_img').tabIndex = 0;
HookHover('u182', false);

u182.style.cursor = 'pointer';
$axure.eventManager.click('u182', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u249'] = 'center';u10.tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u10'] = 'top';u100.tabIndex = 0;

u100.style.cursor = 'pointer';
$axure.eventManager.click('u100', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u100'] = 'top';u77.tabIndex = 0;

u77.style.cursor = 'pointer';
$axure.eventManager.click('u77', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u77'] = 'top';gv_vAlignTable['u153'] = 'center';gv_vAlignTable['u202'] = 'center';document.getElementById('u166_img').tabIndex = 0;
HookHover('u166', false);

u166.style.cursor = 'pointer';
$axure.eventManager.click('u166', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
document.getElementById('u82_img').tabIndex = 0;

u82.style.cursor = 'pointer';
$axure.eventManager.click('u82', function(e) {

if (true) {

	SetPanelState('u34', 'pd1u34','none','',500,'none','',500);

}
});
gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u95'] = 'top';gv_vAlignTable['u116'] = 'top';document.getElementById('u158_img').tabIndex = 0;
HookHover('u158', false);

u158.style.cursor = 'pointer';
$axure.eventManager.click('u158', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u74'] = 'center';document.getElementById('u56_img').tabIndex = 0;

u56.style.cursor = 'pointer';
$axure.eventManager.click('u56', function(e) {

if (true) {

	SetPanelState('u34', 'pd3u34','none','',500,'none','',500);

}
});
gv_vAlignTable['u223'] = 'center';document.getElementById('u160_img').tabIndex = 0;
HookHover('u160', false);

u160.style.cursor = 'pointer';
$axure.eventManager.click('u160', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u157'] = 'center';document.getElementById('u136_img').tabIndex = 0;

u136.style.cursor = 'pointer';
$axure.eventManager.click('u136', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u71'] = 'top';gv_vAlignTable['u181'] = 'center';gv_vAlignTable['u198'] = 'center';document.getElementById('u98_img').tabIndex = 0;

u98.style.cursor = 'pointer';
$axure.eventManager.click('u98', function(e) {

if (true) {

	SetPanelState('u34', 'pd3u34','none','',500,'none','',500);

}
});
gv_vAlignTable['u79'] = 'center';document.getElementById('u127_img').tabIndex = 0;

u127.style.cursor = 'pointer';
$axure.eventManager.click('u127', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u43'] = 'top';u257.tabIndex = 0;

u257.style.cursor = 'pointer';
$axure.eventManager.click('u257', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u257'] = 'top';gv_vAlignTable['u169'] = 'center';u240.tabIndex = 0;

u240.style.cursor = 'pointer';
$axure.eventManager.click('u240', function(e) {

if (true) {

	SetPanelVisibility('u211','hidden','none',500);

}
});

$axure.eventManager.mouseover('u240', function(e) {
if (!IsTrueMouseOver('u240',e)) return;
if (true) {

	SetPanelVisibility('u230','','none',500);

}
});

$axure.eventManager.mouseout('u240', function(e) {
if (!IsTrueMouseOut('u240',e)) return;
if (true) {

	SetPanelVisibility('u230','hidden','none',500);

}
});
gv_vAlignTable['u131'] = 'top';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u42'] = 'center';document.getElementById('u106_img').tabIndex = 0;

u106.style.cursor = 'pointer';
$axure.eventManager.click('u106', function(e) {

if (true) {

	SetPanelState('u34', 'pd1u34','none','',500,'none','',500);

}
});
document.getElementById('u168_img').tabIndex = 0;
HookHover('u168', false);

u168.style.cursor = 'pointer';
$axure.eventManager.click('u168', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
document.getElementById('u154_img').tabIndex = 0;
HookHover('u154', false);

u154.style.cursor = 'pointer';
$axure.eventManager.click('u154', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u139'] = 'top';gv_vAlignTable['u23'] = 'top';document.getElementById('u193_img').tabIndex = 0;

u193.style.cursor = 'pointer';
$axure.eventManager.click('u193', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
u150.tabIndex = 0;

u150.style.cursor = 'pointer';
$axure.eventManager.click('u150', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u150'] = 'top';u250.tabIndex = 0;

u250.style.cursor = 'pointer';
$axure.eventManager.click('u250', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
document.getElementById('u65_img').tabIndex = 0;

u65.style.cursor = 'pointer';
$axure.eventManager.click('u65', function(e) {

if (true) {

	SetPanelState('u34', 'pd1u34','none','',500,'none','',500);

}
});
gv_vAlignTable['u155'] = 'center';gv_vAlignTable['u206'] = 'center';gv_vAlignTable['u109'] = 'center';document.getElementById('u84_img').tabIndex = 0;

u84.style.cursor = 'pointer';
$axure.eventManager.click('u84', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
u239.tabIndex = 0;

u239.style.cursor = 'pointer';
$axure.eventManager.click('u239', function(e) {

if (true) {

	SetPanelVisibility('u211','hidden','none',500);

}
});

$axure.eventManager.mouseover('u239', function(e) {
if (!IsTrueMouseOver('u239',e)) return;
if (true) {

	SetPanelVisibility('u227','','none',500);

}
});

$axure.eventManager.mouseout('u239', function(e) {
if (!IsTrueMouseOut('u239',e)) return;
if (true) {

	SetPanelVisibility('u227','hidden','none',500);

}
});
gv_vAlignTable['u97'] = 'center';document.getElementById('u63_img').tabIndex = 0;

u63.style.cursor = 'pointer';
$axure.eventManager.click('u63', function(e) {

if (true) {

	SetPanelState('u34', 'pd0u34','none','',500,'none','',500);

}
});
gv_vAlignTable['u260'] = 'top';document.getElementById('u170_img').tabIndex = 0;
HookHover('u170', false);

u170.style.cursor = 'pointer';
$axure.eventManager.click('u170', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u121'] = 'top';document.getElementById('u255_img').tabIndex = 0;

u255.style.cursor = 'pointer';
$axure.eventManager.click('u255', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u241'));

	self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));


}
});
gv_vAlignTable['u177'] = 'center';document.getElementById('u209_img').tabIndex = 0;

u209.style.cursor = 'pointer';
$axure.eventManager.click('u209', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u241'));

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u128'] = 'center';gv_vAlignTable['u94'] = 'top';u60.tabIndex = 0;

u60.style.cursor = 'pointer';
$axure.eventManager.click('u60', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u60'] = 'top';gv_vAlignTable['u185'] = 'center';u9.tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
gv_vAlignTable['u9'] = 'top';document.getElementById('u73_img').tabIndex = 0;

u73.style.cursor = 'pointer';
$axure.eventManager.click('u73', function(e) {

if (true) {

	SetPanelState('u34', 'pd2u34','none','',500,'none','',500);

}
});
gv_vAlignTable['u113'] = 'top';gv_vAlignTable['u234'] = 'top';gv_vAlignTable['u163'] = 'center';gv_vAlignTable['u91'] = 'center';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u19'] = 'top';u242.tabIndex = 0;

u242.style.cursor = 'pointer';
$axure.eventManager.click('u242', function(e) {

if (true) {

	self.location.href='index.html';

}
});
gv_vAlignTable['u242'] = 'top';gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u70'] = 'top';gv_vAlignTable['u24'] = 'top';document.getElementById('u188_img').tabIndex = 0;
HookHover('u188', false);

u188.style.cursor = 'pointer';
$axure.eventManager.click('u188', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
document.getElementById('u162_img').tabIndex = 0;
HookHover('u162', false);

u162.style.cursor = 'pointer';
$axure.eventManager.click('u162', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u204'] = 'center';gv_vAlignTable['u126'] = 'center';gv_vAlignTable['u217'] = 'top';gv_vAlignTable['u210'] = 'center';u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u247'] = 'center';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u111'] = 'center';gv_vAlignTable['u132'] = 'top';gv_vAlignTable['u175'] = 'center';gv_vAlignTable['u226'] = 'center';u129.tabIndex = 0;

u129.style.cursor = 'pointer';
$axure.eventManager.click('u129', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u129'] = 'top';document.getElementById('u143_img').tabIndex = 0;

u143.style.cursor = 'pointer';
$axure.eventManager.click('u143', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
u58.tabIndex = 0;

u58.style.cursor = 'pointer';
$axure.eventManager.click('u58', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u58'] = 'top';gv_vAlignTable['u183'] = 'center';gv_vAlignTable['u86'] = 'top';gv_vAlignTable['u173'] = 'center';document.getElementById('u39_img').tabIndex = 0;

u39.style.cursor = 'pointer';
$axure.eventManager.click('u39', function(e) {

if (true) {

	SetPanelState('u34', 'pd1u34','none','',500,'none','',500);

}
});
gv_vAlignTable['u171'] = 'center';gv_vAlignTable['u81'] = 'center';u145.tabIndex = 0;

u145.style.cursor = 'pointer';
$axure.eventManager.click('u145', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u145'] = 'top';gv_vAlignTable['u232'] = 'center';gv_vAlignTable['u83'] = 'center';document.getElementById('u178_img').tabIndex = 0;
HookHover('u178', false);

u178.style.cursor = 'pointer';
$axure.eventManager.click('u178', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
u8.tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u8'] = 'top';u3.tabIndex = 0;

u3.style.cursor = 'pointer';
$axure.eventManager.click('u3', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u3'] = 'top';document.getElementById('u96_img').tabIndex = 0;

u96.style.cursor = 'pointer';
$axure.eventManager.click('u96', function(e) {

if (true) {

	SetPanelState('u34', 'pd2u34','none','',500,'none','',500);

}
});
u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u49'] = 'top';gv_vAlignTable['u124'] = 'center';gv_vAlignTable['u144'] = 'center';document.getElementById('u80_img').tabIndex = 0;

u80.style.cursor = 'pointer';
$axure.eventManager.click('u80', function(e) {

if (true) {

	SetPanelState('u34', 'pd0u34','none','',500,'none','',500);

}
});
gv_vAlignTable['u1'] = 'center';u245.tabIndex = 0;

u245.style.cursor = 'pointer';
$axure.eventManager.click('u245', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');

SetGlobalVariableValue('BookPageViewed', '');

SetGlobalVariableValue('CitySelected', '');

SetGlobalVariableValue('LoginStatus', '');

SetGlobalVariableValue('ReviewVar', '');

SetGlobalVariableValue('EmployeesName', '');

	SetPanelState('u243', 'pd1u243','none','',500,'none','',500);
function waituf022ddcb6b474903a282219d39d908ef1() {

	SetPanelState('u243', 'pd0u243','none','',500,'none','',500);
}
setTimeout(waituf022ddcb6b474903a282219d39d908ef1, 4000);

}
});
gv_vAlignTable['u245'] = 'top';document.getElementById('u148_img').tabIndex = 0;

u148.style.cursor = 'pointer';
$axure.eventManager.click('u148', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u167'] = 'center';u12.tabIndex = 0;

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u165'] = 'center';document.getElementById('u199_img').tabIndex = 0;

u199.style.cursor = 'pointer';
$axure.eventManager.click('u199', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}

if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('OnLoadVariable')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
document.getElementById('u117_img').tabIndex = 0;

u117.style.cursor = 'pointer';
$axure.eventManager.click('u117', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
u59.tabIndex = 0;

u59.style.cursor = 'pointer';
$axure.eventManager.click('u59', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u59'] = 'top';gv_vAlignTable['u137'] = 'center';u244.tabIndex = 0;

u244.style.cursor = 'pointer';
$axure.eventManager.click('u244', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');
function waitud60c4460105243299b524b0b32b428cf1() {

	SetPanelState('u243', 'pd1u243','none','',500,'none','',500);
function waitub3ccdb0e2b0e45289ccb18b7f7d0de481() {
function waitu7d17a4dc47ea4dd0b7636d8a947ae1e31() {
}
setTimeout(waitu7d17a4dc47ea4dd0b7636d8a947ae1e31, 200);
}
setTimeout(waitub3ccdb0e2b0e45289ccb18b7f7d0de481, 200);
}
setTimeout(waitud60c4460105243299b524b0b32b428cf1, 300);

}
});
gv_vAlignTable['u244'] = 'top';document.getElementById('u90_img').tabIndex = 0;

u90.style.cursor = 'pointer';
$axure.eventManager.click('u90', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u18'] = 'top';HookHover('u248', false);
gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u259'] = 'center';document.getElementById('u152_img').tabIndex = 0;

u152.style.cursor = 'pointer';
$axure.eventManager.click('u152', function(e) {

if (true) {

	SetPanelState('u34', 'pd3u34','none','',500,'none','',500);

}
});
gv_vAlignTable['u220'] = 'center';gv_vAlignTable['u107'] = 'center';gv_vAlignTable['u69'] = 'top';gv_vAlignTable['u237'] = 'top';document.getElementById('u180_img').tabIndex = 0;
HookHover('u180', false);

u180.style.cursor = 'pointer';
$axure.eventManager.click('u180', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
document.getElementById('u28_img').tabIndex = 0;

u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u194'] = 'center';