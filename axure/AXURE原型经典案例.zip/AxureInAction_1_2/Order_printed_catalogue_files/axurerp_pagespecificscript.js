﻿for(var i = 0; i < 224; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

SetWidgetSelected('u14');
SetWidgetSelected('u98');
	var obj1 = document.getElementById("u127");
    obj1.focus();

}

if ((GetGlobalVariableValue('ShoppingBasket')) == ('Empty')) {

	SetPanelState('u46', 'pd0u46','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('1'))) {

SetWidgetRichText('u48', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (1 item)</span></p>');

	SetPanelState('u46', 'pd1u46','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('2'))) {

SetWidgetRichText('u48', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (2 items)</span></p>');

	SetPanelState('u46', 'pd1u46','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('3'))) {

SetWidgetRichText('u48', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (3 items)</span></p>');

	SetPanelState('u46', 'pd1u46','none','',500,'none','',500);

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) {

}

});

function rdo0LoadHome(e) {

}
gv_vAlignTable['u115'] = 'top';gv_vAlignTable['u122'] = 'top';gv_vAlignTable['u21'] = 'center';document.getElementById('u32_img').tabIndex = 0;
HookHover('u32', false);

u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u156'] = 'top';u207.tabIndex = 0;

u207.style.cursor = 'pointer';
$axure.eventManager.click('u207', function(e) {

if (true) {

	NewWindow($axure.globalVariableProvider.getLinkUrl('Terms___conditions.html'), "", "directories=0, height=450, location=0, menubar=0, resizable=0, scrollbars=0, status=0, toolbar=0, width=415", true, 415, 450);

}
});
gv_vAlignTable['u207'] = 'top';
u130.style.cursor = 'pointer';
$axure.eventManager.click('u130', function(e) {

if (true) {

	SetPanelVisibility('u112','hidden','none',500);

}
});

$axure.eventManager.blur('u130', function(e) {

if ((GetGlobalVariableValue('OnLoadVariable')) == ('')) {

}
});
gv_vAlignTable['u7'] = 'center';gv_vAlignTable['u79'] = 'center';document.getElementById('u4_img').tabIndex = 0;
HookHover('u4', false);

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u140'] = 'top';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u135'] = 'top';gv_vAlignTable['u151'] = 'top';gv_vAlignTable['u212'] = 'center';gv_vAlignTable['u159'] = 'top';u101.tabIndex = 0;

u101.style.cursor = 'pointer';
$axure.eventManager.click('u101', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('My_details.html');

}
else
if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('LoginStatus')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u101'] = 'top';u186.tabIndex = 0;

u186.style.cursor = 'pointer';
$axure.eventManager.click('u186', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u186'] = 'top';HookHover('u14', false);
gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u105'] = 'center';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u138'] = 'top';gv_vAlignTable['u52'] = 'center';document.getElementById('u20_img').tabIndex = 0;
HookHover('u20', false);

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u67'] = 'top';gv_vAlignTable['u120'] = 'top';gv_vAlignTable['u110'] = 'center';document.getElementById('u6_img').tabIndex = 0;
HookHover('u6', false);

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u205'] = 'center';gv_vAlignTable['u37'] = 'center';u141.tabIndex = 0;

u141.style.cursor = 'pointer';
$axure.eventManager.click('u141', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u141'] = 'top';gv_vAlignTable['u11'] = 'center';document.getElementById('u34_img').tabIndex = 0;
HookHover('u34', false);

u34.style.cursor = 'pointer';
$axure.eventManager.click('u34', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
u68.tabIndex = 0;

u68.style.cursor = 'pointer';
$axure.eventManager.click('u68', function(e) {

if (true) {

	SetPanelVisibility('u61','hidden','none',500);

}
});

$axure.eventManager.mouseover('u68', function(e) {
if (!IsTrueMouseOver('u68',e)) return;
if (true) {

	SetPanelVisibility('u64','','none',500);

}
});

$axure.eventManager.mouseout('u68', function(e) {
if (!IsTrueMouseOut('u68',e)) return;
if (true) {

	SetPanelVisibility('u64','hidden','none',500);

}
});
u89.tabIndex = 0;

u89.style.cursor = 'pointer';
$axure.eventManager.click('u89', function(e) {

if (true) {

	SetPanelVisibility('u61','hidden','none',500);

}
});

$axure.eventManager.mouseover('u89', function(e) {
if (!IsTrueMouseOver('u89',e)) return;
if (true) {

	SetPanelVisibility('u77','','none',500);

}
});

$axure.eventManager.mouseout('u89', function(e) {
if (!IsTrueMouseOut('u89',e)) return;
if (true) {

	SetPanelVisibility('u77','hidden','none',500);

}
});
document.getElementById('u47_img').tabIndex = 0;

u47.style.cursor = 'pointer';
$axure.eventManager.click('u47', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}
});
gv_vAlignTable['u213'] = 'top';u184.tabIndex = 0;

u184.style.cursor = 'pointer';
$axure.eventManager.click('u184', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u184'] = 'top';gv_vAlignTable['u99'] = 'center';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u44'] = 'center';u179.tabIndex = 0;

u179.style.cursor = 'pointer';
$axure.eventManager.click('u179', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
gv_vAlignTable['u179'] = 'top';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u191'] = 'top';document.getElementById('u16_img').tabIndex = 0;
HookHover('u16', false);

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u41'] = 'center';u172.tabIndex = 0;

u172.style.cursor = 'pointer';
$axure.eventManager.click('u172', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u172'] = 'top';gv_vAlignTable['u149'] = 'top';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u118'] = 'center';u88.tabIndex = 0;

u88.style.cursor = 'pointer';
$axure.eventManager.click('u88', function(e) {

if (true) {

	SetPanelVisibility('u61','hidden','none',500);

}
});

$axure.eventManager.mouseover('u88', function(e) {
if (!IsTrueMouseOver('u88',e)) return;
if (true) {

	SetPanelVisibility('u74','','none',500);

}
});

$axure.eventManager.mouseout('u88', function(e) {
if (!IsTrueMouseOut('u88',e)) return;
if (true) {

	SetPanelVisibility('u74','hidden','none',500);

}
});
u189.tabIndex = 0;

u189.style.cursor = 'pointer';
$axure.eventManager.click('u189', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u189'] = 'top';document.getElementById('u38_img').tabIndex = 0;
HookHover('u38', false);

u38.style.cursor = 'pointer';
$axure.eventManager.click('u38', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
u176.tabIndex = 0;

u176.style.cursor = 'pointer';
$axure.eventManager.click('u176', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u176'] = 'top';document.getElementById('u26_img').tabIndex = 0;
HookHover('u26', false);

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
u174.tabIndex = 0;

u174.style.cursor = 'pointer';
$axure.eventManager.click('u174', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u174'] = 'top';gv_vAlignTable['u119'] = 'top';gv_vAlignTable['u85'] = 'top';u182.tabIndex = 0;

u182.style.cursor = 'pointer';
$axure.eventManager.click('u182', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u182'] = 'top';document.getElementById('u10_img').tabIndex = 0;
HookHover('u10', false);

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
u100.tabIndex = 0;

u100.style.cursor = 'pointer';
$axure.eventManager.click('u100', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u144'] = 'center';gv_vAlignTable['u202'] = 'center';gv_vAlignTable['u166'] = 'top';gv_vAlignTable['u82'] = 'center';document.getElementById('u36_img').tabIndex = 0;
HookHover('u36', false);

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
document.getElementById('u30_img').tabIndex = 0;
HookHover('u30', false);

u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
u95.tabIndex = 0;

u95.style.cursor = 'pointer';
$axure.eventManager.click('u95', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');

SetGlobalVariableValue('BookPageViewed', '');

SetGlobalVariableValue('CitySelected', '');

SetGlobalVariableValue('LoginStatus', '');

SetGlobalVariableValue('ReviewVar', '');

SetGlobalVariableValue('EmployeesName', '');

	SetPanelState('u93', 'pd1u93','none','',500,'none','',500);
function waituf022ddcb6b474903a282219d39d908ef1() {

	SetPanelState('u93', 'pd0u93','none','',500,'none','',500);
}
setTimeout(waituf022ddcb6b474903a282219d39d908ef1, 4000);

}
});
gv_vAlignTable['u95'] = 'top';gv_vAlignTable['u195'] = 'top';gv_vAlignTable['u158'] = 'top';u223.tabIndex = 0;

u223.style.cursor = 'pointer';
$axure.eventManager.click('u223', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u223'] = 'top';gv_vAlignTable['u114'] = 'center';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u221'] = 'center';u92.tabIndex = 0;

u92.style.cursor = 'pointer';
$axure.eventManager.click('u92', function(e) {

if (true) {

	self.location.href='index.html';

}
});
gv_vAlignTable['u92'] = 'top';u181.tabIndex = 0;

u181.style.cursor = 'pointer';
$axure.eventManager.click('u181', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u181'] = 'top';document.getElementById('u198_img').tabIndex = 0;

u198.style.cursor = 'pointer';
$axure.eventManager.click('u198', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u5'] = 'center';HookHover('u98', false);
document.getElementById('u43_img').tabIndex = 0;

u43.style.cursor = 'pointer';
$axure.eventManager.click('u43', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u169'] = 'center';gv_vAlignTable['u56'] = 'center';
u150.style.cursor = 'pointer';
$axure.eventManager.click('u150', function(e) {

if ((GetCheckState('u150')) == (true)) {

	SetPanelVisibility('u152','hidden','none',500);

	SetPanelVisibility('u219','hidden','none',500);

	MoveWidgetTo('u163', GetNum('184'), GetNum('654'),'none',500);

}
});
u187.tabIndex = 0;

u187.style.cursor = 'pointer';
$axure.eventManager.click('u187', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u187'] = 'top';gv_vAlignTable['u142'] = 'top';u106.tabIndex = 0;

u106.style.cursor = 'pointer';
$axure.eventManager.click('u106', function(e) {

if (true) {

SetWidgetFormText('u126', '18');

SetSelectedOption('u147', ' January');

SetSelectedOption('u125', ' 2009');

	SetPanelVisibility('u103','hidden','none',500);

}
});
document.getElementById('u168_img').tabIndex = 0;

u168.style.cursor = 'pointer';
$axure.eventManager.click('u168', function(e) {

if ((GetWidgetText('u130')) == ('')) {

	SetPanelVisibility('u112','','none',500);

	ScrollToWidget('u222', false,true,'none',500);

}

if ((GetWidgetText('u131')) == ('')) {

	SetPanelVisibility('u116','','none',500);

	ScrollToWidget('u222', false,true,'none',500);

}

if ((GetPanelState('u108')) == ('pd0u108')) {

	SetPanelVisibility('u116','','none',500);

	ScrollToWidget('u222', false,true,'none',500);

}
else
if (((GetWidgetText('u130')) != ('')) && (((GetWidgetText('u131')) != ('')) && ((GetPanelState('u108')) != ('pd0u108')))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Thank_you_page.html');

}
});
gv_vAlignTable['u154'] = 'top';
u139.style.cursor = 'pointer';
$axure.eventManager.click('u139', function(e) {

if (true) {

	SetPanelVisibility('u108','hidden','none',500);

}
});

$axure.eventManager.keyup('u139', function(e) {

if (((GetWidgetText('u139')) > Number('9999')) || (IsValueAlpha(GetWidgetText('u139')))) {

	SetPanelVisibility('u108','','none',500);

}

if (((GetWidgetText('u139')) <= Number('9999')) && (IsValueNumeric(GetWidgetText('u139')))) {

	SetPanelVisibility('u108','hidden','none',500);

}

if ((GetWidgetText('u139')) == ('')) {

	SetPanelVisibility('u108','hidden','none',500);

}
});
gv_vAlignTable['u87'] = 'top';gv_vAlignTable['u193'] = 'top';
u121.style.cursor = 'pointer';
$axure.eventManager.click('u121', function(e) {

if ((GetCheckState('u121')) == (true)) {

	var obj1 = document.getElementById("u137");
    obj1.disabled = false;

}
else
if ((GetCheckState('u121')) != (true)) {

SetWidgetFormText('u137', '');

	var obj1 = document.getElementById("u137");
    obj1.disabled = true;

}
});
gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u206'] = 'top';gv_vAlignTable['u84'] = 'top';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u97'] = 'center';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u134'] = 'top';u177.tabIndex = 0;

u177.style.cursor = 'pointer';
$axure.eventManager.click('u177', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u177'] = 'top';gv_vAlignTable['u128'] = 'top';u94.tabIndex = 0;

u94.style.cursor = 'pointer';
$axure.eventManager.click('u94', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');
function waitud60c4460105243299b524b0b32b428cf1() {

	SetPanelState('u93', 'pd1u93','none','',500,'none','',500);
function waitub3ccdb0e2b0e45289ccb18b7f7d0de481() {
function waitu7d17a4dc47ea4dd0b7636d8a947ae1e31() {
}
setTimeout(waitu7d17a4dc47ea4dd0b7636d8a947ae1e31, 200);
}
setTimeout(waitub3ccdb0e2b0e45289ccb18b7f7d0de481, 200);
}
setTimeout(waitud60c4460105243299b524b0b32b428cf1, 300);

}
});
gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u60'] = 'center';u190.tabIndex = 0;

u190.style.cursor = 'pointer';
$axure.eventManager.click('u190', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u190'] = 'top';u185.tabIndex = 0;

u185.style.cursor = 'pointer';
$axure.eventManager.click('u185', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u185'] = 'top';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u73'] = 'center';
$axure.eventManager.keyup('u91', function(e) {

if ((GetWidgetText('u91')) == ('')) {

	SetPanelVisibility('u61','hidden','none',500);

}
else
if (true) {

	SetPanelState('u61', 'pd0u61','none','',500,'none','',500);

SetGlobalVariableValue('IncrementalSearchVar', GetWidgetText('u91'));

SetWidgetRichText('u83', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dada</span></p>');

SetWidgetRichText('u84', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dat</span></p>');

SetWidgetRichText('u85', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">gi</span></p>');

SetWidgetRichText('u87', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

SetWidgetRichText('u67', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

	SetPanelVisibility('u61','','none',500);

	BringToFront("u61");
function waitu796b5745765043a58e9fe38835b455f51() {

	SetPanelState('u61', 'pd1u61','none','',500,'none','',500);
}
setTimeout(waitu796b5745765043a58e9fe38835b455f51, 2000);

}
});

$axure.eventManager.blur('u91', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u91'));

}
});

u131.style.cursor = 'pointer';
$axure.eventManager.click('u131', function(e) {

if (true) {

	SetPanelVisibility('u116','hidden','none',500);

}
});
gv_vAlignTable['u70'] = 'center';document.getElementById('u24_img').tabIndex = 0;
HookHover('u24', false);

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
u188.tabIndex = 0;

u188.style.cursor = 'pointer';
$axure.eventManager.click('u188', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u188'] = 'top';gv_vAlignTable['u23'] = 'center';gv_vAlignTable['u210'] = 'center';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u111'] = 'top';gv_vAlignTable['u132'] = 'top';u175.tabIndex = 0;

u175.style.cursor = 'pointer';
$axure.eventManager.click('u175', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u175'] = 'top';gv_vAlignTable['u217'] = 'center';gv_vAlignTable['u129'] = 'top';u86.tabIndex = 0;

u86.style.cursor = 'pointer';
$axure.eventManager.click('u86', function(e) {

if (true) {

	SetPanelVisibility('u61','hidden','none',500);

}
});

$axure.eventManager.mouseover('u86', function(e) {
if (!IsTrueMouseOver('u86',e)) return;
if (true) {

	SetPanelVisibility('u71','','none',500);

}
});

$axure.eventManager.mouseout('u86', function(e) {
if (!IsTrueMouseOut('u86',e)) return;
if (true) {

	SetPanelVisibility('u71','hidden','none',500);

}
});
gv_vAlignTable['u58'] = 'top';u183.tabIndex = 0;

u183.style.cursor = 'pointer';
$axure.eventManager.click('u183', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u183'] = 'top';u173.tabIndex = 0;

u173.style.cursor = 'pointer';
$axure.eventManager.click('u173', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u173'] = 'top';gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u171'] = 'center';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u83'] = 'top';u178.tabIndex = 0;

u178.style.cursor = 'pointer';
$axure.eventManager.click('u178', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u178'] = 'top';document.getElementById('u8_img').tabIndex = 0;
HookHover('u8', false);

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u3'] = 'center';document.getElementById('u96_img').tabIndex = 0;

u96.style.cursor = 'pointer';
$axure.eventManager.click('u96', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u146'] = 'center';u196.tabIndex = 0;

u196.style.cursor = 'pointer';
$axure.eventManager.click('u196', function(e) {

if (true) {

	self.location.href='http://www.lucabenazzi.eu';

}
});
gv_vAlignTable['u15'] = 'center';document.getElementById('u49_img').tabIndex = 0;

u49.style.cursor = 'pointer';
$axure.eventManager.click('u49', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}

if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('OnLoadVariable')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u124'] = 'top';gv_vAlignTable['u1'] = 'center';
u148.style.cursor = 'pointer';
$axure.eventManager.click('u148', function(e) {

if ((GetCheckState('u148')) == (true)) {

	SetPanelVisibility('u152','','none',500);

	SetPanelVisibility('u219','','none',500);

	MoveWidgetTo('u163', GetNum('184'), GetNum('800'),'none',500);

}
});
gv_vAlignTable['u167'] = 'top';document.getElementById('u145_img').tabIndex = 0;

u145.style.cursor = 'pointer';
$axure.eventManager.click('u145', function(e) {

if (true) {

	SetPanelVisibility('u208','toggle','none',500);

}
});
document.getElementById('u12_img').tabIndex = 0;
HookHover('u12', false);

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u199'] = 'center';gv_vAlignTable['u25'] = 'center';document.getElementById('u59_img').tabIndex = 0;

u59.style.cursor = 'pointer';
$axure.eventManager.click('u59', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u91'));

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Search_results.html');

}
});
gv_vAlignTable['u215'] = 'center';u90.tabIndex = 0;

u90.style.cursor = 'pointer';
$axure.eventManager.click('u90', function(e) {

if (true) {

	SetPanelVisibility('u61','hidden','none',500);

}
});

$axure.eventManager.mouseover('u90', function(e) {
if (!IsTrueMouseOver('u90',e)) return;
if (true) {

	SetPanelVisibility('u80','','none',500);

}
});

$axure.eventManager.mouseout('u90', function(e) {
if (!IsTrueMouseOut('u90',e)) return;
if (true) {

	SetPanelVisibility('u80','hidden','none',500);

}
});
document.getElementById('u18_img').tabIndex = 0;
HookHover('u18', false);

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u161'] = 'top';document.getElementById('u22_img').tabIndex = 0;
HookHover('u22', false);

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
document.getElementById('u143_img').tabIndex = 0;

u143.style.cursor = 'pointer';
$axure.eventManager.click('u143', function(e) {

if (true) {

	SetPanelVisibility('u103','toggle','none',500);

	BringToFront("u103");

}
});
u107.tabIndex = 0;

u107.style.cursor = 'pointer';
$axure.eventManager.click('u107', function(e) {

if (true) {

SetWidgetFormText('u126', '15');

SetSelectedOption('u147', ' February');

SetSelectedOption('u125', ' 2009');

	SetPanelVisibility('u103','hidden','none',500);

}
});
gv_vAlignTable['u162'] = 'top';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u136'] = 'top';u218.tabIndex = 0;

u218.style.cursor = 'pointer';
$axure.eventManager.click('u218', function(e) {

if (true) {

	SetPanelVisibility('u208','hidden','none',500);

}
});
gv_vAlignTable['u218'] = 'top';u180.tabIndex = 0;

u180.style.cursor = 'pointer';
$axure.eventManager.click('u180', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u180'] = 'top';document.getElementById('u28_img').tabIndex = 0;
HookHover('u28', false);

u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u194'] = 'top';