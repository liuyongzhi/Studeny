﻿for(var i = 0; i < 535; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

SetWidgetSelected('u50');
}

if ((GetGlobalVariableValue('ShoppingBasket')) == ('Empty')) {

	SetPanelState('u78', 'pd0u78','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('1'))) {

SetWidgetRichText('u80', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (1 item)</span></p>');

	SetPanelState('u78', 'pd1u78','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('2'))) {

SetWidgetRichText('u80', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (2 items)</span></p>');

	SetPanelState('u78', 'pd1u78','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('3'))) {

SetWidgetRichText('u80', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (3 items)</span></p>');

	SetPanelState('u78', 'pd1u78','none','',500,'none','',500);

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) {

}

});

function rdo1LoadHome(e) {

}
gv_vAlignTable['u370'] = 'center';gv_vAlignTable['u167'] = 'center';gv_vAlignTable['u299'] = 'center';u465.tabIndex = 0;

u465.style.cursor = 'pointer';
$axure.eventManager.click('u465', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
document.getElementById('u36_img').tabIndex = 0;
HookHover('u36', false);

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u438'] = 'center';u400.tabIndex = 0;

u400.style.cursor = 'pointer';
$axure.eventManager.click('u400', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
document.getElementById('u176_img').tabIndex = 0;

u176.style.cursor = 'pointer';
$axure.eventManager.click('u176', function(e) {

if (true) {

	SetPanelState('u178', 'pd5u178','none','',500,'none','',500);

                                EnableImageWidget('u154');
                                EnableImageWidget('u156');
                                EnableImageWidget('u158');
                                EnableImageWidget('u160');
                                EnableImageWidget('u162');
                                DisableImageWidget('u164');
}
});
gv_vAlignTable['u216'] = 'top';u194.tabIndex = 0;

u194.style.cursor = 'pointer';
$axure.eventManager.click('u194', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
document.getElementById('u354_img').tabIndex = 0;

u354.style.cursor = 'pointer';
$axure.eventManager.click('u354', function(e) {

if (true) {

	SetPanelState('u360', 'pd3u360','none','',500,'none','',500);

                                EnableImageWidget('u336');
                                EnableImageWidget('u338');
                                EnableImageWidget('u340');
                                EnableImageWidget('u344');
                                EnableImageWidget('u346');
                                DisableImageWidget('u342');
}
});
gv_vAlignTable['u152'] = 'center';gv_vAlignTable['u450'] = 'center';gv_vAlignTable['u331'] = 'center';gv_vAlignTable['u231'] = 'top';gv_vAlignTable['u347'] = 'center';gv_vAlignTable['u159'] = 'center';document.getElementById('u54_img').tabIndex = 0;
HookHover('u54', false);

u54.style.cursor = 'pointer';
$axure.eventManager.click('u54', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u464'] = 'top';document.getElementById('u139_img').tabIndex = 0;

u139.style.cursor = 'pointer';
$axure.eventManager.click('u139', function(e) {

if (true) {

	SetPanelState('u153', 'pd1u153','none','',500,'none','',500);

	SetPanelState('u360', 'pd0u360','none','',500,'none','',500);

	SetPanelVisibility('u528','hidden','none',500);

                                EnableImageWidget('u137');
                                EnableImageWidget('u141');
                                EnableImageWidget('u143');
                                EnableImageWidget('u145');
                                EnableImageWidget('u147');
                                EnableImageWidget('u149');
                                EnableImageWidget('u151');
                                EnableImageWidget('u338');
                                EnableImageWidget('u340');
                                EnableImageWidget('u342');
                                EnableImageWidget('u344');
                                EnableImageWidget('u346');
                                DisableImageWidget('u139');
                                DisableImageWidget('u336');
}
});
gv_vAlignTable['u201'] = 'center';u526.tabIndex = 0;

u526.style.cursor = 'pointer';
$axure.eventManager.click('u526', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u526'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u215'] = 'top';gv_vAlignTable['u193'] = 'top';u11.tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u11'] = 'top';u126.tabIndex = 0;

u126.style.cursor = 'pointer';
$axure.eventManager.click('u126', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');
function waitud60c4460105243299b524b0b32b428cf1() {

	SetPanelState('u125', 'pd1u125','none','',500,'none','',500);
function waitub3ccdb0e2b0e45289ccb18b7f7d0de481() {
function waitu7d17a4dc47ea4dd0b7636d8a947ae1e31() {
}
setTimeout(waitu7d17a4dc47ea4dd0b7636d8a947ae1e31, 200);
}
setTimeout(waitub3ccdb0e2b0e45289ccb18b7f7d0de481, 200);
}
setTimeout(waitud60c4460105243299b524b0b32b428cf1, 300);

}
});
gv_vAlignTable['u126'] = 'top';gv_vAlignTable['u413'] = 'top';gv_vAlignTable['u391'] = 'top';gv_vAlignTable['u275'] = 'center';document.getElementById('u151_img').tabIndex = 0;

u151.style.cursor = 'pointer';
$axure.eventManager.click('u151', function(e) {

if (true) {

	SetPanelState('u153', 'pd3u153','none','',500,'none','',500);

	SetPanelState('u178', 'pd0u178','none','',500,'none','',500);

	SetPanelVisibility('u528','hidden','none',500);

                                EnableImageWidget('u137');
                                EnableImageWidget('u139');
                                EnableImageWidget('u141');
                                EnableImageWidget('u145');
                                EnableImageWidget('u147');
                                EnableImageWidget('u149');
                                EnableImageWidget('u151');
                                EnableImageWidget('u156');
                                EnableImageWidget('u158');
                                EnableImageWidget('u160');
                                EnableImageWidget('u162');
                                EnableImageWidget('u164');
                                DisableImageWidget('u143');
                                DisableImageWidget('u154');
}
});
gv_vAlignTable['u527'] = 'top';document.getElementById('u346_img').tabIndex = 0;

u346.style.cursor = 'pointer';
$axure.eventManager.click('u346', function(e) {

if (true) {

	SetPanelState('u360', 'pd5u360','none','',500,'none','',500);

                                EnableImageWidget('u336');
                                EnableImageWidget('u338');
                                EnableImageWidget('u340');
                                EnableImageWidget('u342');
                                EnableImageWidget('u344');
                                DisableImageWidget('u346');
}
});
u26.tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href='http://www.lucabenazzi.eu';

}
});
u319.tabIndex = 0;

u319.style.cursor = 'pointer';
$axure.eventManager.click('u319', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
document.getElementById('u158_img').tabIndex = 0;

u158.style.cursor = 'pointer';
$axure.eventManager.click('u158', function(e) {

if (true) {

	SetPanelState('u178', 'pd2u178','none','',500,'none','',500);

                                EnableImageWidget('u154');
                                EnableImageWidget('u156');
                                EnableImageWidget('u160');
                                EnableImageWidget('u162');
                                EnableImageWidget('u164');
                                DisableImageWidget('u158');
}
});
gv_vAlignTable['u463'] = 'top';gv_vAlignTable['u138'] = 'center';u100.tabIndex = 0;

u100.style.cursor = 'pointer';
$axure.eventManager.click('u100', function(e) {

if (true) {

	SetPanelVisibility('u93','hidden','none',500);

}
});

$axure.eventManager.mouseover('u100', function(e) {
if (!IsTrueMouseOver('u100',e)) return;
if (true) {

	SetPanelVisibility('u96','','none',500);

}
});

$axure.eventManager.mouseout('u100', function(e) {
if (!IsTrueMouseOut('u100',e)) return;
if (true) {

	SetPanelVisibility('u96','hidden','none',500);

}
});
gv_vAlignTable['u302'] = 'top';gv_vAlignTable['u477'] = 'top';gv_vAlignTable['u214'] = 'center';gv_vAlignTable['u192'] = 'top';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u412'] = 'top';gv_vAlignTable['u390'] = 'top';gv_vAlignTable['u150'] = 'center';u287.tabIndex = 0;

u287.style.cursor = 'pointer';
$axure.eventManager.click('u287', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u436'] = 'center';gv_vAlignTable['u426'] = 'center';gv_vAlignTable['u345'] = 'center';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u80'] = 'center';gv_vAlignTable['u228'] = 'center';gv_vAlignTable['u462'] = 'top';gv_vAlignTable['u476'] = 'top';gv_vAlignTable['u318'] = 'top';document.getElementById('u449_img').tabIndex = 0;

u449.style.cursor = 'pointer';
$axure.eventManager.click('u449', function(e) {

if (true) {

	SetPanelState('u457', 'pd6u457','none','',500,'none','',500);

                                EnableImageWidget('u425');
                                EnableImageWidget('u429');
                                EnableImageWidget('u433');
                                EnableImageWidget('u437');
                                EnableImageWidget('u441');
                                EnableImageWidget('u445');
                                EnableImageWidget('u453');
                                DisableImageWidget('u449');
}
});
gv_vAlignTable['u411'] = 'top';document.getElementById('u245_img').tabIndex = 0;

u245.style.cursor = 'pointer';
$axure.eventManager.click('u245', function(e) {

if (true) {

	SetPanelState('u271', 'pd1u271','none','',500,'none','',500);

                                EnableImageWidget('u243');
                                EnableImageWidget('u247');
                                EnableImageWidget('u249');
                                EnableImageWidget('u251');
                                EnableImageWidget('u253');
                                EnableImageWidget('u255');
                                DisableImageWidget('u245');
}
});
gv_vAlignTable['u286'] = 'top';document.getElementById('u425_img').tabIndex = 0;

u425.style.cursor = 'pointer';
$axure.eventManager.click('u425', function(e) {

if (true) {

	SetPanelState('u457', 'pd0u457','none','',500,'none','',500);

                                EnableImageWidget('u429');
                                EnableImageWidget('u433');
                                EnableImageWidget('u437');
                                EnableImageWidget('u441');
                                EnableImageWidget('u445');
                                EnableImageWidget('u449');
                                EnableImageWidget('u453');
                                DisableImageWidget('u425');
}
});
document.getElementById('u344_img').tabIndex = 0;

u344.style.cursor = 'pointer';
$axure.eventManager.click('u344', function(e) {

if (true) {

	SetPanelState('u360', 'pd4u360','none','',500,'none','',500);

                                EnableImageWidget('u336');
                                EnableImageWidget('u338');
                                EnableImageWidget('u340');
                                EnableImageWidget('u342');
                                EnableImageWidget('u346');
                                DisableImageWidget('u344');
}
});
gv_vAlignTable['u163'] = 'center';gv_vAlignTable['u461'] = 'center';gv_vAlignTable['u326'] = 'center';gv_vAlignTable['u240'] = 'top';gv_vAlignTable['u177'] = 'center';gv_vAlignTable['u180'] = 'center';gv_vAlignTable['u475'] = 'center';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u410'] = 'center';u186.tabIndex = 0;

u186.style.cursor = 'pointer';
$axure.eventManager.click('u186', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u307'] = 'center';gv_vAlignTable['u285'] = 'top';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u18'] = 'top';document.getElementById('u50_img').tabIndex = 0;
HookHover('u50', false);

u50.style.cursor = 'pointer';
$axure.eventManager.click('u50', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
u424.tabIndex = 0;

u424.style.cursor = 'pointer';
$axure.eventManager.click('u424', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u241'] = 'top';gv_vAlignTable['u502'] = 'top';gv_vAlignTable['u357'] = 'center';document.getElementById('u79_img').tabIndex = 0;

u79.style.cursor = 'pointer';
$axure.eventManager.click('u79', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}
});
gv_vAlignTable['u389'] = 'top';gv_vAlignTable['u55'] = 'center';document.getElementById('u149_img').tabIndex = 0;

u149.style.cursor = 'pointer';
$axure.eventManager.click('u149', function(e) {

if (true) {

	SetPanelState('u153', 'pd2u153','none','',500,'none','',500);

	SetPanelState('u271', 'pd0u271','none','',500,'none','',500);

	SetPanelVisibility('u528','hidden','none',500);

                                EnableImageWidget('u137');
                                EnableImageWidget('u139');
                                EnableImageWidget('u143');
                                EnableImageWidget('u145');
                                EnableImageWidget('u147');
                                EnableImageWidget('u149');
                                EnableImageWidget('u151');
                                EnableImageWidget('u245');
                                EnableImageWidget('u247');
                                EnableImageWidget('u249');
                                EnableImageWidget('u251');
                                EnableImageWidget('u253');
                                EnableImageWidget('u255');
                                DisableImageWidget('u141');
                                DisableImageWidget('u243');
}
});
gv_vAlignTable['u111'] = 'center';gv_vAlignTable['u332'] = 'top';gv_vAlignTable['u289'] = 'center';gv_vAlignTable['u284'] = 'top';u12.tabIndex = 0;

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u423'] = 'top';document.getElementById('u342_img').tabIndex = 0;

u342.style.cursor = 'pointer';
$axure.eventManager.click('u342', function(e) {

if (true) {

	SetPanelState('u360', 'pd3u360','none','',500,'none','',500);

                                EnableImageWidget('u336');
                                EnableImageWidget('u338');
                                EnableImageWidget('u340');
                                EnableImageWidget('u344');
                                EnableImageWidget('u346');
                                DisableImageWidget('u342');
}
});
gv_vAlignTable['u161'] = 'center';gv_vAlignTable['u329'] = 'center';document.getElementById('u437_img').tabIndex = 0;

u437.style.cursor = 'pointer';
$axure.eventManager.click('u437', function(e) {

if (true) {

	SetPanelState('u457', 'pd3u457','none','',500,'none','',500);

                                EnableImageWidget('u425');
                                EnableImageWidget('u429');
                                EnableImageWidget('u433');
                                EnableImageWidget('u441');
                                EnableImageWidget('u445');
                                EnableImageWidget('u449');
                                EnableImageWidget('u453');
                                DisableImageWidget('u437');
}
});
document.getElementById('u356_img').tabIndex = 0;

u356.style.cursor = 'pointer';
$axure.eventManager.click('u356', function(e) {

if (true) {

	SetPanelState('u360', 'pd4u360','none','',500,'none','',500);

                                EnableImageWidget('u336');
                                EnableImageWidget('u338');
                                EnableImageWidget('u340');
                                EnableImageWidget('u342');
                                EnableImageWidget('u346');
                                DisableImageWidget('u344');
}
});
gv_vAlignTable['u63'] = 'center';u473.tabIndex = 0;

u473.style.cursor = 'pointer';
$axure.eventManager.click('u473', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u148'] = 'center';gv_vAlignTable['u305'] = 'center';gv_vAlignTable['u283'] = 'center';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u20'] = 'top';u124.tabIndex = 0;

u124.style.cursor = 'pointer';
$axure.eventManager.click('u124', function(e) {

if (true) {

	self.location.href='index.html';

}
});
gv_vAlignTable['u124'] = 'top';gv_vAlignTable['u422'] = 'top';document.getElementById('u38_img').tabIndex = 0;
HookHover('u38', false);

u38.style.cursor = 'pointer';
$axure.eventManager.click('u38', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
document.getElementById('u160_img').tabIndex = 0;

u160.style.cursor = 'pointer';
$axure.eventManager.click('u160', function(e) {

if (true) {

	SetPanelState('u178', 'pd3u178','none','',500,'none','',500);

                                EnableImageWidget('u154');
                                EnableImageWidget('u156');
                                EnableImageWidget('u158');
                                EnableImageWidget('u162');
                                EnableImageWidget('u164');
                                DisableImageWidget('u160');
}
});
gv_vAlignTable['u297'] = 'center';u8.tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u355'] = 'center';document.getElementById('u66_img').tabIndex = 0;
HookHover('u66', false);

u66.style.cursor = 'pointer';
$axure.eventManager.click('u66', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u25'] = 'top';document.getElementById('u81_img').tabIndex = 0;

u81.style.cursor = 'pointer';
$axure.eventManager.click('u81', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}

if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('OnLoadVariable')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u217'] = 'top';gv_vAlignTable['u472'] = 'top';gv_vAlignTable['u198'] = 'top';gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u76'] = 'center';
$axure.eventManager.keyup('u123', function(e) {

if ((GetWidgetText('u123')) == ('')) {

	SetPanelVisibility('u93','hidden','none',500);

}
else
if (true) {

	SetPanelState('u93', 'pd0u93','none','',500,'none','',500);

SetGlobalVariableValue('IncrementalSearchVar', GetWidgetText('u123'));

SetWidgetRichText('u115', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dada</span></p>');

SetWidgetRichText('u116', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dat</span></p>');

SetWidgetRichText('u117', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">gi</span></p>');

SetWidgetRichText('u119', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

SetWidgetRichText('u99', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

	SetPanelVisibility('u93','','none',500);

	BringToFront("u93");
function waitu796b5745765043a58e9fe38835b455f51() {

	SetPanelState('u93', 'pd1u93','none','',500,'none','',500);
}
setTimeout(waitu796b5745765043a58e9fe38835b455f51, 2000);

}
});

$axure.eventManager.blur('u123', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u123'));

}
});
gv_vAlignTable['u191'] = 'top';gv_vAlignTable['u421'] = 'top';document.getElementById('u137_img').tabIndex = 0;

u137.style.cursor = 'pointer';
$axure.eventManager.click('u137', function(e) {

if (true) {

	SetPanelState('u153', 'pd0u153','none','',500,'none','',500);

	SetPanelState('u457', 'pd0u457','none','',500,'none','',500);

	SetPanelVisibility('u528','hidden','none',500);

                                EnableImageWidget('u139');
                                EnableImageWidget('u141');
                                EnableImageWidget('u143');
                                EnableImageWidget('u145');
                                EnableImageWidget('u147');
                                EnableImageWidget('u149');
                                EnableImageWidget('u151');
                                EnableImageWidget('u429');
                                EnableImageWidget('u433');
                                EnableImageWidget('u437');
                                EnableImageWidget('u441');
                                EnableImageWidget('u445');
                                EnableImageWidget('u449');
                                EnableImageWidget('u453');
                                DisableImageWidget('u137');
                                DisableImageWidget('u425');
}
});
document.getElementById('u435_img').tabIndex = 0;

u435.style.cursor = 'pointer';
$axure.eventManager.click('u435', function(e) {

if (true) {

	SetPanelState('u457', 'pd2u457','none','',500,'none','',500);

                                EnableImageWidget('u425');
                                EnableImageWidget('u429');
                                EnableImageWidget('u437');
                                EnableImageWidget('u441');
                                EnableImageWidget('u445');
                                EnableImageWidget('u449');
                                EnableImageWidget('u453');
                                DisableImageWidget('u433');
}
});
u408.tabIndex = 0;

u408.style.cursor = 'pointer';
$axure.eventManager.click('u408', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u173'] = 'center';gv_vAlignTable['u471'] = 'top';gv_vAlignTable['u343'] = 'center';gv_vAlignTable['u290'] = 'top';gv_vAlignTable['u364'] = 'center';u303.tabIndex = 0;

u303.style.cursor = 'pointer';
$axure.eventManager.click('u303', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u281'] = 'center';u122.tabIndex = 0;

u122.style.cursor = 'pointer';
$axure.eventManager.click('u122', function(e) {

if (true) {

	SetPanelVisibility('u93','hidden','none',500);

}
});

$axure.eventManager.mouseover('u122', function(e) {
if (!IsTrueMouseOver('u122',e)) return;
if (true) {

	SetPanelVisibility('u112','','none',500);

}
});

$axure.eventManager.mouseout('u122', function(e) {
if (!IsTrueMouseOut('u122',e)) return;
if (true) {

	SetPanelVisibility('u112','hidden','none',500);

}
});
document.getElementById('u358_img').tabIndex = 0;

u358.style.cursor = 'pointer';
$axure.eventManager.click('u358', function(e) {

if (true) {

	SetPanelState('u360', 'pd5u360','none','',500,'none','',500);

                                EnableImageWidget('u336');
                                EnableImageWidget('u338');
                                EnableImageWidget('u340');
                                EnableImageWidget('u342');
                                EnableImageWidget('u344');
                                DisableImageWidget('u346');
}
});
gv_vAlignTable['u420'] = 'center';u5.tabIndex = 0;

u5.style.cursor = 'pointer';
$axure.eventManager.click('u5', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u268'] = 'center';gv_vAlignTable['u317'] = 'top';u295.tabIndex = 0;

u295.style.cursor = 'pointer';
$axure.eventManager.click('u295', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u136'] = 'center';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u434'] = 'center';document.getElementById('u253_img').tabIndex = 0;

u253.style.cursor = 'pointer';
$axure.eventManager.click('u253', function(e) {

if (true) {

	SetPanelState('u271', 'pd5u271','none','',500,'none','',500);

                                EnableImageWidget('u243');
                                EnableImageWidget('u245');
                                EnableImageWidget('u247');
                                EnableImageWidget('u249');
                                EnableImageWidget('u251');
                                EnableImageWidget('u255');
                                DisableImageWidget('u253');
}
});
document.getElementById('u172_img').tabIndex = 0;

u172.style.cursor = 'pointer';
$axure.eventManager.click('u172', function(e) {

if (true) {

	SetPanelState('u178', 'pd3u178','none','',500,'none','',500);

                                EnableImageWidget('u154');
                                EnableImageWidget('u156');
                                EnableImageWidget('u158');
                                EnableImageWidget('u162');
                                EnableImageWidget('u164');
                                DisableImageWidget('u160');
}
});
gv_vAlignTable['u470'] = 'top';document.getElementById('u267_img').tabIndex = 0;

u267.style.cursor = 'pointer';
$axure.eventManager.click('u267', function(e) {

if (true) {

	SetPanelState('u271', 'pd5u271','none','',500,'none','',500);

                                EnableImageWidget('u243');
                                EnableImageWidget('u245');
                                EnableImageWidget('u247');
                                EnableImageWidget('u249');
                                EnableImageWidget('u251');
                                EnableImageWidget('u255');
                                DisableImageWidget('u253');
}
});
gv_vAlignTable['u399'] = 'top';gv_vAlignTable['u229'] = 'top';HookHover('u46', false);
gv_vAlignTable['u378'] = 'center';u121.tabIndex = 0;

u121.style.cursor = 'pointer';
$axure.eventManager.click('u121', function(e) {

if (true) {

	SetPanelVisibility('u93','hidden','none',500);

}
});

$axure.eventManager.mouseover('u121', function(e) {
if (!IsTrueMouseOver('u121',e)) return;
if (true) {

	SetPanelVisibility('u109','','none',500);

}
});

$axure.eventManager.mouseout('u121', function(e) {
if (!IsTrueMouseOut('u121',e)) return;
if (true) {

	SetPanelVisibility('u109','hidden','none',500);

}
});
gv_vAlignTable['u509'] = 'top';gv_vAlignTable['u316'] = 'top';gv_vAlignTable['u65'] = 'center';document.getElementById('u433_img').tabIndex = 0;

u433.style.cursor = 'pointer';
$axure.eventManager.click('u433', function(e) {

if (true) {

	SetPanelState('u457', 'pd2u457','none','',500,'none','',500);

                                EnableImageWidget('u425');
                                EnableImageWidget('u429');
                                EnableImageWidget('u437');
                                EnableImageWidget('u441');
                                EnableImageWidget('u445');
                                EnableImageWidget('u449');
                                EnableImageWidget('u453');
                                DisableImageWidget('u433');
}
});
gv_vAlignTable['u108'] = 'center';gv_vAlignTable['u252'] = 'center';gv_vAlignTable['u171'] = 'center';gv_vAlignTable['u21'] = 'top';document.getElementById('u447_img').tabIndex = 0;

u447.style.cursor = 'pointer';
$axure.eventManager.click('u447', function(e) {

if (true) {

	SetPanelState('u457', 'pd5u457','none','',500,'none','',500);

                                EnableImageWidget('u425');
                                EnableImageWidget('u429');
                                EnableImageWidget('u433');
                                EnableImageWidget('u437');
                                EnableImageWidget('u441');
                                EnableImageWidget('u449');
                                EnableImageWidget('u453');
                                DisableImageWidget('u445');
}
});
gv_vAlignTable['u533'] = 'center';gv_vAlignTable['u266'] = 'center';document.getElementById('u64_img').tabIndex = 0;
HookHover('u64', false);

u64.style.cursor = 'pointer';
$axure.eventManager.click('u64', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u239'] = 'top';gv_vAlignTable['u301'] = 'top';u120.tabIndex = 0;

u120.style.cursor = 'pointer';
$axure.eventManager.click('u120', function(e) {

if (true) {

	SetPanelVisibility('u93','hidden','none',500);

}
});

$axure.eventManager.mouseover('u120', function(e) {
if (!IsTrueMouseOver('u120',e)) return;
if (true) {

	SetPanelVisibility('u106','','none',500);

}
});

$axure.eventManager.mouseout('u120', function(e) {
if (!IsTrueMouseOut('u120',e)) return;
if (true) {

	SetPanelVisibility('u106','hidden','none',500);

}
});
u2.tabIndex = 0;

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u169'] = 'center';gv_vAlignTable['u315'] = 'center';u513.tabIndex = 0;

u513.style.cursor = 'pointer';
$axure.eventManager.click('u513', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u491'] = 'center';document.getElementById('u162_img').tabIndex = 0;

u162.style.cursor = 'pointer';
$axure.eventManager.click('u162', function(e) {

if (true) {

	SetPanelState('u178', 'pd4u178','none','',500,'none','',500);

                                EnableImageWidget('u154');
                                EnableImageWidget('u156');
                                EnableImageWidget('u158');
                                EnableImageWidget('u160');
                                EnableImageWidget('u164');
                                DisableImageWidget('u162');
}
});
document.getElementById('u251_img').tabIndex = 0;

u251.style.cursor = 'pointer';
$axure.eventManager.click('u251', function(e) {

if (true) {

	SetPanelState('u271', 'pd4u271','none','',500,'none','',500);

                                EnableImageWidget('u243');
                                EnableImageWidget('u245');
                                EnableImageWidget('u247');
                                EnableImageWidget('u249');
                                EnableImageWidget('u253');
                                EnableImageWidget('u255');
                                DisableImageWidget('u251');
}
});
document.getElementById('u170_img').tabIndex = 0;

u170.style.cursor = 'pointer';
$axure.eventManager.click('u170', function(e) {

if (true) {

	SetPanelState('u178', 'pd2u178','none','',500,'none','',500);

                                EnableImageWidget('u154');
                                EnableImageWidget('u156');
                                EnableImageWidget('u160');
                                EnableImageWidget('u162');
                                EnableImageWidget('u164');
                                DisableImageWidget('u158');
}
});
gv_vAlignTable['u496'] = 'top';gv_vAlignTable['u224'] = 'top';gv_vAlignTable['u446'] = 'center';gv_vAlignTable['u373'] = 'top';gv_vAlignTable['u82'] = 'center';u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u238'] = 'center';gv_vAlignTable['u365'] = 'top';u279.tabIndex = 0;

u279.style.cursor = 'pointer';
$axure.eventManager.click('u279', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u292'] = 'top';u133.tabIndex = 0;

u133.style.cursor = 'pointer';
$axure.eventManager.click('u133', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('My_details.html');

}
else
if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('LoginStatus')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u133'] = 'top';gv_vAlignTable['u512'] = 'center';document.getElementById('u431_img').tabIndex = 0;

u431.style.cursor = 'pointer';
$axure.eventManager.click('u431', function(e) {

if (true) {

	SetPanelState('u457', 'pd0u457','none','',500,'none','',500);

                                EnableImageWidget('u429');
                                EnableImageWidget('u433');
                                EnableImageWidget('u437');
                                EnableImageWidget('u441');
                                EnableImageWidget('u445');
                                EnableImageWidget('u449');
                                EnableImageWidget('u453');
                                DisableImageWidget('u425');
}
});
gv_vAlignTable['u250'] = 'center';document.getElementById('u147_img').tabIndex = 0;

u147.style.cursor = 'pointer';
$axure.eventManager.click('u147', function(e) {

if (true) {

	SetPanelState('u153', 'pd1u153','none','',500,'none','',500);

	SetPanelState('u360', 'pd0u360','none','',500,'none','',500);

	SetPanelVisibility('u528','hidden','none',500);

                                EnableImageWidget('u137');
                                EnableImageWidget('u141');
                                EnableImageWidget('u143');
                                EnableImageWidget('u145');
                                EnableImageWidget('u147');
                                EnableImageWidget('u149');
                                EnableImageWidget('u151');
                                EnableImageWidget('u338');
                                EnableImageWidget('u340');
                                EnableImageWidget('u342');
                                EnableImageWidget('u344');
                                EnableImageWidget('u346');
                                DisableImageWidget('u139');
                                DisableImageWidget('u336');
}
});
document.getElementById('u58_img').tabIndex = 0;
HookHover('u58', false);

u58.style.cursor = 'pointer';
$axure.eventManager.click('u58', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
document.getElementById('u445_img').tabIndex = 0;

u445.style.cursor = 'pointer';
$axure.eventManager.click('u445', function(e) {

if (true) {

	SetPanelState('u457', 'pd5u457','none','',500,'none','',500);

                                EnableImageWidget('u425');
                                EnableImageWidget('u429');
                                EnableImageWidget('u433');
                                EnableImageWidget('u437');
                                EnableImageWidget('u441');
                                EnableImageWidget('u449');
                                EnableImageWidget('u453');
                                DisableImageWidget('u445');
}
});
gv_vAlignTable['u90'] = 'top';u327.tabIndex = 0;

u327.style.cursor = 'pointer';
$axure.eventManager.click('u327', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
document.getElementById('u164_img').tabIndex = 0;

u164.style.cursor = 'pointer';
$axure.eventManager.click('u164', function(e) {

if (true) {

	SetPanelState('u178', 'pd5u178','none','',500,'none','',500);

                                EnableImageWidget('u154');
                                EnableImageWidget('u156');
                                EnableImageWidget('u158');
                                EnableImageWidget('u160');
                                EnableImageWidget('u162');
                                DisableImageWidget('u164');
}
});
gv_vAlignTable['u95'] = 'center';u132.tabIndex = 0;

u132.style.cursor = 'pointer';
$axure.eventManager.click('u132', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u430'] = 'center';gv_vAlignTable['u386'] = 'center';gv_vAlignTable['u146'] = 'center';document.getElementById('u52_img').tabIndex = 0;
HookHover('u52', false);

u52.style.cursor = 'pointer';
$axure.eventManager.click('u52', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u444'] = 'center';document.getElementById('u263_img').tabIndex = 0;

u263.style.cursor = 'pointer';
$axure.eventManager.click('u263', function(e) {

if (true) {

	SetPanelState('u271', 'pd3u271','none','',500,'none','',500);

                                EnableImageWidget('u243');
                                EnableImageWidget('u245');
                                EnableImageWidget('u247');
                                EnableImageWidget('u251');
                                EnableImageWidget('u253');
                                EnableImageWidget('u255');
                                DisableImageWidget('u249');
}
});
document.getElementById('u48_img').tabIndex = 0;
HookHover('u48', false);

u48.style.cursor = 'pointer';
$axure.eventManager.click('u48', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u459'] = 'center';gv_vAlignTable['u277'] = 'top';gv_vAlignTable['u388'] = 'center';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u212'] = 'center';gv_vAlignTable['u131'] = 'center';gv_vAlignTable['u510'] = 'top';gv_vAlignTable['u407'] = 'top';document.getElementById('u28_img').tabIndex = 0;

u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
document.getElementById('u145_img').tabIndex = 0;

u145.style.cursor = 'pointer';
$axure.eventManager.click('u145', function(e) {

if (true) {

	SetPanelState('u153', 'pd0u153','none','',500,'none','',500);

	SetPanelState('u457', 'pd0u457','none','',500,'none','',500);

	SetPanelVisibility('u528','hidden','none',500);

                                EnableImageWidget('u139');
                                EnableImageWidget('u141');
                                EnableImageWidget('u143');
                                EnableImageWidget('u145');
                                EnableImageWidget('u147');
                                EnableImageWidget('u149');
                                EnableImageWidget('u151');
                                EnableImageWidget('u429');
                                EnableImageWidget('u433');
                                EnableImageWidget('u437');
                                EnableImageWidget('u441');
                                EnableImageWidget('u445');
                                EnableImageWidget('u449');
                                EnableImageWidget('u453');
                                DisableImageWidget('u137');
                                DisableImageWidget('u425');
}
});
gv_vAlignTable['u524'] = 'top';document.getElementById('u443_img').tabIndex = 0;

u443.style.cursor = 'pointer';
$axure.eventManager.click('u443', function(e) {

if (true) {

	SetPanelState('u457', 'pd4u457','none','',500,'none','',500);

                                EnableImageWidget('u425');
                                EnableImageWidget('u429');
                                EnableImageWidget('u433');
                                EnableImageWidget('u437');
                                EnableImageWidget('u445');
                                EnableImageWidget('u449');
                                EnableImageWidget('u453');
                                DisableImageWidget('u441');
}
});
u118.tabIndex = 0;

u118.style.cursor = 'pointer';
$axure.eventManager.click('u118', function(e) {

if (true) {

	SetPanelVisibility('u93','hidden','none',500);

}
});

$axure.eventManager.mouseover('u118', function(e) {
if (!IsTrueMouseOver('u118',e)) return;
if (true) {

	SetPanelVisibility('u103','','none',500);

}
});

$axure.eventManager.mouseout('u118', function(e) {
if (!IsTrueMouseOut('u118',e)) return;
if (true) {

	SetPanelVisibility('u103','hidden','none',500);

}
});
gv_vAlignTable['u262'] = 'center';gv_vAlignTable['u254'] = 'center';gv_vAlignTable['u236'] = 'center';u489.tabIndex = 0;

u489.style.cursor = 'pointer';
$axure.eventManager.click('u489', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u89'] = 'top';document.getElementById('u249_img').tabIndex = 0;

u249.style.cursor = 'pointer';
$axure.eventManager.click('u249', function(e) {

if (true) {

	SetPanelState('u271', 'pd3u271','none','',500,'none','',500);

                                EnableImageWidget('u243');
                                EnableImageWidget('u245');
                                EnableImageWidget('u247');
                                EnableImageWidget('u251');
                                EnableImageWidget('u253');
                                EnableImageWidget('u255');
                                DisableImageWidget('u249');
}
});
HookHover('u130', false);
gv_vAlignTable['u39'] = 'center';gv_vAlignTable['u406'] = 'top';u384.tabIndex = 0;

u384.style.cursor = 'pointer';
$axure.eventManager.click('u384', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u144'] = 'center';gv_vAlignTable['u523'] = 'center';gv_vAlignTable['u442'] = 'center';document.getElementById('u261_img').tabIndex = 0;

u261.style.cursor = 'pointer';
$axure.eventManager.click('u261', function(e) {

if (true) {

	SetPanelState('u271', 'pd2u271','none','',500,'none','',500);

                                EnableImageWidget('u243');
                                EnableImageWidget('u245');
                                EnableImageWidget('u249');
                                EnableImageWidget('u251');
                                EnableImageWidget('u253');
                                EnableImageWidget('u255');
                                DisableImageWidget('u247');
}
});
gv_vAlignTable['u264'] = 'center';gv_vAlignTable['u175'] = 'center';gv_vAlignTable['u456'] = 'center';gv_vAlignTable['u488'] = 'top';gv_vAlignTable['u260'] = 'center';u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u248'] = 'center';u210.tabIndex = 0;

u210.style.cursor = 'pointer';
$axure.eventManager.click('u210', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u405'] = 'top';gv_vAlignTable['u383'] = 'center';gv_vAlignTable['u294'] = 'center';document.getElementById('u143_img').tabIndex = 0;

u143.style.cursor = 'pointer';
$axure.eventManager.click('u143', function(e) {

if (true) {

	SetPanelState('u153', 'pd3u153','none','',500,'none','',500);

	SetPanelState('u178', 'pd0u178','none','',500,'none','',500);

	SetPanelVisibility('u528','hidden','none',500);

                                EnableImageWidget('u137');
                                EnableImageWidget('u139');
                                EnableImageWidget('u141');
                                EnableImageWidget('u145');
                                EnableImageWidget('u147');
                                EnableImageWidget('u149');
                                EnableImageWidget('u151');
                                EnableImageWidget('u156');
                                EnableImageWidget('u158');
                                EnableImageWidget('u160');
                                EnableImageWidget('u162');
                                EnableImageWidget('u164');
                                DisableImageWidget('u143');
                                DisableImageWidget('u154');
}
});
gv_vAlignTable['u379'] = 'top';gv_vAlignTable['u341'] = 'center';gv_vAlignTable['u397'] = 'top';u9.tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
gv_vAlignTable['u9'] = 'top';gv_vAlignTable['u157'] = 'center';gv_vAlignTable['u59'] = 'center';document.getElementById('u455_img').tabIndex = 0;

u455.style.cursor = 'pointer';
$axure.eventManager.click('u455', function(e) {

if (true) {

	SetPanelState('u457', 'pd7u457','none','',500,'none','',500);

                                EnableImageWidget('u425');
                                EnableImageWidget('u429');
                                EnableImageWidget('u433');
                                EnableImageWidget('u437');
                                EnableImageWidget('u441');
                                EnableImageWidget('u445');
                                EnableImageWidget('u449');
                                DisableImageWidget('u453');
}
});
gv_vAlignTable['u35'] = 'center';document.getElementById('u91_img').tabIndex = 0;

u91.style.cursor = 'pointer';
$axure.eventManager.click('u91', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u123'));

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Search_results.html');

}
});
gv_vAlignTable['u309'] = 'top';gv_vAlignTable['u501'] = 'center';gv_vAlignTable['u404'] = 'center';gv_vAlignTable['u223'] = 'top';gv_vAlignTable['u142'] = 'center';u521.tabIndex = 0;

u521.style.cursor = 'pointer';
$axure.eventManager.click('u521', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
document.getElementById('u265_img').tabIndex = 0;

u265.style.cursor = 'pointer';
$axure.eventManager.click('u265', function(e) {

if (true) {

	SetPanelState('u271', 'pd4u271','none','',500,'none','',500);

                                EnableImageWidget('u243');
                                EnableImageWidget('u245');
                                EnableImageWidget('u247');
                                EnableImageWidget('u249');
                                EnableImageWidget('u253');
                                EnableImageWidget('u255');
                                DisableImageWidget('u251');
}
});
document.getElementById('u340_img').tabIndex = 0;

u340.style.cursor = 'pointer';
$axure.eventManager.click('u340', function(e) {

if (true) {

	SetPanelState('u360', 'pd2u360','none','',500,'none','',500);

                                EnableImageWidget('u336');
                                EnableImageWidget('u338');
                                EnableImageWidget('u342');
                                EnableImageWidget('u344');
                                EnableImageWidget('u346');
                                DisableImageWidget('u340');
}
});
gv_vAlignTable['u396'] = 'center';document.getElementById('u156_img').tabIndex = 0;

u156.style.cursor = 'pointer';
$axure.eventManager.click('u156', function(e) {

if (true) {

	SetPanelState('u178', 'pd1u178','none','',500,'none','',500);

                                EnableImageWidget('u154');
                                EnableImageWidget('u158');
                                EnableImageWidget('u160');
                                EnableImageWidget('u162');
                                EnableImageWidget('u164');
                                DisableImageWidget('u156');
}
});
gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u508'] = 'top';gv_vAlignTable['u273'] = 'center';document.getElementById('u60_img').tabIndex = 0;
HookHover('u60', false);

u60.style.cursor = 'pointer';
$axure.eventManager.click('u60', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
u202.tabIndex = 0;

u202.style.cursor = 'pointer';
$axure.eventManager.click('u202', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u105'] = 'center';gv_vAlignTable['u381'] = 'top';gv_vAlignTable['u222'] = 'center';gv_vAlignTable['u520'] = 'top';u6.tabIndex = 0;

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u534'] = 'top';gv_vAlignTable['u209'] = 'top';u525.tabIndex = 0;

u525.style.cursor = 'pointer';
$axure.eventManager.click('u525', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u525'] = 'top';gv_vAlignTable['u353'] = 'center';gv_vAlignTable['u402'] = 'center';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u367'] = 'top';gv_vAlignTable['u499'] = 'center';document.getElementById('u56_img').tabIndex = 0;
HookHover('u56', false);

u56.style.cursor = 'pointer';
$axure.eventManager.click('u56', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u380'] = 'top';gv_vAlignTable['u86'] = 'center';document.getElementById('u168_img').tabIndex = 0;

u168.style.cursor = 'pointer';
$axure.eventManager.click('u168', function(e) {

if (true) {

	SetPanelState('u178', 'pd1u178','none','',500,'none','',500);

                                EnableImageWidget('u154');
                                EnableImageWidget('u158');
                                EnableImageWidget('u160');
                                EnableImageWidget('u162');
                                EnableImageWidget('u164');
                                DisableImageWidget('u156');
}
});
gv_vAlignTable['u119'] = 'top';document.getElementById('u166_img').tabIndex = 0;

u166.style.cursor = 'pointer';
$axure.eventManager.click('u166', function(e) {

if (true) {

	SetPanelState('u178', 'pd0u178','none','',500,'none','',500);

                                EnableImageWidget('u156');
                                EnableImageWidget('u158');
                                EnableImageWidget('u160');
                                EnableImageWidget('u162');
                                EnableImageWidget('u164');
                                DisableImageWidget('u154');
}
});
u416.tabIndex = 0;

u416.style.cursor = 'pointer';
$axure.eventManager.click('u416', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u394'] = 'center';document.getElementById('u75_img').tabIndex = 0;

u75.style.cursor = 'pointer';
$axure.eventManager.click('u75', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u208'] = 'top';document.getElementById('u352_img').tabIndex = 0;

u352.style.cursor = 'pointer';
$axure.eventManager.click('u352', function(e) {

if (true) {

	SetPanelState('u360', 'pd2u360','none','',500,'none','',500);

                                EnableImageWidget('u336');
                                EnableImageWidget('u338');
                                EnableImageWidget('u342');
                                EnableImageWidget('u344');
                                EnableImageWidget('u346');
                                DisableImageWidget('u340');
}
});
gv_vAlignTable['u418'] = 'center';u531.tabIndex = 0;

u531.style.cursor = 'pointer';
$axure.eventManager.click('u531', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u531'] = 'top';gv_vAlignTable['u366'] = 'top';gv_vAlignTable['u339'] = 'center';gv_vAlignTable['u276'] = 'top';gv_vAlignTable['u220'] = 'center';u3.tabIndex = 0;

u3.style.cursor = 'pointer';
$axure.eventManager.click('u3', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u117'] = 'top';gv_vAlignTable['u415'] = 'center';u234.tabIndex = 0;

u234.style.cursor = 'pointer';
$axure.eventManager.click('u234', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u73'] = 'center';gv_vAlignTable['u351'] = 'center';gv_vAlignTable['u270'] = 'center';gv_vAlignTable['u199'] = 'top';gv_vAlignTable['u519'] = 'top';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u102'] = 'center';document.getElementById('u338_img').tabIndex = 0;

u338.style.cursor = 'pointer';
$axure.eventManager.click('u338', function(e) {

if (true) {

	SetPanelState('u360', 'pd1u360','none','',500,'none','',500);

                                EnableImageWidget('u336');
                                EnableImageWidget('u340');
                                EnableImageWidget('u342');
                                EnableImageWidget('u344');
                                EnableImageWidget('u346');
                                DisableImageWidget('u338');
}
});
gv_vAlignTable['u300'] = 'top';gv_vAlignTable['u116'] = 'top';u392.tabIndex = 0;

u392.style.cursor = 'pointer';
$axure.eventManager.click('u392', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u233'] = 'center';gv_vAlignTable['u469'] = 'center';document.getElementById('u350_img').tabIndex = 0;

u350.style.cursor = 'pointer';
$axure.eventManager.click('u350', function(e) {

if (true) {

	SetPanelState('u360', 'pd1u360','none','',500,'none','',500);

                                EnableImageWidget('u336');
                                EnableImageWidget('u340');
                                EnableImageWidget('u342');
                                EnableImageWidget('u344');
                                EnableImageWidget('u346');
                                DisableImageWidget('u338');
}
});
gv_vAlignTable['u487'] = 'top';document.getElementById('u247_img').tabIndex = 0;

u247.style.cursor = 'pointer';
$axure.eventManager.click('u247', function(e) {

if (true) {

	SetPanelState('u271', 'pd2u271','none','',500,'none','',500);

                                EnableImageWidget('u243');
                                EnableImageWidget('u245');
                                EnableImageWidget('u249');
                                EnableImageWidget('u251');
                                EnableImageWidget('u253');
                                EnableImageWidget('u255');
                                DisableImageWidget('u247');
}
});
document.getElementById('u68_img').tabIndex = 0;
HookHover('u68', false);

u68.style.cursor = 'pointer';
$axure.eventManager.click('u68', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
u226.tabIndex = 0;

u226.style.cursor = 'pointer';
$axure.eventManager.click('u226', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
document.getElementById('u44_img').tabIndex = 0;
HookHover('u44', false);

u44.style.cursor = 'pointer';
$axure.eventManager.click('u44', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u518'] = 'top';gv_vAlignTable['u432'] = 'center';gv_vAlignTable['u188'] = 'center';gv_vAlignTable['u190'] = 'center';gv_vAlignTable['u115'] = 'top';gv_vAlignTable['u313'] = 'center';gv_vAlignTable['u291'] = 'top';gv_vAlignTable['u530'] = 'center';document.getElementById('u529_img').tabIndex = 0;

u529.style.cursor = 'pointer';
$axure.eventManager.click('u529', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
document.getElementById('u427_img').tabIndex = 0;

u427.style.cursor = 'pointer';
$axure.eventManager.click('u427', function(e) {

if (true) {

	SetPanelState('u457', 'pd0u457','none','',500,'none','',500);

                                EnableImageWidget('u429');
                                EnableImageWidget('u433');
                                EnableImageWidget('u437');
                                EnableImageWidget('u441');
                                EnableImageWidget('u445');
                                EnableImageWidget('u449');
                                EnableImageWidget('u453');
                                DisableImageWidget('u425');
}
});
u7.tabIndex = 0;

u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u246'] = 'center';document.getElementById('u62_img').tabIndex = 0;
HookHover('u62', false);

u62.style.cursor = 'pointer';
$axure.eventManager.click('u62', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u448'] = 'center';gv_vAlignTable['u372'] = 'center';gv_vAlignTable['u114'] = 'center';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u503'] = 'top';gv_vAlignTable['u278'] = 'top';gv_vAlignTable['u507'] = 'center';gv_vAlignTable['u485'] = 'center';document.getElementById('u70_img').tabIndex = 0;
HookHover('u70', false);

u70.style.cursor = 'pointer';
$axure.eventManager.click('u70', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
u14.tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u14'] = 'top';u218.tabIndex = 0;

u218.style.cursor = 'pointer';
$axure.eventManager.click('u218', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u362'] = 'center';gv_vAlignTable['u333'] = 'top';gv_vAlignTable['u98'] = 'center';u376.tabIndex = 0;

u376.style.cursor = 'pointer';
$axure.eventManager.click('u376', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u349'] = 'center';u311.tabIndex = 0;

u311.style.cursor = 'pointer';
$axure.eventManager.click('u311', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u230'] = 'top';u127.tabIndex = 0;

u127.style.cursor = 'pointer';
$axure.eventManager.click('u127', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');

SetGlobalVariableValue('BookPageViewed', '');

SetGlobalVariableValue('CitySelected', '');

SetGlobalVariableValue('LoginStatus', '');

SetGlobalVariableValue('ReviewVar', '');

SetGlobalVariableValue('EmployeesName', '');

	SetPanelState('u125', 'pd1u125','none','',500,'none','',500);
function waituf022ddcb6b474903a282219d39d908ef1() {

	SetPanelState('u125', 'pd0u125','none','',500,'none','',500);
}
setTimeout(waituf022ddcb6b474903a282219d39d908ef1, 4000);

}
});
gv_vAlignTable['u127'] = 'top';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u244'] = 'center';gv_vAlignTable['u375'] = 'top';document.getElementById('u429_img').tabIndex = 0;

u429.style.cursor = 'pointer';
$axure.eventManager.click('u429', function(e) {

if (true) {

	SetPanelState('u457', 'pd1u457','none','',500,'none','',500);

                                EnableImageWidget('u425');
                                EnableImageWidget('u433');
                                EnableImageWidget('u437');
                                EnableImageWidget('u441');
                                EnableImageWidget('u445');
                                EnableImageWidget('u449');
                                EnableImageWidget('u453');
                                DisableImageWidget('u429');
}
});
document.getElementById('u348_img').tabIndex = 0;

u348.style.cursor = 'pointer';
$axure.eventManager.click('u348', function(e) {

if (true) {

	SetPanelState('u360', 'pd0u360','none','',500,'none','',500);

                                EnableImageWidget('u338');
                                EnableImageWidget('u340');
                                EnableImageWidget('u342');
                                EnableImageWidget('u344');
                                EnableImageWidget('u346');
                                DisableImageWidget('u336');
}
});
u368.tabIndex = 0;

u368.style.cursor = 'pointer';
$axure.eventManager.click('u368', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u310'] = 'top';gv_vAlignTable['u225'] = 'top';gv_vAlignTable['u207'] = 'top';gv_vAlignTable['u185'] = 'top';u505.tabIndex = 0;

u505.style.cursor = 'pointer';
$axure.eventManager.click('u505', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u483'] = 'center';document.getElementById('u40_img').tabIndex = 0;
HookHover('u40', false);

u40.style.cursor = 'pointer';
$axure.eventManager.click('u40', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u324'] = 'top';document.getElementById('u243_img').tabIndex = 0;

u243.style.cursor = 'pointer';
$axure.eventManager.click('u243', function(e) {

if (true) {

	SetPanelState('u271', 'pd0u271','none','',500,'none','',500);

                                EnableImageWidget('u245');
                                EnableImageWidget('u247');
                                EnableImageWidget('u249');
                                EnableImageWidget('u251');
                                EnableImageWidget('u253');
                                EnableImageWidget('u255');
                                DisableImageWidget('u243');
}
});
document.getElementById('u441_img').tabIndex = 0;

u441.style.cursor = 'pointer';
$axure.eventManager.click('u441', function(e) {

if (true) {

	SetPanelState('u457', 'pd4u457','none','',500,'none','',500);

                                EnableImageWidget('u425');
                                EnableImageWidget('u429');
                                EnableImageWidget('u433');
                                EnableImageWidget('u437');
                                EnableImageWidget('u445');
                                EnableImageWidget('u449');
                                EnableImageWidget('u453');
                                DisableImageWidget('u441');
}
});
u497.tabIndex = 0;

u497.style.cursor = 'pointer';
$axure.eventManager.click('u497', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
document.getElementById('u257_img').tabIndex = 0;

u257.style.cursor = 'pointer';
$axure.eventManager.click('u257', function(e) {

if (true) {

	SetPanelState('u271', 'pd0u271','none','',500,'none','',500);

                                EnableImageWidget('u245');
                                EnableImageWidget('u247');
                                EnableImageWidget('u249');
                                EnableImageWidget('u251');
                                EnableImageWidget('u253');
                                EnableImageWidget('u255');
                                DisableImageWidget('u243');
}
});
gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u478'] = 'top';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u374'] = 'top';gv_vAlignTable['u428'] = 'center';gv_vAlignTable['u165'] = 'center';gv_vAlignTable['u206'] = 'center';gv_vAlignTable['u184'] = 'top';gv_vAlignTable['u504'] = 'top';gv_vAlignTable['u323'] = 'top';u242.tabIndex = 0;

u242.style.cursor = 'pointer';
$axure.eventManager.click('u242', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u440'] = 'center';gv_vAlignTable['u486'] = 'top';gv_vAlignTable['u337'] = 'center';gv_vAlignTable['u256'] = 'center';gv_vAlignTable['u155'] = 'center';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u454'] = 'center';gv_vAlignTable['u129'] = 'center';document.getElementById('u174_img').tabIndex = 0;

u174.style.cursor = 'pointer';
$axure.eventManager.click('u174', function(e) {

if (true) {

	SetPanelState('u178', 'pd4u178','none','',500,'none','',500);

                                EnableImageWidget('u154');
                                EnableImageWidget('u156');
                                EnableImageWidget('u158');
                                EnableImageWidget('u160');
                                EnableImageWidget('u164');
                                DisableImageWidget('u162');
}
});
document.getElementById('u269_img').tabIndex = 0;

u269.style.cursor = 'pointer';
$axure.eventManager.click('u269', function(e) {

if (true) {

	SetPanelState('u271', 'pd6u271','none','',500,'none','',500);

                                EnableImageWidget('u243');
                                EnableImageWidget('u245');
                                EnableImageWidget('u247');
                                EnableImageWidget('u249');
                                EnableImageWidget('u251');
                                EnableImageWidget('u253');
                                DisableImageWidget('u255');
}
});
document.getElementById('u259_img').tabIndex = 0;

u259.style.cursor = 'pointer';
$axure.eventManager.click('u259', function(e) {

if (true) {

	SetPanelState('u271', 'pd1u271','none','',500,'none','',500);

                                EnableImageWidget('u243');
                                EnableImageWidget('u247');
                                EnableImageWidget('u249');
                                EnableImageWidget('u251');
                                EnableImageWidget('u253');
                                EnableImageWidget('u255');
                                DisableImageWidget('u245');
}
});
gv_vAlignTable['u183'] = 'top';u10.tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u10'] = 'top';u481.tabIndex = 0;

u481.style.cursor = 'pointer';
$axure.eventManager.click('u481', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
document.getElementById('u42_img').tabIndex = 0;
HookHover('u42', false);

u42.style.cursor = 'pointer';
$axure.eventManager.click('u42', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u322'] = 'top';document.getElementById('u141_img').tabIndex = 0;

u141.style.cursor = 'pointer';
$axure.eventManager.click('u141', function(e) {

if (true) {

	SetPanelState('u153', 'pd2u153','none','',500,'none','',500);

	SetPanelState('u271', 'pd0u271','none','',500,'none','',500);

	SetPanelVisibility('u528','hidden','none',500);

                                EnableImageWidget('u137');
                                EnableImageWidget('u139');
                                EnableImageWidget('u143');
                                EnableImageWidget('u145');
                                EnableImageWidget('u147');
                                EnableImageWidget('u149');
                                EnableImageWidget('u151');
                                EnableImageWidget('u245');
                                EnableImageWidget('u247');
                                EnableImageWidget('u249');
                                EnableImageWidget('u251');
                                EnableImageWidget('u253');
                                EnableImageWidget('u255');
                                DisableImageWidget('u141');
                                DisableImageWidget('u243');
}
});
gv_vAlignTable['u197'] = 'top';gv_vAlignTable['u517'] = 'center';gv_vAlignTable['u495'] = 'top';document.getElementById('u336_img').tabIndex = 0;

u336.style.cursor = 'pointer';
$axure.eventManager.click('u336', function(e) {

if (true) {

	SetPanelState('u360', 'pd0u360','none','',500,'none','',500);

                                EnableImageWidget('u338');
                                EnableImageWidget('u340');
                                EnableImageWidget('u342');
                                EnableImageWidget('u344');
                                EnableImageWidget('u346');
                                DisableImageWidget('u336');
}
});
gv_vAlignTable['u71'] = 'center';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u15'] = 'top';document.getElementById('u453_img').tabIndex = 0;

u453.style.cursor = 'pointer';
$axure.eventManager.click('u453', function(e) {

if (true) {

	SetPanelState('u457', 'pd7u457','none','',500,'none','',500);

                                EnableImageWidget('u425');
                                EnableImageWidget('u429');
                                EnableImageWidget('u433');
                                EnableImageWidget('u437');
                                EnableImageWidget('u441');
                                EnableImageWidget('u445');
                                EnableImageWidget('u449');
                                DisableImageWidget('u453');
}
});
document.getElementById('u128_img').tabIndex = 0;

u128.style.cursor = 'pointer';
$axure.eventManager.click('u128', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
document.getElementById('u154_img').tabIndex = 0;

u154.style.cursor = 'pointer';
$axure.eventManager.click('u154', function(e) {

if (true) {

	SetPanelState('u178', 'pd0u178','none','',500,'none','',500);

                                EnableImageWidget('u156');
                                EnableImageWidget('u158');
                                EnableImageWidget('u160');
                                EnableImageWidget('u162');
                                EnableImageWidget('u164');
                                DisableImageWidget('u154');
}
});
gv_vAlignTable['u467'] = 'center';gv_vAlignTable['u398'] = 'top';gv_vAlignTable['u204'] = 'center';gv_vAlignTable['u182'] = 'center';gv_vAlignTable['u359'] = 'center';gv_vAlignTable['u480'] = 'center';gv_vAlignTable['u321'] = 'center';document.getElementById('u255_img').tabIndex = 0;

u255.style.cursor = 'pointer';
$axure.eventManager.click('u255', function(e) {

if (true) {

	SetPanelState('u271', 'pd6u271','none','',500,'none','',500);

                                EnableImageWidget('u243');
                                EnableImageWidget('u245');
                                EnableImageWidget('u247');
                                EnableImageWidget('u249');
                                EnableImageWidget('u251');
                                EnableImageWidget('u253');
                                DisableImageWidget('u255');
}
});
gv_vAlignTable['u140'] = 'center';gv_vAlignTable['u196'] = 'center';gv_vAlignTable['u494'] = 'top';u335.tabIndex = 0;

u335.style.cursor = 'pointer';
$axure.eventManager.click('u335', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Album_page.html');

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u308'] = 'top';gv_vAlignTable['u452'] = 'center';document.getElementById('u439_img').tabIndex = 0;

u439.style.cursor = 'pointer';
$axure.eventManager.click('u439', function(e) {

if (true) {

;

                                EnableImageWidget('u425');
                                EnableImageWidget('u429');
                                EnableImageWidget('u433');
                                EnableImageWidget('u441');
                                EnableImageWidget('u445');
                                EnableImageWidget('u449');
                                EnableImageWidget('u453');
                                DisableImageWidget('u437');
}
});
gv_vAlignTable['u84'] = 'center';gv_vAlignTable['u258'] = 'center';u4.tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u515'] = 'center';gv_vAlignTable['u493'] = 'center';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u334'] = 'top';document.getElementById('u451_img').tabIndex = 0;

u451.style.cursor = 'pointer';
$axure.eventManager.click('u451', function(e) {

if (true) {

	SetPanelState('u457', 'pd6u457','none','',500,'none','',500);

                                EnableImageWidget('u425');
                                EnableImageWidget('u429');
                                EnableImageWidget('u433');
                                EnableImageWidget('u437');
                                EnableImageWidget('u441');
                                EnableImageWidget('u445');
                                EnableImageWidget('u453');
                                DisableImageWidget('u449');
}
});
