﻿for(var i = 0; i < 79; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u31'] = 'center';u77.tabIndex = 0;

u77.style.cursor = 'pointer';
$axure.eventManager.click('u77', function(e) {

if (true) {

	parent.location.href = $axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	parent.location.href = $axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u23'] = 'top';u62.tabIndex = 0;

u62.style.cursor = 'pointer';
$axure.eventManager.click('u62', function(e) {

if (true) {

	parent.location.href = $axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u60'] = 'center';document.getElementById('u34_img').tabIndex = 0;

u34.style.cursor = 'pointer';
$axure.eventManager.click('u34', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u17'] = 'center';u64.tabIndex = 0;

u64.style.cursor = 'pointer';
$axure.eventManager.click('u64', function(e) {

if (true) {

	parent.location.href = $axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u2'] = 'center';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u52'] = 'center';u0.tabIndex = 0;

u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

	parent.location.href = $axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u0'] = 'top';gv_vAlignTable['u3'] = 'top';document.getElementById('u47_img').tabIndex = 0;

u47.style.cursor = 'pointer';
$axure.eventManager.click('u47', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u68'] = 'center';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	parent.location.href = $axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u28'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u39'] = 'center';document.getElementById('u69_img').tabIndex = 0;

u69.style.cursor = 'pointer';
$axure.eventManager.click('u69', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
u78.tabIndex = 0;

u78.style.cursor = 'pointer';
$axure.eventManager.click('u78', function(e) {

if (true) {

	parent.location.href = $axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u6'] = 'top';u61.tabIndex = 0;

u61.style.cursor = 'pointer';
$axure.eventManager.click('u61', function(e) {

if (true) {

	parent.location.href = $axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u35'] = 'center';u26.tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	parent.location.href = $axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u56'] = 'center';u5.tabIndex = 0;

u5.style.cursor = 'pointer';
$axure.eventManager.click('u5', function(e) {

if (true) {

	parent.location.href = $axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u5'] = 'top';u12.tabIndex = 0;

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	parent.location.href = $axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u12'] = 'top';u9.tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	parent.location.href = $axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u9'] = 'top';u42.tabIndex = 0;

u42.style.cursor = 'pointer';
$axure.eventManager.click('u42', function(e) {

if (true) {

	parent.location.href = $axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u72'] = 'center';u63.tabIndex = 0;

u63.style.cursor = 'pointer';
$axure.eventManager.click('u63', function(e) {

if (true) {

	parent.location.href = $axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u74'] = 'center';