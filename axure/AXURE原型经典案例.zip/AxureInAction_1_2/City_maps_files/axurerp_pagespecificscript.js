﻿for(var i = 0; i < 163; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

SetWidgetSelected('u65');
	var obj1 = document.getElementById("u138");
    obj1.focus();

}

if ((GetGlobalVariableValue('ShoppingBasket')) == ('Empty')) {

	SetPanelState('u81', 'pd0u81','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('1'))) {

SetWidgetRichText('u83', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (1 item)</span></p>');

	SetPanelState('u81', 'pd1u81','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('2'))) {

SetWidgetRichText('u83', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (2 items)</span></p>');

	SetPanelState('u81', 'pd1u81','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('3'))) {

SetWidgetRichText('u83', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (3 items)</span></p>');

	SetPanelState('u81', 'pd1u81','none','',500,'none','',500);

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) {

}

});

function rdo1LoadHome(e) {

}
gv_vAlignTable['u122'] = 'top';gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u156'] = 'center';u130.tabIndex = 0;

u130.style.cursor = 'pointer';
$axure.eventManager.click('u130', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');

SetGlobalVariableValue('BookPageViewed', '');

SetGlobalVariableValue('CitySelected', '');

SetGlobalVariableValue('LoginStatus', '');

SetGlobalVariableValue('ReviewVar', '');

SetGlobalVariableValue('EmployeesName', '');

	SetPanelState('u128', 'pd1u128','none','',500,'none','',500);
function waituf022ddcb6b474903a282219d39d908ef1() {

	SetPanelState('u128', 'pd0u128','none','',500,'none','',500);
}
setTimeout(waituf022ddcb6b474903a282219d39d908ef1, 4000);

}
});
gv_vAlignTable['u130'] = 'top';u7.tabIndex = 0;

u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u7'] = 'top';u2.tabIndex = 0;

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u79'] = 'center';u4.tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u4'] = 'top';document.getElementById('u153_img').tabIndex = 0;

u153.style.cursor = 'pointer';
$axure.eventManager.click('u153', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Search_results_city_maps.html');

}
});

$axure.eventManager.change('u140', function(e) {

if ((GetSelectedOption('u140')) != (' ')) {

	MoveWidgetTo('u36', GetNum('295'), GetNum('325'),'none',500);

	var obj1 = document.getElementById("u145");
    obj1.disabled = false;

	var obj1 = document.getElementById("u145");
    obj1.focus();

}
else
if ((GetSelectedOption('u143')) == (' ')) {

SetSelectedOption('u145', ' ');

	MoveWidgetTo('u36', GetNum('295'), GetNum('293'),'none',500);

	var obj1 = document.getElementById("u145");
    obj1.disabled = true;

}
});

$axure.eventManager.focus('u140', function(e) {

if (true) {

	SetPanelVisibility('u36','','none',500);

	MoveWidgetTo('u36', GetNum('295'), GetNum('293'),'none',500);

}
});
u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u17'] = 'top';u135.tabIndex = 0;

u135.style.cursor = 'pointer';
$axure.eventManager.click('u135', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u151'] = 'top';gv_vAlignTable['u42'] = 'center';u159.tabIndex = 0;

u159.style.cursor = 'pointer';
$axure.eventManager.click('u159', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u159'] = 'top';document.getElementById('u55_img').tabIndex = 0;
HookHover('u55', false);

u55.style.cursor = 'pointer';
$axure.eventManager.click('u55', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u101'] = 'center';u14.tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u105'] = 'center';
$axure.eventManager.change('u138', function(e) {

if ((GetSelectedOption('u138')) == (' Africa')) {

	SetPanelState('u139', 'pd1u139','none','',500,'none','',500);

	MoveWidgetTo('u36', GetNum('295'), GetNum('293'),'none',500);

	var obj1 = document.getElementById("u143");
    obj1.focus();

}
else
if ((GetSelectedOption('u138')) == (' America')) {

	SetPanelState('u139', 'pd2u139','none','',500,'none','',500);

	MoveWidgetTo('u36', GetNum('295'), GetNum('293'),'none',500);

	var obj1 = document.getElementById("u142");
    obj1.focus();

}
else
if ((GetSelectedOption('u138')) == (' Australasia')) {

	SetPanelState('u139', 'pd3u139','none','',500,'none','',500);

	MoveWidgetTo('u36', GetNum('295'), GetNum('293'),'none',500);

	var obj1 = document.getElementById("u141");
    obj1.focus();

}
else
if ((GetSelectedOption('u138')) == (' Europe')) {

	SetPanelState('u139', 'pd4u139','none','',500,'none','',500);

	MoveWidgetTo('u36', GetNum('295'), GetNum('293'),'none',500);

	var obj1 = document.getElementById("u140");
    obj1.focus();

}
else
if ((GetSelectedOption('u138')) == (' ')) {

	SetPanelState('u139', 'pd0u139','none','',500,'none','',500);

	MoveWidgetTo('u36', GetNum('295'), GetNum('262'),'none',500);

}
});

$axure.eventManager.focus('u138', function(e) {

if (true) {

	SetPanelVisibility('u36','','none',500);

	MoveWidgetTo('u36', GetNum('295'), GetNum('262'),'none',500);

}
});
gv_vAlignTable['u52'] = 'center';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u20'] = 'top';document.getElementById('u67_img').tabIndex = 0;
HookHover('u67', false);

u67.style.cursor = 'pointer';
$axure.eventManager.click('u67', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
document.getElementById('u65_img').tabIndex = 0;
HookHover('u65', false);

u65.style.cursor = 'pointer';
$axure.eventManager.click('u65', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u120'] = 'top';u6.tabIndex = 0;

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u108'] = 'center';gv_vAlignTable['u62'] = 'center';
$axure.eventManager.change('u141', function(e) {

if ((GetSelectedOption('u141')) != (' ')) {

	MoveWidgetTo('u36', GetNum('295'), GetNum('325'),'none',500);

	var obj1 = document.getElementById("u145");
    obj1.disabled = false;

	var obj1 = document.getElementById("u145");
    obj1.focus();

}
else
if ((GetSelectedOption('u143')) == (' ')) {

SetSelectedOption('u145', ' ');

	MoveWidgetTo('u36', GetNum('295'), GetNum('293'),'none',500);

	var obj1 = document.getElementById("u145");
    obj1.disabled = true;

}
});

$axure.eventManager.focus('u141', function(e) {

if (true) {

	SetPanelVisibility('u36','','none',500);

	MoveWidgetTo('u36', GetNum('295'), GetNum('293'),'none',500);

}
});
u11.tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u11'] = 'top';HookHover('u133', false);
gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u89'] = 'center';document.getElementById('u39_img').tabIndex = 0;
HookHover('u39', false);

u39.style.cursor = 'pointer';
$axure.eventManager.click('u39', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
document.getElementById('u47_img').tabIndex = 0;
HookHover('u47', false);

u47.style.cursor = 'pointer';
$axure.eventManager.click('u47', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u72'] = 'center';u103.tabIndex = 0;

u103.style.cursor = 'pointer';
$axure.eventManager.click('u103', function(e) {

if (true) {

	SetPanelVisibility('u96','hidden','none',500);

}
});

$axure.eventManager.mouseover('u103', function(e) {
if (!IsTrueMouseOver('u103',e)) return;
if (true) {

	SetPanelVisibility('u99','','none',500);

}
});

$axure.eventManager.mouseout('u103', function(e) {
if (!IsTrueMouseOut('u103',e)) return;
if (true) {

	SetPanelVisibility('u99','hidden','none',500);

}
});
gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u44'] = 'center';document.getElementById('u78_img').tabIndex = 0;

u78.style.cursor = 'pointer';
$axure.eventManager.click('u78', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
document.getElementById('u57_img').tabIndex = 0;
HookHover('u57', false);

u57.style.cursor = 'pointer';
$axure.eventManager.click('u57', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u119'] = 'top';u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u16'] = 'top';u125.tabIndex = 0;

u125.style.cursor = 'pointer';
$axure.eventManager.click('u125', function(e) {

if (true) {

	SetPanelVisibility('u96','hidden','none',500);

}
});

$axure.eventManager.mouseover('u125', function(e) {
if (!IsTrueMouseOver('u125',e)) return;
if (true) {

	SetPanelVisibility('u115','','none',500);

}
});

$axure.eventManager.mouseout('u125', function(e) {
if (!IsTrueMouseOut('u125',e)) return;
if (true) {

	SetPanelVisibility('u115','hidden','none',500);

}
});
document.getElementById('u41_img').tabIndex = 0;
HookHover('u41', false);

u41.style.cursor = 'pointer';
$axure.eventManager.click('u41', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u149'] = 'top';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u38'] = 'center';u26.tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href='http://www.lucabenazzi.eu';

}
});
gv_vAlignTable['u85'] = 'center';document.getElementById('u51_img').tabIndex = 0;
HookHover('u51', false);

u51.style.cursor = 'pointer';
$axure.eventManager.click('u51', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
u10.tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u23'] = 'top';document.getElementById('u82_img').tabIndex = 0;

u82.style.cursor = 'pointer';
$axure.eventManager.click('u82', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}
});
gv_vAlignTable['u95'] = 'center';document.getElementById('u61_img').tabIndex = 0;
HookHover('u61', false);

u61.style.cursor = 'pointer';
$axure.eventManager.click('u61', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
u158.tabIndex = 0;

u158.style.cursor = 'pointer';
$axure.eventManager.click('u158', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u158'] = 'top';gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u114'] = 'center';gv_vAlignTable['u157'] = 'top';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u46'] = 'center';
$axure.eventManager.keyup('u126', function(e) {

if ((GetWidgetText('u126')) == ('')) {

	SetPanelVisibility('u96','hidden','none',500);

}
else
if (true) {

	SetPanelState('u96', 'pd0u96','none','',500,'none','',500);

SetGlobalVariableValue('IncrementalSearchVar', GetWidgetText('u126'));

SetWidgetRichText('u118', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dada</span></p>');

SetWidgetRichText('u119', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dat</span></p>');

SetWidgetRichText('u120', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">gi</span></p>');

SetWidgetRichText('u122', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

SetWidgetRichText('u102', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

	SetPanelVisibility('u96','','none',500);

	BringToFront("u96");
function waitu796b5745765043a58e9fe38835b455f51() {

	SetPanelState('u96', 'pd1u96','none','',500,'none','',500);
}
setTimeout(waitu796b5745765043a58e9fe38835b455f51, 2000);

}
});

$axure.eventManager.blur('u126', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u126'));

}
});
document.getElementById('u71_img').tabIndex = 0;
HookHover('u71', false);

u71.style.cursor = 'pointer';
$axure.eventManager.click('u71', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
u5.tabIndex = 0;

u5.style.cursor = 'pointer';
$axure.eventManager.click('u5', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u98'] = 'center';u127.tabIndex = 0;

u127.style.cursor = 'pointer';
$axure.eventManager.click('u127', function(e) {

if (true) {

	self.location.href='index.html';

}
});
gv_vAlignTable['u127'] = 'top';document.getElementById('u43_img').tabIndex = 0;
HookHover('u43', false);

u43.style.cursor = 'pointer';
$axure.eventManager.click('u43', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u56'] = 'center';u150.tabIndex = 0;

u150.style.cursor = 'pointer';
$axure.eventManager.click('u150', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u150'] = 'top';
$axure.eventManager.change('u142', function(e) {

if ((GetSelectedOption('u142')) != (' ')) {

	MoveWidgetTo('u36', GetNum('295'), GetNum('325'),'none',500);

	var obj1 = document.getElementById("u145");
    obj1.disabled = false;

	var obj1 = document.getElementById("u145");
    obj1.focus();

}
else
if ((GetSelectedOption('u143')) == (' ')) {

SetSelectedOption('u145', ' ');

	MoveWidgetTo('u36', GetNum('295'), GetNum('293'),'none',500);

	var obj1 = document.getElementById("u145");
    obj1.disabled = true;

}
});

$axure.eventManager.focus('u142', function(e) {

if (true) {

	SetPanelVisibility('u36','','none',500);

	MoveWidgetTo('u36', GetNum('295'), GetNum('293'),'none',500);

}
});
gv_vAlignTable['u154'] = 'center';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u87'] = 'center';document.getElementById('u53_img').tabIndex = 0;
HookHover('u53', false);

u53.style.cursor = 'pointer';
$axure.eventManager.click('u53', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
u121.tabIndex = 0;

u121.style.cursor = 'pointer';
$axure.eventManager.click('u121', function(e) {

if (true) {

	SetPanelVisibility('u96','hidden','none',500);

}
});

$axure.eventManager.mouseover('u121', function(e) {
if (!IsTrueMouseOver('u121',e)) return;
if (true) {

	SetPanelVisibility('u106','','none',500);

}
});

$axure.eventManager.mouseout('u121', function(e) {
if (!IsTrueMouseOut('u121',e)) return;
if (true) {

	SetPanelVisibility('u106','hidden','none',500);

}
});
u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u19'] = 'top';document.getElementById('u155_img').tabIndex = 0;

u155.style.cursor = 'pointer';
$axure.eventManager.click('u155', function(e) {

if ((GetGlobalVariableValue('CitySelected')) == ('Yes')) {

}
else
if ((GetGlobalVariableValue('CitySelected')) == ('No')) {

}
});
document.getElementById('u84_img').tabIndex = 0;

u84.style.cursor = 'pointer';
$axure.eventManager.click('u84', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}

if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('OnLoadVariable')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u50'] = 'center';u123.tabIndex = 0;

u123.style.cursor = 'pointer';
$axure.eventManager.click('u123', function(e) {

if (true) {

	SetPanelVisibility('u96','hidden','none',500);

}
});

$axure.eventManager.mouseover('u123', function(e) {
if (!IsTrueMouseOver('u123',e)) return;
if (true) {

	SetPanelVisibility('u109','','none',500);

}
});

$axure.eventManager.mouseout('u123', function(e) {
if (!IsTrueMouseOut('u123',e)) return;
if (true) {

	SetPanelVisibility('u109','hidden','none',500);

}
});
gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u134'] = 'center';document.getElementById('u94_img').tabIndex = 0;

u94.style.cursor = 'pointer';
$axure.eventManager.click('u94', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u126'));

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Search_results.html');

}
});
gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u102'] = 'top';u9.tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
gv_vAlignTable['u9'] = 'top';document.getElementById('u73_img').tabIndex = 0;
HookHover('u73', false);

u73.style.cursor = 'pointer';
$axure.eventManager.click('u73', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
document.getElementById('u69_img').tabIndex = 0;
HookHover('u69', false);

u69.style.cursor = 'pointer';
$axure.eventManager.click('u69', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u147'] = 'top';gv_vAlignTable['u91'] = 'center';document.getElementById('u131_img').tabIndex = 0;

u131.style.cursor = 'pointer';
$axure.eventManager.click('u131', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u162'] = 'top';gv_vAlignTable['u117'] = 'center';u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u132'] = 'center';u129.tabIndex = 0;

u129.style.cursor = 'pointer';
$axure.eventManager.click('u129', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');
function waitud60c4460105243299b524b0b32b428cf1() {

	SetPanelState('u128', 'pd1u128','none','',500,'none','',500);
function waitub3ccdb0e2b0e45289ccb18b7f7d0de481() {
function waitu7d17a4dc47ea4dd0b7636d8a947ae1e31() {
}
setTimeout(waitu7d17a4dc47ea4dd0b7636d8a947ae1e31, 200);
}
setTimeout(waitub3ccdb0e2b0e45289ccb18b7f7d0de481, 200);
}
setTimeout(waitud60c4460105243299b524b0b32b428cf1, 300);

}
});
gv_vAlignTable['u129'] = 'top';gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u111'] = 'center';document.getElementById('u63_img').tabIndex = 0;
HookHover('u63', false);

u63.style.cursor = 'pointer';
$axure.eventManager.click('u63', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u83'] = 'center';u8.tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u8'] = 'top';u3.tabIndex = 0;

u3.style.cursor = 'pointer';
$axure.eventManager.click('u3', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u146'] = 'top';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u15'] = 'top';HookHover('u49', false);
u124.tabIndex = 0;

u124.style.cursor = 'pointer';
$axure.eventManager.click('u124', function(e) {

if (true) {

	SetPanelVisibility('u96','hidden','none',500);

}
});

$axure.eventManager.mouseover('u124', function(e) {
if (!IsTrueMouseOver('u124',e)) return;
if (true) {

	SetPanelVisibility('u112','','none',500);

}
});

$axure.eventManager.mouseout('u124', function(e) {
if (!IsTrueMouseOut('u124',e)) return;
if (true) {

	SetPanelVisibility('u112','hidden','none',500);

}
});
gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u148'] = 'top';gv_vAlignTable['u93'] = 'top';
$axure.eventManager.change('u145', function(e) {

if ((GetSelectedOption('u145')) != (' ')) {

	SetPanelState('u152', 'pd1u152','none','',500,'none','',500);

	SetPanelVisibility('u36','hidden','none',500);

}
});
u12.tabIndex = 0;

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u25'] = 'top';document.getElementById('u59_img').tabIndex = 0;
HookHover('u59', false);

u59.style.cursor = 'pointer';
$axure.eventManager.click('u59', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u161'] = 'center';document.getElementById('u45_img').tabIndex = 0;
HookHover('u45', false);

u45.style.cursor = 'pointer';
$axure.eventManager.click('u45', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});

$axure.eventManager.change('u143', function(e) {

if ((GetSelectedOption('u143')) != (' ')) {

	MoveWidgetTo('u36', GetNum('295'), GetNum('325'),'none',500);

	var obj1 = document.getElementById("u145");
    obj1.disabled = false;

	var obj1 = document.getElementById("u145");
    obj1.focus();

}
else
if ((GetSelectedOption('u143')) == (' ')) {

SetSelectedOption('u145', ' ');

	MoveWidgetTo('u36', GetNum('295'), GetNum('293'),'none',500);

	var obj1 = document.getElementById("u145");
    obj1.disabled = true;

}
});

$axure.eventManager.focus('u143', function(e) {

if (true) {

	SetPanelVisibility('u36','','none',500);

	MoveWidgetTo('u36', GetNum('295'), GetNum('293'),'none',500);

}
});
gv_vAlignTable['u35'] = 'center';u136.tabIndex = 0;

u136.style.cursor = 'pointer';
$axure.eventManager.click('u136', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('My_details.html');

}
else
if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('LoginStatus')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u136'] = 'top';document.getElementById('u28_img').tabIndex = 0;

u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
