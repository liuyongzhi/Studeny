﻿for(var i = 0; i < 420; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

SetWidgetSelected('u68');
}

if ((GetGlobalVariableValue('ShoppingBasket')) == ('Empty')) {

	SetPanelState('u78', 'pd0u78','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('1'))) {

SetWidgetRichText('u80', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (1 item)</span></p>');

	SetPanelState('u78', 'pd1u78','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('2'))) {

SetWidgetRichText('u80', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (2 items)</span></p>');

	SetPanelState('u78', 'pd1u78','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('3'))) {

SetWidgetRichText('u80', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (3 items)</span></p>');

	SetPanelState('u78', 'pd1u78','none','',500,'none','',500);

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) {

}

});

function rdo1LoadHome(e) {

}
u370.tabIndex = 0;

u370.style.cursor = 'pointer';
$axure.eventManager.click('u370', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u370'] = 'top';document.getElementById('u167_img').tabIndex = 0;

u167.style.cursor = 'pointer';
$axure.eventManager.click('u167', function(e) {

if (true) {

	SetPanelState('u138', 'pd1u138','none','',500,'none','',500);

}
});
u299.tabIndex = 0;

u299.style.cursor = 'pointer';
$axure.eventManager.click('u299', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u299'] = 'top';u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u17'] = 'top';document.getElementById('u36_img').tabIndex = 0;
HookHover('u36', false);

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u180'] = 'center';u136.tabIndex = 0;

u136.style.cursor = 'pointer';
$axure.eventManager.click('u136', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u136'] = 'top';gv_vAlignTable['u216'] = 'top';gv_vAlignTable['u333'] = 'center';gv_vAlignTable['u231'] = 'center';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u166'] = 'center';gv_vAlignTable['u201'] = 'center';gv_vAlignTable['u95'] = 'center';gv_vAlignTable['u1'] = 'center';u215.tabIndex = 0;

u215.style.cursor = 'pointer';
$axure.eventManager.click('u215', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u215'] = 'top';gv_vAlignTable['u193'] = 'center';u11.tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u11'] = 'top';u126.tabIndex = 0;

u126.style.cursor = 'pointer';
$axure.eventManager.click('u126', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');
function waitud60c4460105243299b524b0b32b428cf1() {

	SetPanelState('u125', 'pd1u125','none','',500,'none','',500);
function waitub3ccdb0e2b0e45289ccb18b7f7d0de481() {
function waitu7d17a4dc47ea4dd0b7636d8a947ae1e31() {
}
setTimeout(waitu7d17a4dc47ea4dd0b7636d8a947ae1e31, 200);
}
setTimeout(waitub3ccdb0e2b0e45289ccb18b7f7d0de481, 200);
}
setTimeout(waitud60c4460105243299b524b0b32b428cf1, 300);

}
});
gv_vAlignTable['u126'] = 'top';gv_vAlignTable['u413'] = 'top';u26.tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href='http://www.lucabenazzi.eu';

}
});
document.getElementById('u165_img').tabIndex = 0;

u165.style.cursor = 'pointer';
$axure.eventManager.click('u165', function(e) {

if (true) {

	SetPanelState('u138', 'pd0u138','none','',500,'none','',500);

}
});
u100.tabIndex = 0;

u100.style.cursor = 'pointer';
$axure.eventManager.click('u100', function(e) {

if (true) {

	SetPanelVisibility('u93','hidden','none',500);

}
});

$axure.eventManager.mouseover('u100', function(e) {
if (!IsTrueMouseOver('u100',e)) return;
if (true) {

	SetPanelVisibility('u96','','none',500);

}
});

$axure.eventManager.mouseout('u100', function(e) {
if (!IsTrueMouseOut('u100',e)) return;
if (true) {

	SetPanelVisibility('u96','hidden','none',500);

}
});
document.getElementById('u54_img').tabIndex = 0;
HookHover('u54', false);

u54.style.cursor = 'pointer';
$axure.eventManager.click('u54', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u236'] = 'top';gv_vAlignTable['u214'] = 'top';gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u331'] = 'center';gv_vAlignTable['u150'] = 'top';gv_vAlignTable['u287'] = 'top';document.getElementById('u48_img').tabIndex = 0;
HookHover('u48', false);

u48.style.cursor = 'pointer';
$axure.eventManager.click('u48', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
u345.tabIndex = 0;

u345.style.cursor = 'pointer';
$axure.eventManager.click('u345', function(e) {

if (true) {

	SetPanelState('u340', 'pd0u340','none','',500,'none','',500);

}
});
gv_vAlignTable['u345'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u80'] = 'center';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u268'] = 'center';document.getElementById('u330_img').tabIndex = 0;

u330.style.cursor = 'pointer';
$axure.eventManager.click('u330', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u286'] = 'top';document.getElementById('u42_img').tabIndex = 0;
HookHover('u42', false);

u42.style.cursor = 'pointer';
$axure.eventManager.click('u42', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u159'] = 'top';gv_vAlignTable['u163'] = 'top';gv_vAlignTable['u63'] = 'center';u400.tabIndex = 0;

u400.style.cursor = 'pointer';
$axure.eventManager.click('u400', function(e) {

if (true) {

	SetPanelState('u395', 'pd0u395','none','',500,'none','',500);

}
});
gv_vAlignTable['u400'] = 'top';gv_vAlignTable['u37'] = 'center';HookHover('u46', false);
gv_vAlignTable['u419'] = 'top';gv_vAlignTable['u285'] = 'center';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u18'] = 'top';document.getElementById('u50_img').tabIndex = 0;
HookHover('u50', false);

u50.style.cursor = 'pointer';
$axure.eventManager.click('u50', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u162'] = 'top';u357.tabIndex = 0;

u357.style.cursor = 'pointer';
$axure.eventManager.click('u357', function(e) {

if (true) {

	SetPanelState('u340', 'pd0u340','none','',500,'none','',500);

	MoveWidgetBy('u378', GetNum('0'), GetNum('-162'),'none',500);

	MoveWidgetBy('u395', GetNum('0'), GetNum('-162'),'none',500);

	MoveWidgetBy('u361', GetNum('0'), GetNum('-162'),'none',500);

}
});
gv_vAlignTable['u357'] = 'top';document.getElementById('u79_img').tabIndex = 0;

u79.style.cursor = 'pointer';
$axure.eventManager.click('u79', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}
});
gv_vAlignTable['u176'] = 'center';gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u149'] = 'top';gv_vAlignTable['u111'] = 'center';gv_vAlignTable['u391'] = 'top';gv_vAlignTable['u306'] = 'center';u12.tabIndex = 0;

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u12'] = 'top';u161.tabIndex = 0;

u161.style.cursor = 'pointer';
$axure.eventManager.click('u161', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u161'] = 'top';document.getElementById('u175_img').tabIndex = 0;

u175.style.cursor = 'pointer';
$axure.eventManager.click('u175', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u229'] = 'center';u148.tabIndex = 0;

u148.style.cursor = 'pointer';
$axure.eventManager.click('u148', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u148'] = 'top';u348.tabIndex = 0;

u348.style.cursor = 'pointer';
$axure.eventManager.click('u348', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u348'] = 'top';u283.tabIndex = 0;

u283.style.cursor = 'pointer';
$axure.eventManager.click('u283', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u283'] = 'top';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u20'] = 'top';u124.tabIndex = 0;

u124.style.cursor = 'pointer';
$axure.eventManager.click('u124', function(e) {

if (true) {

	self.location.href='index.html';

}
});
gv_vAlignTable['u124'] = 'top';document.getElementById('u38_img').tabIndex = 0;
HookHover('u38', false);

u38.style.cursor = 'pointer';
$axure.eventManager.click('u38', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u241'] = 'center';gv_vAlignTable['u297'] = 'top';u8.tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u178'] = 'center';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u25'] = 'top';document.getElementById('u309_img').tabIndex = 0;

u309.style.cursor = 'pointer';
$axure.eventManager.click('u309', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
document.getElementById('u228_img').tabIndex = 0;

u228.style.cursor = 'pointer';
$axure.eventManager.click('u228', function(e) {

if (true) {

	SetPanelState('u138', 'pd0u138','none','',500,'none','',500);

}
});
gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u304'] = 'center';gv_vAlignTable['u282'] = 'center';gv_vAlignTable['u76'] = 'center';
$axure.eventManager.keyup('u123', function(e) {

if ((GetWidgetText('u123')) == ('')) {

	SetPanelVisibility('u93','hidden','none',500);

}
else
if (true) {

	SetPanelState('u93', 'pd0u93','none','',500,'none','',500);

SetGlobalVariableValue('IncrementalSearchVar', GetWidgetText('u123'));

SetWidgetRichText('u115', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dada</span></p>');

SetWidgetRichText('u116', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dat</span></p>');

SetWidgetRichText('u117', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">gi</span></p>');

SetWidgetRichText('u119', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

SetWidgetRichText('u99', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

	SetPanelVisibility('u93','','none',500);

	BringToFront("u93");
function waitu796b5745765043a58e9fe38835b455f51() {

	SetPanelState('u93', 'pd1u93','none','',500,'none','',500);
}
setTimeout(waitu796b5745765043a58e9fe38835b455f51, 2000);

}
});

$axure.eventManager.blur('u123', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u123'));

}
});
document.getElementById('u263_img').tabIndex = 0;

u263.style.cursor = 'pointer';
$axure.eventManager.click('u263', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u278'] = 'center';gv_vAlignTable['u296'] = 'top';gv_vAlignTable['u137'] = 'top';gv_vAlignTable['u254'] = 'center';u190.tabIndex = 0;

u190.style.cursor = 'pointer';
$axure.eventManager.click('u190', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
u122.tabIndex = 0;

u122.style.cursor = 'pointer';
$axure.eventManager.click('u122', function(e) {

if (true) {

	SetPanelVisibility('u93','hidden','none',500);

}
});

$axure.eventManager.mouseover('u122', function(e) {
if (!IsTrueMouseOver('u122',e)) return;
if (true) {

	SetPanelVisibility('u112','','none',500);

}
});

$axure.eventManager.mouseout('u122', function(e) {
if (!IsTrueMouseOut('u122',e)) return;
if (true) {

	SetPanelVisibility('u112','hidden','none',500);

}
});
u358.tabIndex = 0;

u358.style.cursor = 'pointer';
$axure.eventManager.click('u358', function(e) {

if (true) {

	SetPanelState('u340', 'pd1u340','none','',500,'none','',500);

}
});
gv_vAlignTable['u358'] = 'top';u5.tabIndex = 0;

u5.style.cursor = 'pointer';
$axure.eventManager.click('u5', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u5'] = 'top';u317.tabIndex = 0;

u317.style.cursor = 'pointer';
$axure.eventManager.click('u317', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
u295.tabIndex = 0;

u295.style.cursor = 'pointer';
$axure.eventManager.click('u295', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u295'] = 'top';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u172'] = 'center';u410.tabIndex = 0;

u410.style.cursor = 'pointer';
$axure.eventManager.click('u410', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u410'] = 'top';u121.tabIndex = 0;

u121.style.cursor = 'pointer';
$axure.eventManager.click('u121', function(e) {

if (true) {

	SetPanelVisibility('u93','hidden','none',500);

}
});

$axure.eventManager.mouseover('u121', function(e) {
if (!IsTrueMouseOver('u121',e)) return;
if (true) {

	SetPanelVisibility('u109','','none',500);

}
});

$axure.eventManager.mouseout('u121', function(e) {
if (!IsTrueMouseOut('u121',e)) return;
if (true) {

	SetPanelVisibility('u109','hidden','none',500);

}
});
gv_vAlignTable['u414'] = 'top';u409.tabIndex = 0;

u409.style.cursor = 'pointer';
$axure.eventManager.click('u409', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u409'] = 'top';gv_vAlignTable['u316'] = 'center';gv_vAlignTable['u294'] = 'top';gv_vAlignTable['u135'] = 'top';gv_vAlignTable['u108'] = 'center';gv_vAlignTable['u252'] = 'center';u191.tabIndex = 0;

u191.style.cursor = 'pointer';
$axure.eventManager.click('u191', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u266'] = 'center';document.getElementById('u64_img').tabIndex = 0;
HookHover('u64', false);

u64.style.cursor = 'pointer';
$axure.eventManager.click('u64', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u239'] = 'center';gv_vAlignTable['u301'] = 'top';u120.tabIndex = 0;

u120.style.cursor = 'pointer';
$axure.eventManager.click('u120', function(e) {

if (true) {

	SetPanelVisibility('u93','hidden','none',500);

}
});

$axure.eventManager.mouseover('u120', function(e) {
if (!IsTrueMouseOver('u120',e)) return;
if (true) {

	SetPanelVisibility('u106','','none',500);

}
});

$axure.eventManager.mouseout('u120', function(e) {
if (!IsTrueMouseOut('u120',e)) return;
if (true) {

	SetPanelVisibility('u106','hidden','none',500);

}
});
u2.tabIndex = 0;

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u293'] = 'top';gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u170'] = 'center';u373.tabIndex = 0;

u373.style.cursor = 'pointer';
$axure.eventManager.click('u373', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u373'] = 'top';gv_vAlignTable['u82'] = 'center';u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u314'] = 'center';u292.tabIndex = 0;

u292.style.cursor = 'pointer';
$axure.eventManager.click('u292', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u292'] = 'top';u133.tabIndex = 0;

u133.style.cursor = 'pointer';
$axure.eventManager.click('u133', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('My_details.html');

}
else
if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('LoginStatus')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u133'] = 'top';gv_vAlignTable['u369'] = 'top';u250.tabIndex = 0;

u250.style.cursor = 'pointer';
$axure.eventManager.click('u250', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u147'] = 'top';document.getElementById('u58_img').tabIndex = 0;
HookHover('u58', false);

u58.style.cursor = 'pointer';
$axure.eventManager.click('u58', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
gv_vAlignTable['u145'] = 'center';gv_vAlignTable['u90'] = 'top';gv_vAlignTable['u213'] = 'top';u132.tabIndex = 0;

u132.style.cursor = 'pointer';
$axure.eventManager.click('u132', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u327'] = 'center';gv_vAlignTable['u146'] = 'top';document.getElementById('u52_img').tabIndex = 0;
HookHover('u52', false);

u52.style.cursor = 'pointer';
$axure.eventManager.click('u52', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u274'] = 'center';document.getElementById('u277_img').tabIndex = 0;

u277.style.cursor = 'pointer';
$axure.eventManager.click('u277', function(e) {

if (true) {

	SetPanelState('u138', 'pd2u138','none','',500,'none','',500);

}
});
u388.tabIndex = 0;

u388.style.cursor = 'pointer';
$axure.eventManager.click('u388', function(e) {

if (true) {

	SetPanelState('u378', 'pd0u378','none','',500,'none','',500);

	MoveWidgetBy('u395', GetNum('0'), GetNum('-119'),'none',500);

}
});
gv_vAlignTable['u388'] = 'top';gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u212'] = 'center';gv_vAlignTable['u131'] = 'center';u183.tabIndex = 0;

u183.style.cursor = 'pointer';
$axure.eventManager.click('u183', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
u407.tabIndex = 0;

u407.style.cursor = 'pointer';
$axure.eventManager.click('u407', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u407'] = 'top';document.getElementById('u28_img').tabIndex = 0;

u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
document.getElementById('u60_img').tabIndex = 0;
HookHover('u60', false);

u60.style.cursor = 'pointer';
$axure.eventManager.click('u60', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
u118.tabIndex = 0;

u118.style.cursor = 'pointer';
$axure.eventManager.click('u118', function(e) {

if (true) {

	SetPanelVisibility('u93','hidden','none',500);

}
});

$axure.eventManager.mouseover('u118', function(e) {
if (!IsTrueMouseOver('u118',e)) return;
if (true) {

	SetPanelVisibility('u103','','none',500);

}
});

$axure.eventManager.mouseout('u118', function(e) {
if (!IsTrueMouseOut('u118',e)) return;
if (true) {

	SetPanelVisibility('u103','hidden','none',500);

}
});
gv_vAlignTable['u262'] = 'center';gv_vAlignTable['u276'] = 'center';gv_vAlignTable['u89'] = 'top';gv_vAlignTable['u249'] = 'center';HookHover('u130', false);
gv_vAlignTable['u39'] = 'center';u406.tabIndex = 0;

u406.style.cursor = 'pointer';
$axure.eventManager.click('u406', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u406'] = 'top';gv_vAlignTable['u61'] = 'center';document.getElementById('u275_img').tabIndex = 0;

u275.style.cursor = 'pointer';
$axure.eventManager.click('u275', function(e) {

if (true) {

	SetPanelState('u138', 'pd1u138','none','',500,'none','',500);

}
});
gv_vAlignTable['u329'] = 'center';u210.tabIndex = 0;

u210.style.cursor = 'pointer';
$axure.eventManager.click('u210', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u210'] = 'top';document.getElementById('u44_img').tabIndex = 0;
HookHover('u44', false);

u44.style.cursor = 'pointer';
$axure.eventManager.click('u44', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
u405.tabIndex = 0;

u405.style.cursor = 'pointer';
$axure.eventManager.click('u405', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u405'] = 'top';u383.tabIndex = 0;

u383.style.cursor = 'pointer';
$axure.eventManager.click('u383', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u383'] = 'top';u224.tabIndex = 0;

u224.style.cursor = 'pointer';
$axure.eventManager.click('u224', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u224'] = 'top';u143.tabIndex = 0;

u143.style.cursor = 'pointer';
$axure.eventManager.click('u143', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u143'] = 'top';u379.tabIndex = 0;

u379.style.cursor = 'pointer';
$axure.eventManager.click('u379', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u379'] = 'top';gv_vAlignTable['u260'] = 'center';u9.tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
gv_vAlignTable['u9'] = 'top';u157.tabIndex = 0;

u157.style.cursor = 'pointer';
$axure.eventManager.click('u157', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u157'] = 'top';gv_vAlignTable['u59'] = 'center';gv_vAlignTable['u189'] = 'center';gv_vAlignTable['u35'] = 'center';document.getElementById('u91_img').tabIndex = 0;

u91.style.cursor = 'pointer';
$axure.eventManager.click('u91', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u123'));

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Search_results.html');

}
});
gv_vAlignTable['u404'] = 'top';u382.tabIndex = 0;

u382.style.cursor = 'pointer';
$axure.eventManager.click('u382', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u382'] = 'top';gv_vAlignTable['u223'] = 'top';gv_vAlignTable['u142'] = 'center';gv_vAlignTable['u86'] = 'center';document.getElementById('u70_img').tabIndex = 0;
HookHover('u70', false);

u70.style.cursor = 'pointer';
$axure.eventManager.click('u70', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u156'] = 'top';gv_vAlignTable['u43'] = 'center';u354.tabIndex = 0;

u354.style.cursor = 'pointer';
$axure.eventManager.click('u354', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u354'] = 'top';gv_vAlignTable['u53'] = 'center';gv_vAlignTable['u105'] = 'center';u381.tabIndex = 0;

u381.style.cursor = 'pointer';
$axure.eventManager.click('u381', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u381'] = 'top';gv_vAlignTable['u222'] = 'top';u6.tabIndex = 0;

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u155'] = 'top';gv_vAlignTable['u209'] = 'center';u353.tabIndex = 0;

u353.style.cursor = 'pointer';
$axure.eventManager.click('u353', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u353'] = 'top';u272.tabIndex = 0;

u272.style.cursor = 'pointer';
$axure.eventManager.click('u272', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u308'] = 'center';u380.tabIndex = 0;

u380.style.cursor = 'pointer';
$axure.eventManager.click('u380', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u380'] = 'top';u221.tabIndex = 0;

u221.style.cursor = 'pointer';
$axure.eventManager.click('u221', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u221'] = 'top';gv_vAlignTable['u119'] = 'top';document.getElementById('u232_img').tabIndex = 0;

u232.style.cursor = 'pointer';
$axure.eventManager.click('u232', function(e) {

if (true) {

	SetPanelState('u138', 'pd2u138','none','',500,'none','',500);

}
});
u416.tabIndex = 0;

u416.style.cursor = 'pointer';
$axure.eventManager.click('u416', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u416'] = 'top';u394.tabIndex = 0;

u394.style.cursor = 'pointer';
$axure.eventManager.click('u394', function(e) {

if (true) {

	SetPanelState('u378', 'pd1u378','none','',500,'none','',500);

	MoveWidgetBy('u395', GetNum('0'), GetNum('119'),'none',500);

}
});
gv_vAlignTable['u394'] = 'top';gv_vAlignTable['u235'] = 'top';document.getElementById('u75_img').tabIndex = 0;

u75.style.cursor = 'pointer';
$axure.eventManager.click('u75', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u13'] = 'top';u352.tabIndex = 0;

u352.style.cursor = 'pointer';
$axure.eventManager.click('u352', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u352'] = 'top';u271.tabIndex = 0;

u271.style.cursor = 'pointer';
$axure.eventManager.click('u271', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u418'] = 'center';u366.tabIndex = 0;

u366.style.cursor = 'pointer';
$axure.eventManager.click('u366', function(e) {

if (true) {

	SetPanelState('u361', 'pd0u361','none','',500,'none','',500);

	MoveWidgetBy('u378', GetNum('0'), GetNum('-119'),'none',500);

	MoveWidgetBy('u395', GetNum('0'), GetNum('-119'),'none',500);

}
});
gv_vAlignTable['u366'] = 'top';gv_vAlignTable['u98'] = 'center';u339.tabIndex = 0;

u339.style.cursor = 'pointer';
$axure.eventManager.click('u339', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u158'] = 'top';gv_vAlignTable['u220'] = 'center';u3.tabIndex = 0;

u3.style.cursor = 'pointer';
$axure.eventManager.click('u3', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u117'] = 'top';u234.tabIndex = 0;

u234.style.cursor = 'pointer';
$axure.eventManager.click('u234', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u234'] = 'top';gv_vAlignTable['u73'] = 'center';u351.tabIndex = 0;

u351.style.cursor = 'pointer';
$axure.eventManager.click('u351', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u351'] = 'top';gv_vAlignTable['u270'] = 'center';gv_vAlignTable['u199'] = 'center';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u102'] = 'center';document.getElementById('u56_img').tabIndex = 0;
HookHover('u56', false);

u56.style.cursor = 'pointer';
$axure.eventManager.click('u56', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u300'] = 'top';gv_vAlignTable['u116'] = 'top';u392.tabIndex = 0;

u392.style.cursor = 'pointer';
$axure.eventManager.click('u392', function(e) {

if (true) {

	SetPanelState('u378', 'pd0u378','none','',500,'none','',500);

}
});
gv_vAlignTable['u392'] = 'top';gv_vAlignTable['u233'] = 'center';u350.tabIndex = 0;

u350.style.cursor = 'pointer';
$axure.eventManager.click('u350', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u350'] = 'top';gv_vAlignTable['u247'] = 'center';document.getElementById('u68_img').tabIndex = 0;
HookHover('u68', false);

u68.style.cursor = 'pointer';
$axure.eventManager.click('u68', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u226'] = 'top';gv_vAlignTable['u319'] = 'center';u338.tabIndex = 0;

u338.style.cursor = 'pointer';
$axure.eventManager.click('u338', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u115'] = 'top';u7.tabIndex = 0;

u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u7'] = 'top';document.getElementById('u62_img').tabIndex = 0;
HookHover('u62', false);

u62.style.cursor = 'pointer';
$axure.eventManager.click('u62', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u377'] = 'top';u372.tabIndex = 0;

u372.style.cursor = 'pointer';
$axure.eventManager.click('u372', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u372'] = 'top';gv_vAlignTable['u114'] = 'center';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u312'] = 'center';gv_vAlignTable['u290'] = 'top';u408.tabIndex = 0;

u408.style.cursor = 'pointer';
$axure.eventManager.click('u408', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u408'] = 'top';gv_vAlignTable['u187'] = 'center';gv_vAlignTable['u245'] = 'center';u412.tabIndex = 0;

u412.style.cursor = 'pointer';
$axure.eventManager.click('u412', function(e) {

if (true) {

	SetPanelState('u395', 'pd1u395','none','',500,'none','',500);

}
});
gv_vAlignTable['u412'] = 'top';u14.tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u14'] = 'top';u376.tabIndex = 0;

u376.style.cursor = 'pointer';
$axure.eventManager.click('u376', function(e) {

if (true) {

	SetPanelState('u361', 'pd1u361','none','',500,'none','',500);

	MoveWidgetBy('u378', GetNum('0'), GetNum('119'),'none',500);

	MoveWidgetBy('u395', GetNum('0'), GetNum('119'),'none',500);

}
});
gv_vAlignTable['u376'] = 'top';gv_vAlignTable['u99'] = 'top';u349.tabIndex = 0;

u349.style.cursor = 'pointer';
$axure.eventManager.click('u349', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u349'] = 'top';gv_vAlignTable['u168'] = 'center';u127.tabIndex = 0;

u127.style.cursor = 'pointer';
$axure.eventManager.click('u127', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');

SetGlobalVariableValue('BookPageViewed', '');

SetGlobalVariableValue('CitySelected', '');

SetGlobalVariableValue('LoginStatus', '');

SetGlobalVariableValue('ReviewVar', '');

SetGlobalVariableValue('EmployeesName', '');

	SetPanelState('u125', 'pd1u125','none','',500,'none','',500);
function waituf022ddcb6b474903a282219d39d908ef1() {

	SetPanelState('u125', 'pd0u125','none','',500,'none','',500);
}
setTimeout(waituf022ddcb6b474903a282219d39d908ef1, 4000);

}
});
gv_vAlignTable['u127'] = 'top';u325.tabIndex = 0;

u325.style.cursor = 'pointer';
$axure.eventManager.click('u325', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u310'] = 'center';gv_vAlignTable['u185'] = 'center';document.getElementById('u40_img').tabIndex = 0;
HookHover('u40', false);

u40.style.cursor = 'pointer';
$axure.eventManager.click('u40', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
u324.tabIndex = 0;

u324.style.cursor = 'pointer';
$axure.eventManager.click('u324', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u243'] = 'center';u360.tabIndex = 0;

u360.style.cursor = 'pointer';
$axure.eventManager.click('u360', function(e) {

if (true) {

	SetPanelState('u340', 'pd1u340','none','',500,'none','',500);

	MoveWidgetBy('u378', GetNum('0'), GetNum('162'),'none',500);

	MoveWidgetBy('u395', GetNum('0'), GetNum('162'),'none',500);

	MoveWidgetBy('u361', GetNum('0'), GetNum('162'),'none',500);

}
});
gv_vAlignTable['u360'] = 'top';u257.tabIndex = 0;

u257.style.cursor = 'pointer';
$axure.eventManager.click('u257', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u289'] = 'top';gv_vAlignTable['u45'] = 'center';u374.tabIndex = 0;

u374.style.cursor = 'pointer';
$axure.eventManager.click('u374', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u374'] = 'top';gv_vAlignTable['u323'] = 'center';document.getElementById('u242_img').tabIndex = 0;

u242.style.cursor = 'pointer';
$axure.eventManager.click('u242', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u337'] = 'center';gv_vAlignTable['u256'] = 'center';u288.tabIndex = 0;

u288.style.cursor = 'pointer';
$axure.eventManager.click('u288', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u288'] = 'top';gv_vAlignTable['u129'] = 'center';gv_vAlignTable['u174'] = 'center';u205.tabIndex = 0;

u205.style.cursor = 'pointer';
$axure.eventManager.click('u205', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
document.getElementById('u81_img').tabIndex = 0;

u81.style.cursor = 'pointer';
$axure.eventManager.click('u81', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}

if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('OnLoadVariable')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
u10.tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u197'] = 'center';gv_vAlignTable['u71'] = 'center';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u15'] = 'top';document.getElementById('u128_img').tabIndex = 0;

u128.style.cursor = 'pointer';
$axure.eventManager.click('u128', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
u204.tabIndex = 0;

u204.style.cursor = 'pointer';
$axure.eventManager.click('u204', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u182'] = 'center';document.getElementById('u66_img').tabIndex = 0;
HookHover('u66', false);

u66.style.cursor = 'pointer';
$axure.eventManager.click('u66', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u321'] = 'center';document.getElementById('u196_img').tabIndex = 0;

u196.style.cursor = 'pointer';
$axure.eventManager.click('u196', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u335'] = 'center';gv_vAlignTable['u23'] = 'top';u154.tabIndex = 0;

u154.style.cursor = 'pointer';
$axure.eventManager.click('u154', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u154'] = 'top';gv_vAlignTable['u264'] = 'center';u371.tabIndex = 0;

u371.style.cursor = 'pointer';
$axure.eventManager.click('u371', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Selected_catalogue.html');

}
});
gv_vAlignTable['u371'] = 'top';gv_vAlignTable['u203'] = 'center';gv_vAlignTable['u84'] = 'center';u258.tabIndex = 0;

u258.style.cursor = 'pointer';
$axure.eventManager.click('u258', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
u4.tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u217'] = 'top';gv_vAlignTable['u195'] = 'center';gv_vAlignTable['u225'] = 'top';gv_vAlignTable['u41'] = 'center';gv_vAlignTable['u153'] = 'center';