﻿for(var i = 0; i < 793; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

SetWidgetSelected('u60');
}

if ((GetGlobalVariableValue('ShoppingBasket')) == ('Empty')) {

	SetPanelState('u78', 'pd0u78','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('1'))) {

SetWidgetRichText('u80', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (1 item)</span></p>');

	SetPanelState('u78', 'pd1u78','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('2'))) {

SetWidgetRichText('u80', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (2 items)</span></p>');

	SetPanelState('u78', 'pd1u78','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('3'))) {

SetWidgetRichText('u80', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (3 items)</span></p>');

	SetPanelState('u78', 'pd1u78','none','',500,'none','',500);

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) {

}

});

function rdo1LoadHome(e) {

}
gv_vAlignTable['u285'] = 'top';document.getElementById('u343_img').tabIndex = 0;

u343.style.cursor = 'pointer';
$axure.eventManager.click('u343', function(e) {

if (true) {

	BringToFront("u303");
function waitu2423c184074a4a29ad1c01a37de7457e1() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waituc9e5d1dc7a4a4503900e6cf6cdb8cd4b1() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu33cb9bdb7a08417baf86ed2062b36cd41() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu711cd83e4f78499c88da56125662700b1() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitub18126f116354aeba4c16e6d09a26dcc1() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd4u322','none','',500,'none','',500);
function waitu0c25507abb454059aa2ae4ca4fd8f9a61() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu3505cf6c68b3424bb8f4f91e46c07f911() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitue25ac60ef5fd435ebe56318e2539bf791() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu29a3b70f66cc40a79231f9dd38fca9cc1() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitu34a71421ad0c4d13a3e05107854ccc311() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waitu34a71421ad0c4d13a3e05107854ccc311, 100);
}
setTimeout(waitu29a3b70f66cc40a79231f9dd38fca9cc1, 100);
}
setTimeout(waitue25ac60ef5fd435ebe56318e2539bf791, 100);
}
setTimeout(waitu3505cf6c68b3424bb8f4f91e46c07f911, 100);
}
setTimeout(waitu0c25507abb454059aa2ae4ca4fd8f9a61, 100);
}
setTimeout(waitub18126f116354aeba4c16e6d09a26dcc1, 100);
}
setTimeout(waitu711cd83e4f78499c88da56125662700b1, 100);
}
setTimeout(waitu33cb9bdb7a08417baf86ed2062b36cd41, 100);
}
setTimeout(waituc9e5d1dc7a4a4503900e6cf6cdb8cd4b1, 100);
}
setTimeout(waitu2423c184074a4a29ad1c01a37de7457e1, 100);

}
});
gv_vAlignTable['u691'] = 'center';gv_vAlignTable['u497'] = 'center';gv_vAlignTable['u684'] = 'center';document.getElementById('u281_img').tabIndex = 0;

u281.style.cursor = 'pointer';
$axure.eventManager.click('u281', function(e) {

if (true) {

	SetPanelState('u135', 'pd11u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u493'] = 'center';gv_vAlignTable['u400'] = 'center';gv_vAlignTable['u206'] = 'center';gv_vAlignTable['u363'] = 'center';gv_vAlignTable['u680'] = 'center';gv_vAlignTable['u241'] = 'top';gv_vAlignTable['u612'] = 'center';gv_vAlignTable['u266'] = 'center';gv_vAlignTable['u637'] = 'center';gv_vAlignTable['u234'] = 'center';gv_vAlignTable['u699'] = 'top';gv_vAlignTable['u202'] = 'center';document.getElementById('u421_img').tabIndex = 0;

u421.style.cursor = 'pointer';
$axure.eventManager.click('u421', function(e) {

if (true) {

	SetPanelState('u135', 'pd7u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u446'] = 'center';gv_vAlignTable['u665'] = 'center';gv_vAlignTable['u228'] = 'center';document.getElementById('u81_img').tabIndex = 0;

u81.style.cursor = 'pointer';
$axure.eventManager.click('u81', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}

if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('OnLoadVariable')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u414'] = 'center';gv_vAlignTable['u633'] = 'center';gv_vAlignTable['u601'] = 'center';u2.tabIndex = 0;

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u442'] = 'center';gv_vAlignTable['u661'] = 'top';document.getElementById('u249_img').tabIndex = 0;

u249.style.cursor = 'pointer';
$axure.eventManager.click('u249', function(e) {

if (true) {

	SetPanelState('u135', 'pd1u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u468'] = 'center';gv_vAlignTable['u396'] = 'top';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u470'] = 'center';document.getElementById('u275_img').tabIndex = 0;

u275.style.cursor = 'pointer';
$axure.eventManager.click('u275', function(e) {

if (true) {

	SetPanelState('u135', 'pd3u135','none','',500,'none','',500);

}
});
document.getElementById('u725_img').tabIndex = 0;

u725.style.cursor = 'pointer';
$axure.eventManager.click('u725', function(e) {

if (true) {

	SetPanelState('u135', 'pd16u135','none','',500,'none','',500);
function waituf581754bbbf147e695326ebb91003d021() {

	SetPanelState('u135', 'pd17u135','none','',500,'none','',500);
function waitucad2993e24fc4074afde03b60cbc8fb91() {

	SetPanelState('u135', 'pd18u135','none','',500,'none','',500);
function waitu71ba27c725ac49b8b21132812d0a41a01() {

	SetPanelState('u135', 'pd12u135','none','',500,'none','',500);
}
setTimeout(waitu71ba27c725ac49b8b21132812d0a41a01, 100);
}
setTimeout(waitucad2993e24fc4074afde03b60cbc8fb91, 100);
}
setTimeout(waituf581754bbbf147e695326ebb91003d021, 100);

}
});
gv_vAlignTable['u591'] = 'center';gv_vAlignTable['u98'] = 'center';gv_vAlignTable['u584'] = 'center';gv_vAlignTable['u188'] = 'center';document.getElementById('u75_img').tabIndex = 0;

u75.style.cursor = 'pointer';
$axure.eventManager.click('u75', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u393'] = 'center';document.getElementById('u552_img').tabIndex = 0;

u552.style.cursor = 'pointer';
$axure.eventManager.click('u552', function(e) {

if (true) {

	BringToFront("u485");
function waitu259f6667b3a1442594bd3726f75092551() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waituba55c33927f54855aaaf6d756f7302bb1() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitufe3428ea38ae428ea259a94a230fefa91() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitubf391e6bc56d40b1987f1283574385a71() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu0069864c014f47c8ad3f263eaa9be9c61() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd6u504','none','',500,'none','',500);
function waitu0293f985e31a44b6b0507133976129111() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu621c5c042b054089a3e0b04625d1aa1f1() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu06ab4099e3dd4b7e8b66896cf7cf2e621() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waituc503cbb6324c4c38940df656a0ac1a291() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waituc4f7b90ac59c49818c2e92b9c6620e391() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waituc4f7b90ac59c49818c2e92b9c6620e391, 100);
}
setTimeout(waituc503cbb6324c4c38940df656a0ac1a291, 100);
}
setTimeout(waitu06ab4099e3dd4b7e8b66896cf7cf2e621, 100);
}
setTimeout(waitu621c5c042b054089a3e0b04625d1aa1f1, 100);
}
setTimeout(waitu0293f985e31a44b6b0507133976129111, 100);
}
setTimeout(waitu0069864c014f47c8ad3f263eaa9be9c61, 100);
}
setTimeout(waitubf391e6bc56d40b1987f1283574385a71, 100);
}
setTimeout(waitufe3428ea38ae428ea259a94a230fefa91, 100);
}
setTimeout(waituba55c33927f54855aaaf6d756f7302bb1, 100);
}
setTimeout(waitu259f6667b3a1442594bd3726f75092551, 100);

}
});
gv_vAlignTable['u250'] = 'center';gv_vAlignTable['u580'] = 'center';gv_vAlignTable['u141'] = 'center';document.getElementById('u512_img').tabIndex = 0;

u512.style.cursor = 'pointer';
$axure.eventManager.click('u512', function(e) {

if (true) {

	BringToFront("u485");
function waitu6e1c18ef002443ccbfef66b93a38b95b1() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitu82953e668bc24d62b6bd6d3072a9d5031() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu33a9a65fef5a4143bb75c45ba736dcc61() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu91c14095d7d84edcb055c82ba38a72071() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waituf8808efbd1454a8fb1db198b76c7a68d1() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd4u504','none','',500,'none','',500);
function waitu62540b90d5be4e75a00970f4cb0146341() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu5ca78bb2e7f4456b8184fa5bd8cf9f661() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitue118b108c8604762a882457c860b1b3a1() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitua47da60075f2402c96865932dd516c681() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitu4678400e98f544769992dfcd65e077571() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waitu4678400e98f544769992dfcd65e077571, 100);
}
setTimeout(waitua47da60075f2402c96865932dd516c681, 100);
}
setTimeout(waitue118b108c8604762a882457c860b1b3a1, 100);
}
setTimeout(waitu5ca78bb2e7f4456b8184fa5bd8cf9f661, 100);
}
setTimeout(waitu62540b90d5be4e75a00970f4cb0146341, 100);
}
setTimeout(waituf8808efbd1454a8fb1db198b76c7a68d1, 100);
}
setTimeout(waitu91c14095d7d84edcb055c82ba38a72071, 100);
}
setTimeout(waitu33a9a65fef5a4143bb75c45ba736dcc61, 100);
}
setTimeout(waitu82953e668bc24d62b6bd6d3072a9d5031, 100);
}
setTimeout(waitu6e1c18ef002443ccbfef66b93a38b95b1, 100);

}
});
document.getElementById('u166_img').tabIndex = 0;

u166.style.cursor = 'pointer';
$axure.eventManager.click('u166', function(e) {

if (true) {

	SetPanelState('u135', 'pd1u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u537'] = 'center';gv_vAlignTable['u792'] = 'top';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u599'] = 'center';gv_vAlignTable['u102'] = 'center';gv_vAlignTable['u39'] = 'center';u127.tabIndex = 0;

u127.style.cursor = 'pointer';
$axure.eventManager.click('u127', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');

SetGlobalVariableValue('BookPageViewed', '');

SetGlobalVariableValue('CitySelected', '');

SetGlobalVariableValue('LoginStatus', '');

SetGlobalVariableValue('ReviewVar', '');

SetGlobalVariableValue('EmployeesName', '');

	SetPanelState('u125', 'pd1u125','none','',500,'none','',500);
function waituf022ddcb6b474903a282219d39d908ef1() {

	SetPanelState('u125', 'pd0u125','none','',500,'none','',500);
}
setTimeout(waituf022ddcb6b474903a282219d39d908ef1, 4000);

}
});
gv_vAlignTable['u127'] = 'top';gv_vAlignTable['u346'] = 'center';gv_vAlignTable['u717'] = 'center';document.getElementById('u128_img').tabIndex = 0;

u128.style.cursor = 'pointer';
$axure.eventManager.click('u128', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u752'] = 'center';document.getElementById('u777_img').tabIndex = 0;

u777.style.cursor = 'pointer';
$axure.eventManager.click('u777', function(e) {

if (true) {

	SetPanelState('u135', 'pd13u135','none','',500,'none','',500);
function waitu8a8f3498ee7045e0925d39934d11664a1() {

	SetPanelState('u135', 'pd14u135','none','',500,'none','',500);
function waitu70890996cd7849b9bd9523c6e7c605701() {

	SetPanelState('u135', 'pd15u135','none','',500,'none','',500);
function waitu6d6b5ce3fb7c4f4f99fcb7ad42e8525d1() {

	SetPanelState('u135', 'pd2u135','none','',500,'none','',500);
}
setTimeout(waitu6d6b5ce3fb7c4f4f99fcb7ad42e8525d1, 100);
}
setTimeout(waitu70890996cd7849b9bd9523c6e7c605701, 100);
}
setTimeout(waitu8a8f3498ee7045e0925d39934d11664a1, 100);

}
});
HookHover('u130', false);
gv_vAlignTable['u501'] = 'center';gv_vAlignTable['u720'] = 'top';gv_vAlignTable['u374'] = 'top';gv_vAlignTable['u745'] = 'center';gv_vAlignTable['u342'] = 'center';document.getElementById('u368_img').tabIndex = 0;

u368.style.cursor = 'pointer';
$axure.eventManager.click('u368', function(e) {

if (true) {

	BringToFront("u303");
function waitu32192a40485d479abc1ae7b65a6834d01() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitu7dd8e5932c1b447e8df2e283ef3fd77e1() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitue73e6468461a443cb8796a1e6dd8973a1() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waituefd7f2440b6641418388339f2c2370481() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu9c1fab456c4c44faa570645d7ddaad2b1() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd5u322','none','',500,'none','',500);
function waitu7e1ad110e94d4acb9d0cef6bfd8b771b1() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu1b0341d6d17a4ae2b3a0e6670a9a6cd91() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitub083f12a6b524b9d8d88ffd1a85b74511() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu9d027b7c5f294b84943184c174a687111() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitue0350971ef14406aa131beccd43f61791() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waitue0350971ef14406aa131beccd43f61791, 100);
}
setTimeout(waitu9d027b7c5f294b84943184c174a687111, 100);
}
setTimeout(waitub083f12a6b524b9d8d88ffd1a85b74511, 100);
}
setTimeout(waitu1b0341d6d17a4ae2b3a0e6670a9a6cd91, 100);
}
setTimeout(waitu7e1ad110e94d4acb9d0cef6bfd8b771b1, 100);
}
setTimeout(waitu9c1fab456c4c44faa570645d7ddaad2b1, 100);
}
setTimeout(waituefd7f2440b6641418388339f2c2370481, 100);
}
setTimeout(waitue73e6468461a443cb8796a1e6dd8973a1, 100);
}
setTimeout(waitu7dd8e5932c1b447e8df2e283ef3fd77e1, 100);
}
setTimeout(waitu32192a40485d479abc1ae7b65a6834d01, 100);

}
});
gv_vAlignTable['u53'] = 'center';document.getElementById('u370_img').tabIndex = 0;

u370.style.cursor = 'pointer';
$axure.eventManager.click('u370', function(e) {

if (true) {

	BringToFront("u303");
function waitu259f6667b3a1442594bd3726f75092551() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waituba55c33927f54855aaaf6d756f7302bb1() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitufe3428ea38ae428ea259a94a230fefa91() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitubf391e6bc56d40b1987f1283574385a71() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu0069864c014f47c8ad3f263eaa9be9c61() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd6u322','none','',500,'none','',500);
function waitu0293f985e31a44b6b0507133976129111() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu621c5c042b054089a3e0b04625d1aa1f1() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu06ab4099e3dd4b7e8b66896cf7cf2e621() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waituc503cbb6324c4c38940df656a0ac1a291() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waituc4f7b90ac59c49818c2e92b9c6620e391() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waituc4f7b90ac59c49818c2e92b9c6620e391, 100);
}
setTimeout(waituc503cbb6324c4c38940df656a0ac1a291, 100);
}
setTimeout(waitu06ab4099e3dd4b7e8b66896cf7cf2e621, 100);
}
setTimeout(waitu621c5c042b054089a3e0b04625d1aa1f1, 100);
}
setTimeout(waitu0293f985e31a44b6b0507133976129111, 100);
}
setTimeout(waitu0069864c014f47c8ad3f263eaa9be9c61, 100);
}
setTimeout(waitubf391e6bc56d40b1987f1283574385a71, 100);
}
setTimeout(waitufe3428ea38ae428ea259a94a230fefa91, 100);
}
setTimeout(waituba55c33927f54855aaaf6d756f7302bb1, 100);
}
setTimeout(waitu259f6667b3a1442594bd3726f75092551, 100);

}
});
document.getElementById('u364_img').tabIndex = 0;

u364.style.cursor = 'pointer';
$axure.eventManager.click('u364', function(e) {

if (true) {

	BringToFront("u303");
function waitu7f35a463ebc245f89cfad4256057966f1() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitu56de5f1f412a4e598e8edb6f5ba0166f1() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitub135599508ca497789d61c7c1c2fb9421() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu6be77a6a33e54fd9b441b89a517cb8c81() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu2c77a3082c7b42f6a28cfb384b93b9a81() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd3u322','none','',500,'none','',500);
function waitu40c553b5a6be4b9197e112ef0dbac7821() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu3742d4e9ca37400081fe57a1c46850531() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu80f0afce20ad435ca758a1a25dbbfd641() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu5869824e4c7247048cc4bad7ff8ae21e1() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitu88fa7ca3cad043249beb119a600beaa01() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waitu88fa7ca3cad043249beb119a600beaa01, 100);
}
setTimeout(waitu5869824e4c7247048cc4bad7ff8ae21e1, 100);
}
setTimeout(waitu80f0afce20ad435ca758a1a25dbbfd641, 100);
}
setTimeout(waitu3742d4e9ca37400081fe57a1c46850531, 100);
}
setTimeout(waitu40c553b5a6be4b9197e112ef0dbac7821, 100);
}
setTimeout(waitu2c77a3082c7b42f6a28cfb384b93b9a81, 100);
}
setTimeout(waitu6be77a6a33e54fd9b441b89a517cb8c81, 100);
}
setTimeout(waitub135599508ca497789d61c7c1c2fb9421, 100);
}
setTimeout(waitu56de5f1f412a4e598e8edb6f5ba0166f1, 100);
}
setTimeout(waitu7f35a463ebc245f89cfad4256057966f1, 100);

}
});
document.getElementById('u548_img').tabIndex = 0;

u548.style.cursor = 'pointer';
$axure.eventManager.click('u548', function(e) {

if (true) {

	BringToFront("u485");
function waitu0c4cb32a75e64b12b020e8a84ae628d21() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waituf4c90e5df6444d138374efaad8620bab1() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitufa95f0687eeb43508bd1311ba8eb47aa1() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu075489eb4ffe445d9961c49c534211fc1() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu27e82be218b247028f0793012f115a201() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd4u504','none','',500,'none','',500);
function waitu58c023714e51491c987681ad3b33fc3a1() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitud27f6c8ed2ed49d8a6a7b568e5d4bde21() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu08d460c0bb354d31992967da7d307f5d1() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitue2430c53fbcb4cef885f75f95a4c50651() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitu37bdf31882d6434a90edab2b96e377d61() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waitu37bdf31882d6434a90edab2b96e377d61, 100);
}
setTimeout(waitue2430c53fbcb4cef885f75f95a4c50651, 100);
}
setTimeout(waitu08d460c0bb354d31992967da7d307f5d1, 100);
}
setTimeout(waitud27f6c8ed2ed49d8a6a7b568e5d4bde21, 100);
}
setTimeout(waitu58c023714e51491c987681ad3b33fc3a1, 100);
}
setTimeout(waitu27e82be218b247028f0793012f115a201, 100);
}
setTimeout(waitu075489eb4ffe445d9961c49c534211fc1, 100);
}
setTimeout(waitufa95f0687eeb43508bd1311ba8eb47aa1, 100);
}
setTimeout(waituf4c90e5df6444d138374efaad8620bab1, 100);
}
setTimeout(waitu0c4cb32a75e64b12b020e8a84ae628d21, 100);

}
});
u12.tabIndex = 0;

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u156'] = 'center';gv_vAlignTable['u543'] = 'center';gv_vAlignTable['u491'] = 'center';gv_vAlignTable['u521'] = 'center';gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u484'] = 'top';u7.tabIndex = 0;

u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u7'] = 'top';document.getElementById('u197_img').tabIndex = 0;

u197.style.cursor = 'pointer';
$axure.eventManager.click('u197', function(e) {

if (true) {

	SetPanelState('u135', 'pd2u135','none','',500,'none','',500);

}
});
document.getElementById('u425_img').tabIndex = 0;

u425.style.cursor = 'pointer';
$axure.eventManager.click('u425', function(e) {

if (true) {

	SetPanelState('u135', 'pd9u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u293'] = 'center';gv_vAlignTable['u200'] = 'center';gv_vAlignTable['u225'] = 'top';document.getElementById('u480_img').tabIndex = 0;

u480.style.cursor = 'pointer';
$axure.eventManager.click('u480', function(e) {

if (true) {

	SetPanelState('u135', 'pd8u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u412'] = 'center';gv_vAlignTable['u450'] = 'top';document.getElementById('u405_img').tabIndex = 0;

u405.style.cursor = 'pointer';
$axure.eventManager.click('u405', function(e) {

if (true) {

	BringToFront("u303");
function waituea259d56f03548ba9899cd9225fb401d1() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd1u322','none','',500,'none','',500);
function waitu14a6e2d873df4fc5a4a5a9556b5bdea81() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd2u322','none','',500,'none','',500);
function waitu4c7130d946564f018b2f55333cf4e96e1() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu343853c49f5d40e49ca8aaf7c94bcb6b1() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu3e3fc62e16884299861f3262ab2006c41() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd6u322','none','',500,'none','',500);
function waitueb88275d245c41908a22cce5873d2aa21() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu8ef25fd117074d04bc54d140543e4ba51() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu29e99e60ecf543c6b652dd2cf568bacd1() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu0be70c55adce4ae2997fb1c376f4f3e71() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitu5db16dc112c04b46b22074a7c8d6f63c1() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waitu5db16dc112c04b46b22074a7c8d6f63c1, 100);
}
setTimeout(waitu0be70c55adce4ae2997fb1c376f4f3e71, 100);
}
setTimeout(waitu29e99e60ecf543c6b652dd2cf568bacd1, 100);
}
setTimeout(waitu8ef25fd117074d04bc54d140543e4ba51, 100);
}
setTimeout(waitueb88275d245c41908a22cce5873d2aa21, 100);
}
setTimeout(waitu3e3fc62e16884299861f3262ab2006c41, 100);
}
setTimeout(waitu343853c49f5d40e49ca8aaf7c94bcb6b1, 100);
}
setTimeout(waitu4c7130d946564f018b2f55333cf4e96e1, 100);
}
setTimeout(waitu14a6e2d873df4fc5a4a5a9556b5bdea81, 100);
}
setTimeout(waituea259d56f03548ba9899cd9225fb401d1, 100);

}
});
gv_vAlignTable['u499'] = 'center';gv_vAlignTable['u214'] = 'center';document.getElementById('u514_img').tabIndex = 0;

u514.style.cursor = 'pointer';
$axure.eventManager.click('u514', function(e) {

if (true) {

	BringToFront("u485");
function waitua613447af0524d82bf3c17dea3e1ffba1() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waituab60d3881c984454badfdec85dd644861() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitufd3e6c2d16804e7c968550997fd718d01() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu27766848b76940a1828b6f3d8f7036861() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitud084239d218546af924c7a68e32f2af11() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd5u504','none','',500,'none','',500);
function waitue7285338587c402997b2cee1a03d93b41() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waituaa69a04e0dda49258e429e2eba5cb3061() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu66b8e13d89a340dcadab7673b80dcc961() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu919f53be9fb5405f92b4231a32f09b931() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitu1d5875a260404a3ba9dab5c3245d37a51() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waitu1d5875a260404a3ba9dab5c3245d37a51, 100);
}
setTimeout(waitu919f53be9fb5405f92b4231a32f09b931, 100);
}
setTimeout(waitu66b8e13d89a340dcadab7673b80dcc961, 100);
}
setTimeout(waituaa69a04e0dda49258e429e2eba5cb3061, 100);
}
setTimeout(waitue7285338587c402997b2cee1a03d93b41, 100);
}
setTimeout(waitud084239d218546af924c7a68e32f2af11, 100);
}
setTimeout(waitu27766848b76940a1828b6f3d8f7036861, 100);
}
setTimeout(waitufd3e6c2d16804e7c968550997fd718d01, 100);
}
setTimeout(waituab60d3881c984454badfdec85dd644861, 100);
}
setTimeout(waitua613447af0524d82bf3c17dea3e1ffba1, 100);

}
});
gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u440'] = 'center';gv_vAlignTable['u246'] = 'center';gv_vAlignTable['u82'] = 'center';gv_vAlignTable['u32'] = 'center';gv_vAlignTable['u652'] = 'top';document.getElementById('u677_img').tabIndex = 0;

u677.style.cursor = 'pointer';
$axure.eventManager.click('u677', function(e) {

if (true) {

	SetPanelState('u135', 'pd3u135','none','',500,'none','',500);

}
});
document.getElementById('u401_img').tabIndex = 0;

u401.style.cursor = 'pointer';
$axure.eventManager.click('u401', function(e) {

if (true) {

	BringToFront("u303");
function waitubec89408914f46319e83a3f6558395c31() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd1u322','none','',500,'none','',500);
function waitud4fa8cb1055f4620b231e956790b24241() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd2u322','none','',500,'none','',500);
function waitu0affdb628432409b88b01072d1341cbc1() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitufd93429219ea4d8da63c08becf4799841() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu85a71df17b5240989ca785d90f6033841() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd4u322','none','',500,'none','',500);
function waituc62e1cbf0d84415fabee873f404b94881() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu83d11a21fe4a45be8f44df9b7c3930ae1() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitufafd2e22d2c7472eb8e466631f2fba751() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu3be2df74a10b41c5873bb0645283e7c41() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitubc5eff91539c4da0881cfb4ae48d83f81() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waitubc5eff91539c4da0881cfb4ae48d83f81, 100);
}
setTimeout(waitu3be2df74a10b41c5873bb0645283e7c41, 100);
}
setTimeout(waitufafd2e22d2c7472eb8e466631f2fba751, 100);
}
setTimeout(waitu83d11a21fe4a45be8f44df9b7c3930ae1, 100);
}
setTimeout(waituc62e1cbf0d84415fabee873f404b94881, 100);
}
setTimeout(waitu85a71df17b5240989ca785d90f6033841, 100);
}
setTimeout(waitufd93429219ea4d8da63c08becf4799841, 100);
}
setTimeout(waitu0affdb628432409b88b01072d1341cbc1, 100);
}
setTimeout(waitud4fa8cb1055f4620b231e956790b24241, 100);
}
setTimeout(waitubec89408914f46319e83a3f6558395c31, 100);

}
});
gv_vAlignTable['u274'] = 'center';gv_vAlignTable['u645'] = 'center';gv_vAlignTable['u208'] = 'center';gv_vAlignTable['u242'] = 'top';gv_vAlignTable['u639'] = 'center';document.getElementById('u673_img').tabIndex = 0;

u673.style.cursor = 'pointer';
$axure.eventManager.click('u673', function(e) {

if (true) {

	SetPanelState('u135', 'pd1u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u270'] = 'center';gv_vAlignTable['u219'] = 'top';gv_vAlignTable['u448'] = 'center';gv_vAlignTable['u61'] = 'center';gv_vAlignTable['u67'] = 'center';document.getElementById('u140_img').tabIndex = 0;

u140.style.cursor = 'pointer';
$axure.eventManager.click('u140', function(e) {

if (true) {

	SetPanelState('u135', 'pd1u135','none','',500,'none','',500);

}
});
document.getElementById('u640_img').tabIndex = 0;

u640.style.cursor = 'pointer';
$axure.eventManager.click('u640', function(e) {

if (true) {

	SetPanelState('u135', 'pd2u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u391'] = 'center';gv_vAlignTable['u787'] = 'top';gv_vAlignTable['u384'] = 'center';gv_vAlignTable['u146'] = 'top';gv_vAlignTable['u163'] = 'center';u6.tabIndex = 0;

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u6'] = 'top';u100.tabIndex = 0;

u100.style.cursor = 'pointer';
$axure.eventManager.click('u100', function(e) {

if (true) {

	SetPanelVisibility('u93','hidden','none',500);

}
});

$axure.eventManager.mouseover('u100', function(e) {
if (!IsTrueMouseOver('u100',e)) return;
if (true) {

	SetPanelVisibility('u96','','none',500);

}
});

$axure.eventManager.mouseout('u100', function(e) {
if (!IsTrueMouseOut('u100',e)) return;
if (true) {

	SetPanelVisibility('u96','hidden','none',500);

}
});
gv_vAlignTable['u783'] = 'top';gv_vAlignTable['u365'] = 'center';gv_vAlignTable['u380'] = 'center';document.getElementById('u550_img').tabIndex = 0;

u550.style.cursor = 'pointer';
$axure.eventManager.click('u550', function(e) {

if (true) {

	BringToFront("u485");
function waitu32192a40485d479abc1ae7b65a6834d01() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitu7dd8e5932c1b447e8df2e283ef3fd77e1() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitue73e6468461a443cb8796a1e6dd8973a1() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waituefd7f2440b6641418388339f2c2370481() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu9c1fab456c4c44faa570645d7ddaad2b1() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd5u504','none','',500,'none','',500);
function waitu7e1ad110e94d4acb9d0cef6bfd8b771b1() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu1b0341d6d17a4ae2b3a0e6670a9a6cd91() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitub083f12a6b524b9d8d88ffd1a85b74511() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu9d027b7c5f294b84943184c174a687111() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitue0350971ef14406aa131beccd43f61791() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waitue0350971ef14406aa131beccd43f61791, 100);
}
setTimeout(waitu9d027b7c5f294b84943184c174a687111, 100);
}
setTimeout(waitub083f12a6b524b9d8d88ffd1a85b74511, 100);
}
setTimeout(waitu1b0341d6d17a4ae2b3a0e6670a9a6cd91, 100);
}
setTimeout(waitu7e1ad110e94d4acb9d0cef6bfd8b771b1, 100);
}
setTimeout(waitu9c1fab456c4c44faa570645d7ddaad2b1, 100);
}
setTimeout(waituefd7f2440b6641418388339f2c2370481, 100);
}
setTimeout(waitue73e6468461a443cb8796a1e6dd8973a1, 100);
}
setTimeout(waitu7dd8e5932c1b447e8df2e283ef3fd77e1, 100);
}
setTimeout(waitu32192a40485d479abc1ae7b65a6834d01, 100);

}
});
gv_vAlignTable['u337'] = 'center';gv_vAlignTable['u305'] = 'center';gv_vAlignTable['u524'] = 'center';document.getElementById('u399_img').tabIndex = 0;

u399.style.cursor = 'pointer';
$axure.eventManager.click('u399', function(e) {

if (true) {

	BringToFront("u303");
function waitua83b2fbf2bf645d79fc88aec720a4f041() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd1u322','none','',500,'none','',500);
function waitu682564184c9e464790d27d9c2baf4f821() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd2u322','none','',500,'none','',500);
function waitu0d6397d4b11842bdbe8ecf0812c9bcad1() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waituc18decb019ee4019af7df213db81b6431() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu9bf5baac8cca497ba1328804f84e75b01() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd3u322','none','',500,'none','',500);
function waitu7b898af8a70947cda73e45c4245d30b71() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitue4071d9c82654d989fa8e2930163dd2b1() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu4b34bd22edec4323b5a87fa6e5176cc31() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitufd5de992b2394337b85c09570dc9eeac1() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waituc84887218a13432aba3e8bec9f6a1bfb1() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waituc84887218a13432aba3e8bec9f6a1bfb1, 100);
}
setTimeout(waitufd5de992b2394337b85c09570dc9eeac1, 100);
}
setTimeout(waitu4b34bd22edec4323b5a87fa6e5176cc31, 100);
}
setTimeout(waitue4071d9c82654d989fa8e2930163dd2b1, 100);
}
setTimeout(waitu7b898af8a70947cda73e45c4245d30b71, 100);
}
setTimeout(waitu9bf5baac8cca497ba1328804f84e75b01, 100);
}
setTimeout(waituc18decb019ee4019af7df213db81b6431, 100);
}
setTimeout(waitu0d6397d4b11842bdbe8ecf0812c9bcad1, 100);
}
setTimeout(waitu682564184c9e464790d27d9c2baf4f821, 100);
}
setTimeout(waitua83b2fbf2bf645d79fc88aec720a4f041, 100);

}
});
u121.tabIndex = 0;

u121.style.cursor = 'pointer';
$axure.eventManager.click('u121', function(e) {

if (true) {

	SetPanelVisibility('u93','hidden','none',500);

}
});

$axure.eventManager.mouseover('u121', function(e) {
if (!IsTrueMouseOver('u121',e)) return;
if (true) {

	SetPanelVisibility('u109','','none',500);

}
});

$axure.eventManager.mouseout('u121', function(e) {
if (!IsTrueMouseOut('u121',e)) return;
if (true) {

	SetPanelVisibility('u109','hidden','none',500);

}
});
gv_vAlignTable['u340'] = 'top';gv_vAlignTable['u711'] = 'center';gv_vAlignTable['u517'] = 'center';gv_vAlignTable['u736'] = 'center';document.getElementById('u721_img').tabIndex = 0;

u721.style.cursor = 'pointer';
$axure.eventManager.click('u721', function(e) {

if (true) {

	SetPanelState('u135', 'pd16u135','none','',500,'none','',500);
function waitu78c94d2bdd9c4db2bba8b6094ff9cbf51() {

	SetPanelState('u135', 'pd17u135','none','',500,'none','',500);
function waituc856b1eab1c94d84b87efac23eadf2b81() {

	SetPanelState('u135', 'pd18u135','none','',500,'none','',500);
function waitu09ece43f42dd47adb8c74d1bb3b7054b1() {

	SetPanelState('u135', 'pd10u135','none','',500,'none','',500);
}
setTimeout(waitu09ece43f42dd47adb8c74d1bb3b7054b1, 100);
}
setTimeout(waituc856b1eab1c94d84b87efac23eadf2b81, 100);
}
setTimeout(waitu78c94d2bdd9c4db2bba8b6094ff9cbf51, 100);

}
});
gv_vAlignTable['u114'] = 'center';gv_vAlignTable['u333'] = 'center';gv_vAlignTable['u704'] = 'top';gv_vAlignTable['u577'] = 'center';gv_vAlignTable['u174'] = 'center';gv_vAlignTable['u301'] = 'center';u5.tabIndex = 0;

u5.style.cursor = 'pointer';
$axure.eventManager.click('u5', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u545'] = 'center';gv_vAlignTable['u764'] = 'top';gv_vAlignTable['u361'] = 'center';gv_vAlignTable['u732'] = 'center';document.getElementById('u757_img').tabIndex = 0;

u757.style.cursor = 'pointer';
$axure.eventManager.click('u757', function(e) {

if (true) {

	SetPanelState('u135', 'pd2u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u539'] = 'center';gv_vAlignTable['u758'] = 'center';gv_vAlignTable['u551'] = 'center';document.getElementById('u170_img').tabIndex = 0;

u170.style.cursor = 'pointer';
$axure.eventManager.click('u170', function(e) {

if (true) {

	SetPanelState('u135', 'pd3u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u760'] = 'center';gv_vAlignTable['u348'] = 'center';gv_vAlignTable['u719'] = 'top';gv_vAlignTable['u575'] = 'center';gv_vAlignTable['u51'] = 'center';document.getElementById('u779_img').tabIndex = 0;

u779.style.cursor = 'pointer';
$axure.eventManager.click('u779', function(e) {

if (true) {

	SetPanelState('u135', 'pd13u135','none','',500,'none','',500);
function waitu478e589c1043489ea4bc3677e2eee4151() {

	SetPanelState('u135', 'pd14u135','none','',500,'none','',500);
function waitua7757b639f5145959b303bcc4e83d08d1() {

	SetPanelState('u135', 'pd15u135','none','',500,'none','',500);
function waitued180271067541029c8a660febebf0ff1() {

	SetPanelState('u135', 'pd3u135','none','',500,'none','',500);
}
setTimeout(waitued180271067541029c8a660febebf0ff1, 100);
}
setTimeout(waitua7757b639f5145959b303bcc4e83d08d1, 100);
}
setTimeout(waitu478e589c1043489ea4bc3677e2eee4151, 100);

}
});
gv_vAlignTable['u353'] = 'top';gv_vAlignTable['u57'] = 'center';gv_vAlignTable['u715'] = 'center';gv_vAlignTable['u291'] = 'center';gv_vAlignTable['u196'] = 'center';gv_vAlignTable['u687'] = 'top';gv_vAlignTable['u617'] = 'center';gv_vAlignTable['u284'] = 'center';gv_vAlignTable['u263'] = 'top';document.getElementById('u683_img').tabIndex = 0;

u683.style.cursor = 'pointer';
$axure.eventManager.click('u683', function(e) {

if (true) {

	SetPanelState('u135', 'pd5u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u280'] = 'center';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u212'] = 'center';document.getElementById('u205_img').tabIndex = 0;

u205.style.cursor = 'pointer';
$axure.eventManager.click('u205', function(e) {

if (true) {

	SetPanelState('u135', 'pd11u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u424'] = 'center';gv_vAlignTable['u299'] = 'top';document.getElementById('u153_img').tabIndex = 0;

u153.style.cursor = 'pointer';
$axure.eventManager.click('u153', function(e) {

if (true) {

	SetPanelState('u135', 'pd1u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u240'] = 'center';document.getElementById('u611_img').tabIndex = 0;

u611.style.cursor = 'pointer';
$axure.eventManager.click('u611', function(e) {

if (true) {

	SetPanelState('u135', 'pd5u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u452'] = 'top';gv_vAlignTable['u698'] = 'top';gv_vAlignTable['u603'] = 'center';gv_vAlignTable['u420'] = 'center';document.getElementById('u445_img').tabIndex = 0;

u445.style.cursor = 'pointer';
$axure.eventManager.click('u445', function(e) {

if (true) {

	SetPanelState('u135', 'pd8u135','none','',500,'none','',500);

}
});
document.getElementById('u540_img').tabIndex = 0;

u540.style.cursor = 'pointer';
$axure.eventManager.click('u540', function(e) {

if (true) {

	BringToFront("u485");
function waitu1ff4b16d9a634ff6bd6047f638e7bafe1() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waituc268c348007146deb4be996f2b7e71591() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu9f299adbff854f1581f82087d6c8f0251() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitue922c53735fb4a52ab5aad6f902ee0331() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waituaae5879196fa48089a53695df15080121() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd5u504','none','',500,'none','',500);
function waitu38ff64633d954723977744344a821a921() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu6e88e82ee0e94a05b1719874a3d3ae231() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waituba75a8361c8446829859675baf589f461() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitue4e6ac503906440a84302aae4ad4442b1() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waituffc50390a87a425f973ff1b4551cf5f81() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waituffc50390a87a425f973ff1b4551cf5f81, 100);
}
setTimeout(waitue4e6ac503906440a84302aae4ad4442b1, 100);
}
setTimeout(waituba75a8361c8446829859675baf589f461, 100);
}
setTimeout(waitu6e88e82ee0e94a05b1719874a3d3ae231, 100);
}
setTimeout(waitu38ff64633d954723977744344a821a921, 100);
}
setTimeout(waituaae5879196fa48089a53695df15080121, 100);
}
setTimeout(waitue922c53735fb4a52ab5aad6f902ee0331, 100);
}
setTimeout(waitu9f299adbff854f1581f82087d6c8f0251, 100);
}
setTimeout(waituc268c348007146deb4be996f2b7e71591, 100);
}
setTimeout(waitu1ff4b16d9a634ff6bd6047f638e7bafe1, 100);

}
});
document.getElementById('u58_img').tabIndex = 0;
HookHover('u58', false);

u58.style.cursor = 'pointer';
$axure.eventManager.click('u58', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
document.getElementById('u439_img').tabIndex = 0;

u439.style.cursor = 'pointer';
$axure.eventManager.click('u439', function(e) {

if (true) {

	SetPanelState('u135', 'pd3u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u658'] = 'center';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u660'] = 'center';gv_vAlignTable['u248'] = 'center';gv_vAlignTable['u619'] = 'center';gv_vAlignTable['u791'] = 'center';gv_vAlignTable['u41'] = 'center';document.getElementById('u473_img').tabIndex = 0;

u473.style.cursor = 'pointer';
$axure.eventManager.click('u473', function(e) {

if (true) {

	SetPanelState('u135', 'pd3u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u108'] = 'center';document.getElementById('u38_img').tabIndex = 0;
HookHover('u38', false);

u38.style.cursor = 'pointer';
$axure.eventManager.click('u38', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
document.getElementById('u68_img').tabIndex = 0;
HookHover('u68', false);

u68.style.cursor = 'pointer';
$axure.eventManager.click('u68', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
document.getElementById('u587_img').tabIndex = 0;

u587.style.cursor = 'pointer';
$axure.eventManager.click('u587', function(e) {

if (true) {

	BringToFront("u485");
function waituea259d56f03548ba9899cd9225fb401d1() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd1u504','none','',500,'none','',500);
function waitu14a6e2d873df4fc5a4a5a9556b5bdea81() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd2u504','none','',500,'none','',500);
function waitu4c7130d946564f018b2f55333cf4e96e1() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu343853c49f5d40e49ca8aaf7c94bcb6b1() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu3e3fc62e16884299861f3262ab2006c41() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd6u504','none','',500,'none','',500);
function waitueb88275d245c41908a22cce5873d2aa21() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu8ef25fd117074d04bc54d140543e4ba51() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu29e99e60ecf543c6b652dd2cf568bacd1() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu0be70c55adce4ae2997fb1c376f4f3e71() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitu5db16dc112c04b46b22074a7c8d6f63c1() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waitu5db16dc112c04b46b22074a7c8d6f63c1, 100);
}
setTimeout(waitu0be70c55adce4ae2997fb1c376f4f3e71, 100);
}
setTimeout(waitu29e99e60ecf543c6b652dd2cf568bacd1, 100);
}
setTimeout(waitu8ef25fd117074d04bc54d140543e4ba51, 100);
}
setTimeout(waitueb88275d245c41908a22cce5873d2aa21, 100);
}
setTimeout(waitu3e3fc62e16884299861f3262ab2006c41, 100);
}
setTimeout(waitu343853c49f5d40e49ca8aaf7c94bcb6b1, 100);
}
setTimeout(waitu4c7130d946564f018b2f55333cf4e96e1, 100);
}
setTimeout(waitu14a6e2d873df4fc5a4a5a9556b5bdea81, 100);
}
setTimeout(waituea259d56f03548ba9899cd9225fb401d1, 100);

}
});
gv_vAlignTable['u184'] = 'center';u4.tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u4'] = 'top';document.getElementById('u583_img').tabIndex = 0;

u583.style.cursor = 'pointer';
$axure.eventManager.click('u583', function(e) {

if (true) {

	BringToFront("u485");
function waitubec89408914f46319e83a3f6558395c31() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd1u504','none','',500,'none','',500);
function waitud4fa8cb1055f4620b231e956790b24241() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd2u504','none','',500,'none','',500);
function waitu0affdb628432409b88b01072d1341cbc1() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitufd93429219ea4d8da63c08becf4799841() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu85a71df17b5240989ca785d90f6033841() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd4u504','none','',500,'none','',500);
function waituc62e1cbf0d84415fabee873f404b94881() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu83d11a21fe4a45be8f44df9b7c3930ae1() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitufafd2e22d2c7472eb8e466631f2fba751() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu3be2df74a10b41c5873bb0645283e7c41() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitubc5eff91539c4da0881cfb4ae48d83f81() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waitubc5eff91539c4da0881cfb4ae48d83f81, 100);
}
setTimeout(waitu3be2df74a10b41c5873bb0645283e7c41, 100);
}
setTimeout(waitufafd2e22d2c7472eb8e466631f2fba751, 100);
}
setTimeout(waitu83d11a21fe4a45be8f44df9b7c3930ae1, 100);
}
setTimeout(waituc62e1cbf0d84415fabee873f404b94881, 100);
}
setTimeout(waitu85a71df17b5240989ca785d90f6033841, 100);
}
setTimeout(waitufd93429219ea4d8da63c08becf4799841, 100);
}
setTimeout(waitu0affdb628432409b88b01072d1341cbc1, 100);
}
setTimeout(waitud4fa8cb1055f4620b231e956790b24241, 100);
}
setTimeout(waitubec89408914f46319e83a3f6558395c31, 100);

}
});
gv_vAlignTable['u180'] = 'center';gv_vAlignTable['u137'] = 'center';gv_vAlignTable['u105'] = 'center';gv_vAlignTable['u324'] = 'center';document.getElementById('u199_img').tabIndex = 0;

u199.style.cursor = 'pointer';
$axure.eventManager.click('u199', function(e) {

if (true) {

	SetPanelState('u135', 'pd3u135','none','',500,'none','',500);

}
});
document.getElementById('u253_img').tabIndex = 0;

u253.style.cursor = 'pointer';
$axure.eventManager.click('u253', function(e) {

if (true) {

	SetPanelState('u135', 'pd3u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u511'] = 'center';gv_vAlignTable['u317'] = 'center';document.getElementById('u536_img').tabIndex = 0;

u536.style.cursor = 'pointer';
$axure.eventManager.click('u536', function(e) {

if (true) {

	BringToFront("u485");
function waitu9e74b9b3370a4b68952979623df891601() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitu57223f7735ce4c5dacc9ee1c7f41c4dc1() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu18f6117f29f54249bb8432855c44bb501() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu058a42e4a7af49d8b0c16e59b00792ce1() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu08a0fca1088849e8a3a4a35bb088fae21() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd3u504','none','',500,'none','',500);
function waitubf3958be81894002b85f9cd41dfd31601() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitueeda13abb0704671aeb7396745225a4a1() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu0e9c75f998404aa3a64bea883af44be01() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu75fe7c1182c640e685e506fff473b6b51() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waituc29d30d508f848f6aa3a80983753e0131() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waituc29d30d508f848f6aa3a80983753e0131, 100);
}
setTimeout(waitu75fe7c1182c640e685e506fff473b6b51, 100);
}
setTimeout(waitu0e9c75f998404aa3a64bea883af44be01, 100);
}
setTimeout(waitueeda13abb0704671aeb7396745225a4a1, 100);
}
setTimeout(waitubf3958be81894002b85f9cd41dfd31601, 100);
}
setTimeout(waitu08a0fca1088849e8a3a4a35bb088fae21, 100);
}
setTimeout(waitu058a42e4a7af49d8b0c16e59b00792ce1, 100);
}
setTimeout(waitu18f6117f29f54249bb8432855c44bb501, 100);
}
setTimeout(waitu57223f7735ce4c5dacc9ee1c7f41c4dc1, 100);
}
setTimeout(waitu9e74b9b3370a4b68952979623df891601, 100);

}
});
gv_vAlignTable['u90'] = 'top';u133.tabIndex = 0;

u133.style.cursor = 'pointer';
$axure.eventManager.click('u133', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('My_details.html');

}
else
if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('LoginStatus')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u133'] = 'top';gv_vAlignTable['u352'] = 'center';document.getElementById('u723_img').tabIndex = 0;

u723.style.cursor = 'pointer';
$axure.eventManager.click('u723', function(e) {

if (true) {

	SetPanelState('u135', 'pd16u135','none','',500,'none','',500);
function waitu513cfa602d0f431c88dffecde68c66ee1() {

	SetPanelState('u135', 'pd17u135','none','',500,'none','',500);
function waitua94031065e9040da9a70d5463ec6b2911() {

	SetPanelState('u135', 'pd18u135','none','',500,'none','',500);
function waituad07eb97576f4b1e83b8d0d2e112c9a81() {

	SetPanelState('u135', 'pd11u135','none','',500,'none','',500);
}
setTimeout(waituad07eb97576f4b1e83b8d0d2e112c9a81, 100);
}
setTimeout(waitua94031065e9040da9a70d5463ec6b2911, 100);
}
setTimeout(waitu513cfa602d0f431c88dffecde68c66ee1, 100);

}
});
document.getElementById('u345_img').tabIndex = 0;

u345.style.cursor = 'pointer';
$axure.eventManager.click('u345', function(e) {

if (true) {

	BringToFront("u303");
function waituecb49a52820c45bc99fa324c29a5ea241() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitub8bce14ee29249c0a33f9b4f2d956c891() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu4b00eda0ba4340ff8405f618f5f55a3e1() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu63b601db53a74f8ba3332a13a30745051() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu086493974c054153bf9812f69d0a3eb01() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd5u322','none','',500,'none','',500);
function waitu13c87d6708914259bba5bb72102e1ed81() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu501bb1b438124769a932e27acc1a94801() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitua9818b92c9224b34944c9c3c0e7a26591() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitue76166ea65184af8b085b954fa48a0761() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitub8f39fc0dd01414bba88c0925333a7b81() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waitub8f39fc0dd01414bba88c0925333a7b81, 100);
}
setTimeout(waitue76166ea65184af8b085b954fa48a0761, 100);
}
setTimeout(waitua9818b92c9224b34944c9c3c0e7a26591, 100);
}
setTimeout(waitu501bb1b438124769a932e27acc1a94801, 100);
}
setTimeout(waitu13c87d6708914259bba5bb72102e1ed81, 100);
}
setTimeout(waitu086493974c054153bf9812f69d0a3eb01, 100);
}
setTimeout(waitu63b601db53a74f8ba3332a13a30745051, 100);
}
setTimeout(waitu4b00eda0ba4340ff8405f618f5f55a3e1, 100);
}
setTimeout(waitub8bce14ee29249c0a33f9b4f2d956c891, 100);
}
setTimeout(waituecb49a52820c45bc99fa324c29a5ea241, 100);

}
});
gv_vAlignTable['u564'] = 'center';gv_vAlignTable['u161'] = 'center';gv_vAlignTable['u532'] = 'center';gv_vAlignTable['u776'] = 'center';gv_vAlignTable['u339'] = 'center';gv_vAlignTable['u558'] = 'center';gv_vAlignTable['u373'] = 'center';document.getElementById('u744_img').tabIndex = 0;

u744.style.cursor = 'pointer';
$axure.eventManager.click('u744', function(e) {

if (true) {

	SetPanelState('u135', 'pd16u135','none','',500,'none','',500);
function waitub96cd80a08244660a2dc6bf5cbbbe1f71() {

	SetPanelState('u135', 'pd17u135','none','',500,'none','',500);
function waitu10a2b1ee4c45464fadb19c04e97071e91() {

	SetPanelState('u135', 'pd18u135','none','',500,'none','',500);
function waitu78ed6291c3494a3d82c0003788f619ef1() {

	SetPanelState('u135', 'pd7u135','none','',500,'none','',500);
}
setTimeout(waitu78ed6291c3494a3d82c0003788f619ef1, 100);
}
setTimeout(waitu10a2b1ee4c45464fadb19c04e97071e91, 100);
}
setTimeout(waitub96cd80a08244660a2dc6bf5cbbbe1f71, 100);

}
});
gv_vAlignTable['u560'] = 'center';gv_vAlignTable['u148'] = 'center';gv_vAlignTable['u519'] = 'center';gv_vAlignTable['u738'] = 'center';gv_vAlignTable['u772'] = 'center';gv_vAlignTable['u37'] = 'center';document.getElementById('u759_img').tabIndex = 0;

u759.style.cursor = 'pointer';
$axure.eventManager.click('u759', function(e) {

if (true) {

	SetPanelState('u135', 'pd3u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u296'] = 'top';document.getElementById('u330_img').tabIndex = 0;

u330.style.cursor = 'pointer';
$axure.eventManager.click('u330', function(e) {

if (true) {

	BringToFront("u303");
function waitu6e1c18ef002443ccbfef66b93a38b95b1() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitu82953e668bc24d62b6bd6d3072a9d5031() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu33a9a65fef5a4143bb75c45ba736dcc61() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu91c14095d7d84edcb055c82ba38a72071() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waituf8808efbd1454a8fb1db198b76c7a68d1() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd4u322','none','',500,'none','',500);
function waitu62540b90d5be4e75a00970f4cb0146341() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu5ca78bb2e7f4456b8184fa5bd8cf9f661() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitue118b108c8604762a882457c860b1b3a1() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitua47da60075f2402c96865932dd516c681() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitu4678400e98f544769992dfcd65e077571() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waitu4678400e98f544769992dfcd65e077571, 100);
}
setTimeout(waitua47da60075f2402c96865932dd516c681, 100);
}
setTimeout(waitue118b108c8604762a882457c860b1b3a1, 100);
}
setTimeout(waitu5ca78bb2e7f4456b8184fa5bd8cf9f661, 100);
}
setTimeout(waitu62540b90d5be4e75a00970f4cb0146341, 100);
}
setTimeout(waituf8808efbd1454a8fb1db198b76c7a68d1, 100);
}
setTimeout(waitu91c14095d7d84edcb055c82ba38a72071, 100);
}
setTimeout(waitu33a9a65fef5a4143bb75c45ba736dcc61, 100);
}
setTimeout(waitu82953e668bc24d62b6bd6d3072a9d5031, 100);
}
setTimeout(waitu6e1c18ef002443ccbfef66b93a38b95b1, 100);

}
});
gv_vAlignTable['u487'] = 'center';gv_vAlignTable['u463'] = 'top';u3.tabIndex = 0;

u3.style.cursor = 'pointer';
$axure.eventManager.click('u3', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u483'] = 'center';gv_vAlignTable['u367'] = 'center';gv_vAlignTable['u695'] = 'center';gv_vAlignTable['u224'] = 'top';gv_vAlignTable['u689'] = 'center';gv_vAlignTable['u436'] = 'center';gv_vAlignTable['u80'] = 'center';gv_vAlignTable['u404'] = 'center';gv_vAlignTable['u623'] = 'center';gv_vAlignTable['u86'] = 'center';gv_vAlignTable['u651'] = 'center';gv_vAlignTable['u676'] = 'center';gv_vAlignTable['u458'] = 'center';document.getElementById('u273_img').tabIndex = 0;

u273.style.cursor = 'pointer';
$axure.eventManager.click('u273', function(e) {

if (true) {

	SetPanelState('u135', 'pd2u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u460'] = 'center';document.getElementById('u638_img').tabIndex = 0;

u638.style.cursor = 'pointer';
$axure.eventManager.click('u638', function(e) {

if (true) {

	SetPanelState('u135', 'pd1u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u672'] = 'center';gv_vAlignTable['u479'] = 'center';document.getElementById('u443_img').tabIndex = 0;

u443.style.cursor = 'pointer';
$axure.eventManager.click('u443', function(e) {

if (true) {

	SetPanelState('u135', 'pd7u135','none','',500,'none','',500);

}
});
document.getElementById('u417_img').tabIndex = 0;

u417.style.cursor = 'pointer';
$axure.eventManager.click('u417', function(e) {

if (true) {

	SetPanelState('u135', 'pd3u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u176'] = 'center';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u387'] = 'center';u788.tabIndex = 0;

u788.style.cursor = 'pointer';
$axure.eventManager.click('u788', function(e) {

if (true) {

	SetPanelState('u135', 'pd0u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u788'] = 'top';gv_vAlignTable['u327'] = 'top';gv_vAlignTable['u786'] = 'top';gv_vAlignTable['u595'] = 'center';gv_vAlignTable['u782'] = 'center';u124.tabIndex = 0;

u124.style.cursor = 'pointer';
$axure.eventManager.click('u124', function(e) {

if (true) {

	self.location.href='index.html';

}
});
gv_vAlignTable['u124'] = 'top';gv_vAlignTable['u589'] = 'top';gv_vAlignTable['u311'] = 'center';gv_vAlignTable['u117'] = 'top';document.getElementById('u523_img').tabIndex = 0;

u523.style.cursor = 'pointer';
$axure.eventManager.click('u523', function(e) {

if (true) {

	BringToFront("u485");
function waituee462a1706b74406b61628299b4ff64f1() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitue1a87cc908ae4f44b02ea9ef5ea9ccb11() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu93b39e0f326f423484e7c9857affbf341() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu137a63a12a084ac2898dfa5c0f63eb2b1() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu0d592347048c44b98fd68f6333cbbf8b1() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd3u504','none','',500,'none','',500);
function waitu2c1a35d39b19475190972451693723ef1() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitucc88ea1c4cea417cb314a65c49036fde1() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu0acd190d29514b0ba90bd9922459c26b1() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu73c5c8539e1b47ae84a8055cf327d4471() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitu7280bf860be84b7c93dd73111a6987751() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waitu7280bf860be84b7c93dd73111a6987751, 100);
}
setTimeout(waitu73c5c8539e1b47ae84a8055cf327d4471, 100);
}
setTimeout(waitu0acd190d29514b0ba90bd9922459c26b1, 100);
}
setTimeout(waitucc88ea1c4cea417cb314a65c49036fde1, 100);
}
setTimeout(waitu2c1a35d39b19475190972451693723ef1, 100);
}
setTimeout(waitu0d592347048c44b98fd68f6333cbbf8b1, 100);
}
setTimeout(waitu137a63a12a084ac2898dfa5c0f63eb2b1, 100);
}
setTimeout(waitu93b39e0f326f423484e7c9857affbf341, 100);
}
setTimeout(waitue1a87cc908ae4f44b02ea9ef5ea9ccb11, 100);
}
setTimeout(waituee462a1706b74406b61628299b4ff64f1, 100);

}
});
gv_vAlignTable['u398'] = 'center';document.getElementById('u767_img').tabIndex = 0;

u767.style.cursor = 'pointer';
$axure.eventManager.click('u767', function(e) {

if (true) {

	SetPanelState('u135', 'pd16u135','none','',500,'none','',500);
function waitu3ef2f6f2860d4aa799604199dc5af5791() {

	SetPanelState('u135', 'pd17u135','none','',500,'none','',500);
function waitu0f3fd426fc6241abae77592c929921fd1() {

	SetPanelState('u135', 'pd18u135','none','',500,'none','',500);
function waituf37e374d66a7443485af5915de6c1d9a1() {

	SetPanelState('u135', 'pd7u135','none','',500,'none','',500);
}
setTimeout(waituf37e374d66a7443485af5915de6c1d9a1, 100);
}
setTimeout(waitu0f3fd426fc6241abae77592c929921fd1, 100);
}
setTimeout(waitu3ef2f6f2860d4aa799604199dc5af5791, 100);

}
});
gv_vAlignTable['u154'] = 'center';u120.tabIndex = 0;

u120.style.cursor = 'pointer';
$axure.eventManager.click('u120', function(e) {

if (true) {

	SetPanelVisibility('u93','hidden','none',500);

}
});

$axure.eventManager.mouseover('u120', function(e) {
if (!IsTrueMouseOver('u120',e)) return;
if (true) {

	SetPanelVisibility('u106','','none',500);

}
});

$axure.eventManager.mouseout('u120', function(e) {
if (!IsTrueMouseOut('u120',e)) return;
if (true) {

	SetPanelVisibility('u106','hidden','none',500);

}
});
gv_vAlignTable['u605'] = 'center';document.getElementById('u516_img').tabIndex = 0;

u516.style.cursor = 'pointer';
$axure.eventManager.click('u516', function(e) {

if (true) {

	BringToFront("u485");
function waitu590273513ed9436aa4fdec8dba3d76941() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitudbd29e73b44648a3b2a3ad27b5f512111() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitub655a9c0fae24a36a58da1dff03fd9ae1() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu135a921764544137a13f1584c5529c6d1() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitud622d01caca8443daf7aa3ab5b535f181() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd6u504','none','',500,'none','',500);
function waitu733ae1ec84c84d7d8bc1b2dd74950e741() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu0dccd57622e24ff9aee55410f72ad1781() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu2b3a04ef766043a99a04716420f77e5f1() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu04aab818ad844ecca2f7c85401f0b5c01() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitu0575030b0589481e95b8780df1f05d8a1() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waitu0575030b0589481e95b8780df1f05d8a1, 100);
}
setTimeout(waitu04aab818ad844ecca2f7c85401f0b5c01, 100);
}
setTimeout(waitu2b3a04ef766043a99a04716420f77e5f1, 100);
}
setTimeout(waitu0dccd57622e24ff9aee55410f72ad1781, 100);
}
setTimeout(waitu733ae1ec84c84d7d8bc1b2dd74950e741, 100);
}
setTimeout(waitud622d01caca8443daf7aa3ab5b535f181, 100);
}
setTimeout(waitu135a921764544137a13f1584c5529c6d1, 100);
}
setTimeout(waitub655a9c0fae24a36a58da1dff03fd9ae1, 100);
}
setTimeout(waitudbd29e73b44648a3b2a3ad27b5f512111, 100);
}
setTimeout(waitu590273513ed9436aa4fdec8dba3d76941, 100);

}
});
document.getElementById('u604_img').tabIndex = 0;

u604.style.cursor = 'pointer';
$axure.eventManager.click('u604', function(e) {

if (true) {

	SetPanelState('u135', 'pd3u135','none','',500,'none','',500);

}
});
document.getElementById('u332_img').tabIndex = 0;

u332.style.cursor = 'pointer';
$axure.eventManager.click('u332', function(e) {

if (true) {

	BringToFront("u303");
function waitua613447af0524d82bf3c17dea3e1ffba1() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waituab60d3881c984454badfdec85dd644861() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitufd3e6c2d16804e7c968550997fd718d01() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu27766848b76940a1828b6f3d8f7036861() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitud084239d218546af924c7a68e32f2af11() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd5u322','none','',500,'none','',500);
function waitue7285338587c402997b2cee1a03d93b41() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waituaa69a04e0dda49258e429e2eba5cb3061() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu66b8e13d89a340dcadab7673b80dcc961() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu919f53be9fb5405f92b4231a32f09b931() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitu1d5875a260404a3ba9dab5c3245d37a51() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waitu1d5875a260404a3ba9dab5c3245d37a51, 100);
}
setTimeout(waitu919f53be9fb5405f92b4231a32f09b931, 100);
}
setTimeout(waitu66b8e13d89a340dcadab7673b80dcc961, 100);
}
setTimeout(waituaa69a04e0dda49258e429e2eba5cb3061, 100);
}
setTimeout(waitue7285338587c402997b2cee1a03d93b41, 100);
}
setTimeout(waitud084239d218546af924c7a68e32f2af11, 100);
}
setTimeout(waitu27766848b76940a1828b6f3d8f7036861, 100);
}
setTimeout(waitufd3e6c2d16804e7c968550997fd718d01, 100);
}
setTimeout(waituab60d3881c984454badfdec85dd644861, 100);
}
setTimeout(waitua613447af0524d82bf3c17dea3e1ffba1, 100);

}
});
gv_vAlignTable['u703'] = 'center';gv_vAlignTable['u357'] = 'center';gv_vAlignTable['u139'] = 'center';document.getElementById('u358_img').tabIndex = 0;

u358.style.cursor = 'pointer';
$axure.eventManager.click('u358', function(e) {

if (true) {

	BringToFront("u303");
function waitu1ff4b16d9a634ff6bd6047f638e7bafe1() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waituc268c348007146deb4be996f2b7e71591() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu9f299adbff854f1581f82087d6c8f0251() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitue922c53735fb4a52ab5aad6f902ee0331() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waituaae5879196fa48089a53695df15080121() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd5u322','none','',500,'none','',500);
function waitu38ff64633d954723977744344a821a921() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu6e88e82ee0e94a05b1719874a3d3ae231() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waituba75a8361c8446829859675baf589f461() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitue4e6ac503906440a84302aae4ad4442b1() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waituffc50390a87a425f973ff1b4551cf5f81() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waituffc50390a87a425f973ff1b4551cf5f81, 100);
}
setTimeout(waitue4e6ac503906440a84302aae4ad4442b1, 100);
}
setTimeout(waituba75a8361c8446829859675baf589f461, 100);
}
setTimeout(waitu6e88e82ee0e94a05b1719874a3d3ae231, 100);
}
setTimeout(waitu38ff64633d954723977744344a821a921, 100);
}
setTimeout(waituaae5879196fa48089a53695df15080121, 100);
}
setTimeout(waitue922c53735fb4a52ab5aad6f902ee0331, 100);
}
setTimeout(waitu9f299adbff854f1581f82087d6c8f0251, 100);
}
setTimeout(waituc268c348007146deb4be996f2b7e71591, 100);
}
setTimeout(waitu1ff4b16d9a634ff6bd6047f638e7bafe1, 100);

}
});
document.getElementById('u729_img').tabIndex = 0;

u729.style.cursor = 'pointer';
$axure.eventManager.click('u729', function(e) {

if (true) {

	SetPanelState('u135', 'pd1u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u763'] = 'center';document.getElementById('u360_img').tabIndex = 0;

u360.style.cursor = 'pointer';
$axure.eventManager.click('u360', function(e) {

if (true) {

	BringToFront("u303");
function waitu9077dcee75224f019b321212220ba4691() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitub0e648ab99b14e1d9ffa16b2909b94711() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waituf6f1017c97a043758dbb318c5d91b6031() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu4503a8d5685240c5b0b1ac1bdd3346ad1() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitubf83cff978334417895110e0f98f9e431() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd6u322','none','',500,'none','',500);
function waitu94d10b6941ba428dbaa8112903d79a361() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitueb37b10980f04c9e8f90ead0317fa3191() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitub621daf5d2274728a48af221570bb3641() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitufd99bab5c44e4b1c8fe4a43824a25b741() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waituecc382b3f3294e95b71a2241d8eca2c51() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waituecc382b3f3294e95b71a2241d8eca2c51, 100);
}
setTimeout(waitufd99bab5c44e4b1c8fe4a43824a25b741, 100);
}
setTimeout(waitub621daf5d2274728a48af221570bb3641, 100);
}
setTimeout(waitueb37b10980f04c9e8f90ead0317fa3191, 100);
}
setTimeout(waitu94d10b6941ba428dbaa8112903d79a361, 100);
}
setTimeout(waitubf83cff978334417895110e0f98f9e431, 100);
}
setTimeout(waitu4503a8d5685240c5b0b1ac1bdd3346ad1, 100);
}
setTimeout(waituf6f1017c97a043758dbb318c5d91b6031, 100);
}
setTimeout(waitub0e648ab99b14e1d9ffa16b2909b94711, 100);
}
setTimeout(waitu9077dcee75224f019b321212220ba4691, 100);

}
});
gv_vAlignTable['u756'] = 'center';gv_vAlignTable['u319'] = 'center';document.getElementById('u538_img').tabIndex = 0;

u538.style.cursor = 'pointer';
$axure.eventManager.click('u538', function(e) {

if (true) {

	BringToFront("u485");
function waituaff75c67ef7941af9ae915e90562a29a1() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitubdb50c743e6b41aea2a5eddccdb6d6b91() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu3caa22324fce413e9f037070cf4453871() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitue13c912b2474419b9be67c72ad0a6c8c1() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitub8452847438e43df83286b1cda80811c1() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd4u504','none','',500,'none','',500);
function waitu4a7ae62667444ddba8a190be1ce92ea71() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu94d0bf65460c4ebcbc5fa325e93e04e31() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu693abee1697b459abc2e8e5f6bdeb47f1() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu75e12276c3ee45ab9556cb5a1c3fd2321() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitu9462cfcac5f94e398928a1f6a23f8da61() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waitu9462cfcac5f94e398928a1f6a23f8da61, 100);
}
setTimeout(waitu75e12276c3ee45ab9556cb5a1c3fd2321, 100);
}
setTimeout(waitu693abee1697b459abc2e8e5f6bdeb47f1, 100);
}
setTimeout(waitu94d0bf65460c4ebcbc5fa325e93e04e31, 100);
}
setTimeout(waitu4a7ae62667444ddba8a190be1ce92ea71, 100);
}
setTimeout(waitub8452847438e43df83286b1cda80811c1, 100);
}
setTimeout(waitue13c912b2474419b9be67c72ad0a6c8c1, 100);
}
setTimeout(waitu3caa22324fce413e9f037070cf4453871, 100);
}
setTimeout(waitubdb50c743e6b41aea2a5eddccdb6d6b91, 100);
}
setTimeout(waituaff75c67ef7941af9ae915e90562a29a1, 100);

}
});
gv_vAlignTable['u556'] = 'top';u11.tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u11'] = 'top';document.getElementById('u70_img').tabIndex = 0;
HookHover('u70', false);

u70.style.cursor = 'pointer';
$axure.eventManager.click('u70', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u718'] = 'top';gv_vAlignTable['u778'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u287'] = 'center';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u686'] = 'center';document.getElementById('u283_img').tabIndex = 0;

u283.style.cursor = 'pointer';
$axure.eventManager.click('u283', function(e) {

if (true) {

	SetPanelState('u135', 'pd12u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u495'] = 'center';gv_vAlignTable['u682'] = 'center';gv_vAlignTable['u489'] = 'center';gv_vAlignTable['u553'] = 'center';document.getElementById('u28_img').tabIndex = 0;

u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u236'] = 'center';gv_vAlignTable['u204'] = 'center';gv_vAlignTable['u298'] = 'center';gv_vAlignTable['u610'] = 'center';gv_vAlignTable['u416'] = 'center';gv_vAlignTable['u232'] = 'center';gv_vAlignTable['u451'] = 'top';document.getElementById('u257_img').tabIndex = 0;

u257.style.cursor = 'pointer';
$axure.eventManager.click('u257', function(e) {

if (true) {

	SetPanelState('u135', 'pd10u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u258'] = 'center';gv_vAlignTable['u84'] = 'center';gv_vAlignTable['u444'] = 'center';gv_vAlignTable['u663'] = 'top';gv_vAlignTable['u260'] = 'center';gv_vAlignTable['u631'] = 'center';gv_vAlignTable['u656'] = 'center';gv_vAlignTable['u749'] = 'center';gv_vAlignTable['u438'] = 'center';gv_vAlignTable['u472'] = 'center';document.getElementById('u60_img').tabIndex = 0;
HookHover('u60', false);

u60.style.cursor = 'pointer';
$axure.eventManager.click('u60', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
document.getElementById('u66_img').tabIndex = 0;
HookHover('u66', false);

u66.style.cursor = 'pointer';
$axure.eventManager.click('u66', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u678'] = 'center';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u606'] = 'top';gv_vAlignTable['u190'] = 'center';gv_vAlignTable['u586'] = 'center';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u395'] = 'center';document.getElementById('u157_img').tabIndex = 0;

u157.style.cursor = 'pointer';
$axure.eventManager.click('u157', function(e) {

if (true) {

	SetPanelState('u135', 'pd3u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u582'] = 'center';gv_vAlignTable['u389'] = 'center';gv_vAlignTable['u111'] = 'center';gv_vAlignTable['u726'] = 'center';gv_vAlignTable['u198'] = 'center';gv_vAlignTable['u567'] = 'top';document.getElementById('u510_img').tabIndex = 0;

u510.style.cursor = 'pointer';
$axure.eventManager.click('u510', function(e) {

if (true) {

	BringToFront("u485");
function waitu24582ae6e61b4727819b347022c8dfe71() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waituec2c6fe626b344c3b7e4805066a107111() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu2192c9b28d314c0eaf5bdf1a4e48206a1() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu10c68b7c398f4f6298f7221c6905e7c01() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu165f8fb7a4e14d52a511bcffff2c90cd1() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd3u504','none','',500,'none','',500);
function waitue4fe3a58ae6240159bec385d81baff651() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu17c5257a42094902bf98d8c4d22a596c1() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu090bdb88ca47405086631594861bcf5d1() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu14e17b9940574b4db0676ad24928ec801() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitu1deeffc5d6204f59bd44ff4684dd5be91() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waitu1deeffc5d6204f59bd44ff4684dd5be91, 100);
}
setTimeout(waitu14e17b9940574b4db0676ad24928ec801, 100);
}
setTimeout(waitu090bdb88ca47405086631594861bcf5d1, 100);
}
setTimeout(waitu17c5257a42094902bf98d8c4d22a596c1, 100);
}
setTimeout(waitue4fe3a58ae6240159bec385d81baff651, 100);
}
setTimeout(waitu165f8fb7a4e14d52a511bcffff2c90cd1, 100);
}
setTimeout(waitu10c68b7c398f4f6298f7221c6905e7c01, 100);
}
setTimeout(waitu2192c9b28d314c0eaf5bdf1a4e48206a1, 100);
}
setTimeout(waituec2c6fe626b344c3b7e4805066a107111, 100);
}
setTimeout(waitu24582ae6e61b4727819b347022c8dfe71, 100);

}
});
gv_vAlignTable['u535'] = 'top';gv_vAlignTable['u754'] = 'center';u132.tabIndex = 0;

u132.style.cursor = 'pointer';
$axure.eventManager.click('u132', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u503'] = 'center';gv_vAlignTable['u722'] = 'center';gv_vAlignTable['u376'] = 'center';gv_vAlignTable['u747'] = 'center';gv_vAlignTable['u158'] = 'center';document.getElementById('u529_img').tabIndex = 0;

u529.style.cursor = 'pointer';
$axure.eventManager.click('u529', function(e) {

if (true) {

	BringToFront("u485");
function waitu0f43c2028d0f430e8bb632eb8338094c1() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitu7b4eda0dac0044ccb8e9d247eb566f241() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu7f6a9c51740b46e88fda601c67a9cece1() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu294c203027c445a396244d81e147ba161() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu420f045424b54f12ac15b421cafd843e1() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd6u504','none','',500,'none','',500);
function waitu2807cb86418d4b08a21ee2bfdeab49da1() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waituc98f56ec7f1b425baeb31be972ef87241() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitue3060952855a43b5b9b3be65bdfe8d5b1() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu67714a70cfea406d98797df4231078811() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waituc77f8f214469414e80c9dfb88c8748c61() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waituc77f8f214469414e80c9dfb88c8748c61, 100);
}
setTimeout(waitu67714a70cfea406d98797df4231078811, 100);
}
setTimeout(waitue3060952855a43b5b9b3be65bdfe8d5b1, 100);
}
setTimeout(waituc98f56ec7f1b425baeb31be972ef87241, 100);
}
setTimeout(waitu2807cb86418d4b08a21ee2bfdeab49da1, 100);
}
setTimeout(waitu420f045424b54f12ac15b421cafd843e1, 100);
}
setTimeout(waitu294c203027c445a396244d81e147ba161, 100);
}
setTimeout(waitu7f6a9c51740b46e88fda601c67a9cece1, 100);
}
setTimeout(waitu7b4eda0dac0044ccb8e9d247eb566f241, 100);
}
setTimeout(waitu0f43c2028d0f430e8bb632eb8338094c1, 100);

}
});
gv_vAlignTable['u220'] = 'top';gv_vAlignTable['u344'] = 'center';document.getElementById('u50_img').tabIndex = 0;
HookHover('u50', false);

u50.style.cursor = 'pointer';
$axure.eventManager.click('u50', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u750'] = 'top';document.getElementById('u40_img').tabIndex = 0;
HookHover('u40', false);

u40.style.cursor = 'pointer';
$axure.eventManager.click('u40', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u119'] = 'top';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u743'] = 'top';document.getElementById('u769_img').tabIndex = 0;

u769.style.cursor = 'pointer';
$axure.eventManager.click('u769', function(e) {

if (true) {

	SetPanelState('u135', 'pd16u135','none','',500,'none','',500);
function waitu28622470268c43f09b561221c1e0a65a1() {

	SetPanelState('u135', 'pd17u135','none','',500,'none','',500);
function waitu0a3921c02dd84dad8b1f45bd6e9411321() {

	SetPanelState('u135', 'pd18u135','none','',500,'none','',500);
function waitue67bfd2cb1be4625b83eaa01246ba4541() {

	SetPanelState('u135', 'pd8u135','none','',500,'none','',500);
}
setTimeout(waitue67bfd2cb1be4625b83eaa01246ba4541, 100);
}
setTimeout(waitu0a3921c02dd84dad8b1f45bd6e9411321, 100);
}
setTimeout(waitu28622470268c43f09b561221c1e0a65a1, 100);

}
});
document.getElementById('u56_img').tabIndex = 0;
HookHover('u56', false);

u56.style.cursor = 'pointer';
$axure.eventManager.click('u56', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u145'] = 'center';document.getElementById('u771_img').tabIndex = 0;

u771.style.cursor = 'pointer';
$axure.eventManager.click('u771', function(e) {

if (true) {

	SetPanelState('u135', 'pd16u135','none','',500,'none','',500);
function waitu17eb0af3c13f463f9b4a33babfda42231() {

	SetPanelState('u135', 'pd17u135','none','',500,'none','',500);
function waitua99dae2af8174b4c80a96b21ef7bb0a61() {

	SetPanelState('u135', 'pd18u135','none','',500,'none','',500);
function waitu7b7a9a95101f4fc0a92a03393cc157a11() {

	SetPanelState('u135', 'pd9u135','none','',500,'none','',500);
}
setTimeout(waitu7b7a9a95101f4fc0a92a03393cc157a11, 100);
}
setTimeout(waitua99dae2af8174b4c80a96b21ef7bb0a61, 100);
}
setTimeout(waitu17eb0af3c13f463f9b4a33babfda42231, 100);

}
});
u8.tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u359'] = 'center';gv_vAlignTable['u578'] = 'top';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u191'] = 'top';gv_vAlignTable['u627'] = 'top';gv_vAlignTable['u295'] = 'top';document.getElementById('u482_img').tabIndex = 0;

u482.style.cursor = 'pointer';
$axure.eventManager.click('u482', function(e) {

if (true) {

	SetPanelState('u135', 'pd9u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u289'] = 'center';gv_vAlignTable['u407'] = 'top';gv_vAlignTable['u626'] = 'top';gv_vAlignTable['u223'] = 'top';gv_vAlignTable['u254'] = 'center';document.getElementById('u435_img').tabIndex = 0;

u435.style.cursor = 'pointer';
$axure.eventManager.click('u435', function(e) {

if (true) {

	SetPanelState('u135', 'pd1u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u654'] = 'center';document.getElementById('u403_img').tabIndex = 0;

u403.style.cursor = 'pointer';
$axure.eventManager.click('u403', function(e) {

if (true) {

	BringToFront("u303");
function waitu3d06e0964c1a43fb90476ca3ba9b59301() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd1u322','none','',500,'none','',500);
function waitu674f4c2036514892a5d5631cb211f83c1() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd2u322','none','',500,'none','',500);
function waitu522bf99fe7f1487b85867799c80701011() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitub7568fca87c8402a99450d80242e24e71() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu63da5e332241428cacde9e5ebb09294e1() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd5u322','none','',500,'none','',500);
function waitu0d33db81425946b99f100ccae3986a311() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitue3af3fc9ded1455cb95601cb2ad7c55f1() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu7bc9e445656243d79b0311592f2215331() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu51cf844f619f48409321b35102cf95751() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitu2b9fcec4ec43425da9cff7b00c2977dd1() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waitu2b9fcec4ec43425da9cff7b00c2977dd1, 100);
}
setTimeout(waitu51cf844f619f48409321b35102cf95751, 100);
}
setTimeout(waitu7bc9e445656243d79b0311592f2215331, 100);
}
setTimeout(waitue3af3fc9ded1455cb95601cb2ad7c55f1, 100);
}
setTimeout(waitu0d33db81425946b99f100ccae3986a311, 100);
}
setTimeout(waitu63da5e332241428cacde9e5ebb09294e1, 100);
}
setTimeout(waitub7568fca87c8402a99450d80242e24e71, 100);
}
setTimeout(waitu522bf99fe7f1487b85867799c80701011, 100);
}
setTimeout(waitu674f4c2036514892a5d5631cb211f83c1, 100);
}
setTimeout(waitu3d06e0964c1a43fb90476ca3ba9b59301, 100);

}
});
gv_vAlignTable['u276'] = 'center';gv_vAlignTable['u647'] = 'center';gv_vAlignTable['u244'] = 'top';gv_vAlignTable['u615'] = 'top';gv_vAlignTable['u431'] = 'top';document.getElementById('u650_img').tabIndex = 0;

u650.style.cursor = 'pointer';
$axure.eventManager.click('u650', function(e) {

if (true) {

	SetPanelState('u135', 'pd6u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u456'] = 'center';document.getElementById('u675_img').tabIndex = 0;

u675.style.cursor = 'pointer';
$axure.eventManager.click('u675', function(e) {

if (true) {

	SetPanelState('u135', 'pd2u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u238'] = 'center';document.getElementById('u609_img').tabIndex = 0;

u609.style.cursor = 'pointer';
$axure.eventManager.click('u609', function(e) {

if (true) {

	SetPanelState('u135', 'pd4u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u272'] = 'center';gv_vAlignTable['u643'] = 'center';gv_vAlignTable['u669'] = 'top';HookHover('u46', false);
gv_vAlignTable['u418'] = 'center';document.getElementById('u478_img').tabIndex = 0;

u478.style.cursor = 'pointer';
$axure.eventManager.click('u478', function(e) {

if (true) {

	SetPanelState('u135', 'pd7u135','none','',500,'none','',500);

}
});
document.getElementById('u64_img').tabIndex = 0;
HookHover('u64', false);

u64.style.cursor = 'pointer';
$axure.eventManager.click('u64', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u621'] = 'center';gv_vAlignTable['u264'] = 'top';document.getElementById('u195_img').tabIndex = 0;

u195.style.cursor = 'pointer';
$axure.eventManager.click('u195', function(e) {

if (true) {

	SetPanelState('u135', 'pd1u135','none','',500,'none','',500);

}
});
u785.tabIndex = 0;

u785.style.cursor = 'pointer';
$axure.eventManager.click('u785', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u785'] = 'top';gv_vAlignTable['u382'] = 'center';gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u307'] = 'center';gv_vAlignTable['u526'] = 'center';gv_vAlignTable['u216'] = 'center';document.getElementById('u781_img').tabIndex = 0;

u781.style.cursor = 'pointer';
$axure.eventManager.click('u781', function(e) {

if (true) {

	SetPanelState('u135', 'pd13u135','none','',500,'none','',500);
function waitu339edb09db5b4ceeb73a1e754801ad001() {

	SetPanelState('u135', 'pd14u135','none','',500,'none','',500);
function waitu359d1a8563a94e9da746ca9397f092041() {

	SetPanelState('u135', 'pd15u135','none','',500,'none','',500);
function waitu366c3e0639e44db9a5466170e85dc6251() {

	SetPanelState('u135', 'pd1u135','none','',500,'none','',500);
}
setTimeout(waitu366c3e0639e44db9a5466170e85dc6251, 100);
}
setTimeout(waitu359d1a8563a94e9da746ca9397f092041, 100);
}
setTimeout(waitu339edb09db5b4ceeb73a1e754801ad001, 100);

}
});

$axure.eventManager.keyup('u123', function(e) {

if ((GetWidgetText('u123')) == ('')) {

	SetPanelVisibility('u93','hidden','none',500);

}
else
if (true) {

	SetPanelState('u93', 'pd0u93','none','',500,'none','',500);

SetGlobalVariableValue('IncrementalSearchVar', GetWidgetText('u123'));

SetWidgetRichText('u115', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dada</span></p>');

SetWidgetRichText('u116', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dat</span></p>');

SetWidgetRichText('u117', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">gi</span></p>');

SetWidgetRichText('u119', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

SetWidgetRichText('u99', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

	SetPanelVisibility('u93','','none',500);

	BringToFront("u93");
function waitu796b5745765043a58e9fe38835b455f51() {

	SetPanelState('u93', 'pd1u93','none','',500,'none','',500);
}
setTimeout(waitu796b5745765043a58e9fe38835b455f51, 2000);

}
});

$axure.eventManager.blur('u123', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u123'));

}
});
gv_vAlignTable['u713'] = 'center';gv_vAlignTable['u588'] = 'center';gv_vAlignTable['u116'] = 'top';gv_vAlignTable['u335'] = 'center';gv_vAlignTable['u706'] = 'center';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u522'] = 'top';gv_vAlignTable['u741'] = 'top';gv_vAlignTable['u547'] = 'center';gv_vAlignTable['u766'] = 'top';gv_vAlignTable['u329'] = 'center';document.getElementById('u144_img').tabIndex = 0;

u144.style.cursor = 'pointer';
$axure.eventManager.click('u144', function(e) {

if (true) {

	SetPanelState('u135', 'pd3u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u515'] = 'center';gv_vAlignTable['u734'] = 'center';gv_vAlignTable['u331'] = 'center';document.getElementById('u356_img').tabIndex = 0;

u356.style.cursor = 'pointer';
$axure.eventManager.click('u356', function(e) {

if (true) {

	BringToFront("u303");
function waituaff75c67ef7941af9ae915e90562a29a1() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitubdb50c743e6b41aea2a5eddccdb6d6b91() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu3caa22324fce413e9f037070cf4453871() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitue13c912b2474419b9be67c72ad0a6c8c1() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitub8452847438e43df83286b1cda80811c1() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd4u322','none','',500,'none','',500);
function waitu4a7ae62667444ddba8a190be1ce92ea71() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu94d0bf65460c4ebcbc5fa325e93e04e31() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu693abee1697b459abc2e8e5f6bdeb47f1() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu75e12276c3ee45ab9556cb5a1c3fd2321() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitu9462cfcac5f94e398928a1f6a23f8da61() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waitu9462cfcac5f94e398928a1f6a23f8da61, 100);
}
setTimeout(waitu75e12276c3ee45ab9556cb5a1c3fd2321, 100);
}
setTimeout(waitu693abee1697b459abc2e8e5f6bdeb47f1, 100);
}
setTimeout(waitu94d0bf65460c4ebcbc5fa325e93e04e31, 100);
}
setTimeout(waitu4a7ae62667444ddba8a190be1ce92ea71, 100);
}
setTimeout(waitub8452847438e43df83286b1cda80811c1, 100);
}
setTimeout(waitue13c912b2474419b9be67c72ad0a6c8c1, 100);
}
setTimeout(waitu3caa22324fce413e9f037070cf4453871, 100);
}
setTimeout(waitubdb50c743e6b41aea2a5eddccdb6d6b91, 100);
}
setTimeout(waituaff75c67ef7941af9ae915e90562a29a1, 100);

}
});
gv_vAlignTable['u509'] = 'top';gv_vAlignTable['u728'] = 'center';gv_vAlignTable['u172'] = 'top';gv_vAlignTable['u569'] = 'center';gv_vAlignTable['u730'] = 'center';document.getElementById('u36_img').tabIndex = 0;
HookHover('u36', false);

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u571'] = 'center';gv_vAlignTable['u159'] = 'top';gv_vAlignTable['u378'] = 'center';gv_vAlignTable['u65'] = 'center';gv_vAlignTable['u596'] = 'top';document.getElementById('u54_img').tabIndex = 0;
HookHover('u54', false);

u54.style.cursor = 'pointer';
$axure.eventManager.click('u54', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
document.getElementById('u685_img').tabIndex = 0;

u685.style.cursor = 'pointer';
$axure.eventManager.click('u685', function(e) {

if (true) {

	SetPanelState('u135', 'pd6u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u282'] = 'center';gv_vAlignTable['u89'] = 'top';gv_vAlignTable['u426'] = 'center';document.getElementById('u681_img').tabIndex = 0;

u681.style.cursor = 'pointer';
$axure.eventManager.click('u681', function(e) {

if (true) {

	SetPanelState('u135', 'pd4u135','none','',500,'none','',500);

}
});
document.getElementById('u613_img').tabIndex = 0;

u613.style.cursor = 'pointer';
$axure.eventManager.click('u613', function(e) {

if (true) {

	SetPanelState('u135', 'pd6u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u267'] = 'top';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u709'] = 'top';gv_vAlignTable['u454'] = 'center';document.getElementById('u203_img').tabIndex = 0;

u203.style.cursor = 'pointer';
$axure.eventManager.click('u203', function(e) {

if (true) {

	SetPanelState('u135', 'pd10u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u422'] = 'center';gv_vAlignTable['u641'] = 'center';document.getElementById('u447_img').tabIndex = 0;

u447.style.cursor = 'pointer';
$axure.eventManager.click('u447', function(e) {

if (true) {

	SetPanelState('u135', 'pd9u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u666'] = 'top';gv_vAlignTable['u229'] = 'top';gv_vAlignTable['u634'] = 'top';document.getElementById('u602_img').tabIndex = 0;

u602.style.cursor = 'pointer';
$axure.eventManager.click('u602', function(e) {

if (true) {

	SetPanelState('u135', 'pd2u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u256'] = 'center';gv_vAlignTable['u475'] = 'top';gv_vAlignTable['u409'] = 'center';gv_vAlignTable['u628'] = 'top';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u662'] = 'top';document.getElementById('u469_img').tabIndex = 0;

u469.style.cursor = 'pointer';
$axure.eventManager.click('u469', function(e) {

if (true) {

	SetPanelState('u135', 'pd1u135','none','',500,'none','',500);

}
});
u26.tabIndex = 0;

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href='http://www.lucabenazzi.eu';

}
});
gv_vAlignTable['u218'] = 'center';gv_vAlignTable['u573'] = 'center';document.getElementById('u471_img').tabIndex = 0;

u471.style.cursor = 'pointer';
$axure.eventManager.click('u471', function(e) {

if (true) {

	SetPanelState('u135', 'pd2u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u278'] = 'center';gv_vAlignTable['u649'] = 'center';document.getElementById('u44_img').tabIndex = 0;
HookHover('u44', false);

u44.style.cursor = 'pointer';
$axure.eventManager.click('u44', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
document.getElementById('u62_img').tabIndex = 0;
HookHover('u62', false);

u62.style.cursor = 'pointer';
$axure.eventManager.click('u62', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u186'] = 'center';gv_vAlignTable['u464'] = 'top';document.getElementById('u585_img').tabIndex = 0;

u585.style.cursor = 'pointer';
$axure.eventManager.click('u585', function(e) {

if (true) {

	BringToFront("u485");
function waitu3d06e0964c1a43fb90476ca3ba9b59301() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd1u504','none','',500,'none','',500);
function waitu674f4c2036514892a5d5631cb211f83c1() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd2u504','none','',500,'none','',500);
function waitu522bf99fe7f1487b85867799c80701011() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitub7568fca87c8402a99450d80242e24e71() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu63da5e332241428cacde9e5ebb09294e1() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd5u504','none','',500,'none','',500);
function waitu0d33db81425946b99f100ccae3986a311() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitue3af3fc9ded1455cb95601cb2ad7c55f1() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu7bc9e445656243d79b0311592f2215331() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu51cf844f619f48409321b35102cf95751() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitu2b9fcec4ec43425da9cff7b00c2977dd1() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waitu2b9fcec4ec43425da9cff7b00c2977dd1, 100);
}
setTimeout(waitu51cf844f619f48409321b35102cf95751, 100);
}
setTimeout(waitu7bc9e445656243d79b0311592f2215331, 100);
}
setTimeout(waitue3af3fc9ded1455cb95601cb2ad7c55f1, 100);
}
setTimeout(waitu0d33db81425946b99f100ccae3986a311, 100);
}
setTimeout(waitu63da5e332241428cacde9e5ebb09294e1, 100);
}
setTimeout(waitub7568fca87c8402a99450d80242e24e71, 100);
}
setTimeout(waitu522bf99fe7f1487b85867799c80701011, 100);
}
setTimeout(waitu674f4c2036514892a5d5631cb211f83c1, 100);
}
setTimeout(waitu3d06e0964c1a43fb90476ca3ba9b59301, 100);

}
});
document.getElementById('u328_img').tabIndex = 0;

u328.style.cursor = 'pointer';
$axure.eventManager.click('u328', function(e) {

if (true) {

	BringToFront("u303");
function waitu24582ae6e61b4727819b347022c8dfe71() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waituec2c6fe626b344c3b7e4805066a107111() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu2192c9b28d314c0eaf5bdf1a4e48206a1() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu10c68b7c398f4f6298f7221c6905e7c01() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu165f8fb7a4e14d52a511bcffff2c90cd1() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd3u322','none','',500,'none','',500);
function waitue4fe3a58ae6240159bec385d81baff651() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu17c5257a42094902bf98d8c4d22a596c1() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu090bdb88ca47405086631594861bcf5d1() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu14e17b9940574b4db0676ad24928ec801() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitu1deeffc5d6204f59bd44ff4684dd5be91() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waitu1deeffc5d6204f59bd44ff4684dd5be91, 100);
}
setTimeout(waitu14e17b9940574b4db0676ad24928ec801, 100);
}
setTimeout(waitu090bdb88ca47405086631594861bcf5d1, 100);
}
setTimeout(waitu17c5257a42094902bf98d8c4d22a596c1, 100);
}
setTimeout(waitue4fe3a58ae6240159bec385d81baff651, 100);
}
setTimeout(waitu165f8fb7a4e14d52a511bcffff2c90cd1, 100);
}
setTimeout(waitu10c68b7c398f4f6298f7221c6905e7c01, 100);
}
setTimeout(waitu2192c9b28d314c0eaf5bdf1a4e48206a1, 100);
}
setTimeout(waituec2c6fe626b344c3b7e4805066a107111, 100);
}
setTimeout(waitu24582ae6e61b4727819b347022c8dfe71, 100);

}
});
gv_vAlignTable['u182'] = 'center';u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u326'] = 'center';document.getElementById('u581_img').tabIndex = 0;

u581.style.cursor = 'pointer';
$axure.eventManager.click('u581', function(e) {

if (true) {

	BringToFront("u485");
function waitua83b2fbf2bf645d79fc88aec720a4f041() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd1u504','none','',500,'none','',500);
function waitu682564184c9e464790d27d9c2baf4f821() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd2u504','none','',500,'none','',500);
function waitu0d6397d4b11842bdbe8ecf0812c9bcad1() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waituc18decb019ee4019af7df213db81b6431() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu9bf5baac8cca497ba1328804f84e75b01() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd3u504','none','',500,'none','',500);
function waitu7b898af8a70947cda73e45c4245d30b71() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitue4071d9c82654d989fa8e2930163dd2b1() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu4b34bd22edec4323b5a87fa6e5176cc31() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitufd5de992b2394337b85c09570dc9eeac1() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waituc84887218a13432aba3e8bec9f6a1bfb1() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waituc84887218a13432aba3e8bec9f6a1bfb1, 100);
}
setTimeout(waitufd5de992b2394337b85c09570dc9eeac1, 100);
}
setTimeout(waitu4b34bd22edec4323b5a87fa6e5176cc31, 100);
}
setTimeout(waitue4071d9c82654d989fa8e2930163dd2b1, 100);
}
setTimeout(waitu7b898af8a70947cda73e45c4245d30b71, 100);
}
setTimeout(waitu9bf5baac8cca497ba1328804f84e75b01, 100);
}
setTimeout(waituc18decb019ee4019af7df213db81b6431, 100);
}
setTimeout(waitu0d6397d4b11842bdbe8ecf0812c9bcad1, 100);
}
setTimeout(waitu682564184c9e464790d27d9c2baf4f821, 100);
}
setTimeout(waitua83b2fbf2bf645d79fc88aec720a4f041, 100);

}
});
gv_vAlignTable['u513'] = 'center';document.getElementById('u354_img').tabIndex = 0;

u354.style.cursor = 'pointer';
$axure.eventManager.click('u354', function(e) {

if (true) {

	BringToFront("u303");
function waitu9e74b9b3370a4b68952979623df891601() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitu57223f7735ce4c5dacc9ee1c7f41c4dc1() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu18f6117f29f54249bb8432855c44bb501() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu058a42e4a7af49d8b0c16e59b00792ce1() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu08a0fca1088849e8a3a4a35bb088fae21() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd3u322','none','',500,'none','',500);
function waitubf3958be81894002b85f9cd41dfd31601() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitueeda13abb0704671aeb7396745225a4a1() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu0e9c75f998404aa3a64bea883af44be01() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu75fe7c1182c640e685e506fff473b6b51() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waituc29d30d508f848f6aa3a80983753e0131() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waituc29d30d508f848f6aa3a80983753e0131, 100);
}
setTimeout(waitu75fe7c1182c640e685e506fff473b6b51, 100);
}
setTimeout(waitu0e9c75f998404aa3a64bea883af44be01, 100);
}
setTimeout(waitueeda13abb0704671aeb7396745225a4a1, 100);
}
setTimeout(waitubf3958be81894002b85f9cd41dfd31601, 100);
}
setTimeout(waitu08a0fca1088849e8a3a4a35bb088fae21, 100);
}
setTimeout(waitu058a42e4a7af49d8b0c16e59b00792ce1, 100);
}
setTimeout(waitu18f6117f29f54249bb8432855c44bb501, 100);
}
setTimeout(waitu57223f7735ce4c5dacc9ee1c7f41c4dc1, 100);
}
setTimeout(waitu9e74b9b3370a4b68952979623df891601, 100);

}
});
document.getElementById('u261_img').tabIndex = 0;

u261.style.cursor = 'pointer';
$axure.eventManager.click('u261', function(e) {

if (true) {

	SetPanelState('u135', 'pd12u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u700'] = 'top';gv_vAlignTable['u506'] = 'center';gv_vAlignTable['u152'] = 'center';gv_vAlignTable['u541'] = 'center';document.getElementById('u347_img').tabIndex = 0;

u347.style.cursor = 'pointer';
$axure.eventManager.click('u347', function(e) {

if (true) {

	BringToFront("u303");
function waitu0f43c2028d0f430e8bb632eb8338094c1() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitu7b4eda0dac0044ccb8e9d247eb566f241() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu7f6a9c51740b46e88fda601c67a9cece1() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu294c203027c445a396244d81e147ba161() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu420f045424b54f12ac15b421cafd843e1() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd6u322','none','',500,'none','',500);
function waitu2807cb86418d4b08a21ee2bfdeab49da1() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waituc98f56ec7f1b425baeb31be972ef87241() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitue3060952855a43b5b9b3be65bdfe8d5b1() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu67714a70cfea406d98797df4231078811() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waituc77f8f214469414e80c9dfb88c8748c61() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waituc77f8f214469414e80c9dfb88c8748c61, 100);
}
setTimeout(waitu67714a70cfea406d98797df4231078811, 100);
}
setTimeout(waitue3060952855a43b5b9b3be65bdfe8d5b1, 100);
}
setTimeout(waituc98f56ec7f1b425baeb31be972ef87241, 100);
}
setTimeout(waitu2807cb86418d4b08a21ee2bfdeab49da1, 100);
}
setTimeout(waitu420f045424b54f12ac15b421cafd843e1, 100);
}
setTimeout(waitu294c203027c445a396244d81e147ba161, 100);
}
setTimeout(waitu7f6a9c51740b46e88fda601c67a9cece1, 100);
}
setTimeout(waitu7b4eda0dac0044ccb8e9d247eb566f241, 100);
}
setTimeout(waitu0f43c2028d0f430e8bb632eb8338094c1, 100);

}
});
gv_vAlignTable['u566'] = 'center';gv_vAlignTable['u129'] = 'center';gv_vAlignTable['u315'] = 'center';gv_vAlignTable['u534'] = 'center';gv_vAlignTable['u131'] = 'center';gv_vAlignTable['u350'] = 'center';document.getElementById('u79_img').tabIndex = 0;

u79.style.cursor = 'pointer';
$axure.eventManager.click('u79', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}
});
document.getElementById('u746_img').tabIndex = 0;

u746.style.cursor = 'pointer';
$axure.eventManager.click('u746', function(e) {

if (true) {

	SetPanelState('u135', 'pd16u135','none','',500,'none','',500);
function waituf38c2d3b2f1d411b8612848dc40b2e181() {

	SetPanelState('u135', 'pd17u135','none','',500,'none','',500);
function waitu89190b951a404dee9f4604d918b5f14c1() {

	SetPanelState('u135', 'pd18u135','none','',500,'none','',500);
function waitu02543d6a5deb418491599bfe6cd7ee2f1() {

	SetPanelState('u135', 'pd8u135','none','',500,'none','',500);
}
setTimeout(waitu02543d6a5deb418491599bfe6cd7ee2f1, 100);
}
setTimeout(waitu89190b951a404dee9f4604d918b5f14c1, 100);
}
setTimeout(waituf38c2d3b2f1d411b8612848dc40b2e181, 100);

}
});
gv_vAlignTable['u309'] = 'center';gv_vAlignTable['u528'] = 'center';u10.tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u10'] = 'top';document.getElementById('u714_img').tabIndex = 0;

u714.style.cursor = 'pointer';
$axure.eventManager.click('u714', function(e) {

if (true) {

	SetPanelState('u135', 'pd2u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u369'] = 'center';gv_vAlignTable['u530'] = 'center';gv_vAlignTable['u555'] = 'center';u118.tabIndex = 0;

u118.style.cursor = 'pointer';
$axure.eventManager.click('u118', function(e) {

if (true) {

	SetPanelVisibility('u93','hidden','none',500);

}
});

$axure.eventManager.mouseover('u118', function(e) {
if (!IsTrueMouseOver('u118',e)) return;
if (true) {

	SetPanelVisibility('u103','','none',500);

}
});

$axure.eventManager.mouseout('u118', function(e) {
if (!IsTrueMouseOut('u118',e)) return;
if (true) {

	SetPanelVisibility('u103','hidden','none',500);

}
});
gv_vAlignTable['u708'] = 'center';gv_vAlignTable['u371'] = 'center';gv_vAlignTable['u742'] = 'top';gv_vAlignTable['u178'] = 'center';gv_vAlignTable['u549'] = 'center';gv_vAlignTable['u768'] = 'center';document.getElementById('u251_img').tabIndex = 0;

u251.style.cursor = 'pointer';
$axure.eventManager.click('u251', function(e) {

if (true) {

	SetPanelState('u135', 'pd2u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u770'] = 'center';gv_vAlignTable['u210'] = 'center';document.getElementById('u52_img').tabIndex = 0;
HookHover('u52', false);

u52.style.cursor = 'pointer';
$axure.eventManager.click('u52', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
document.getElementById('u423_img').tabIndex = 0;

u423.style.cursor = 'pointer';
$axure.eventManager.click('u423', function(e) {

if (true) {

	SetPanelState('u135', 'pd8u135','none','',500,'none','',500);

}
});
u789.tabIndex = 0;

u789.style.cursor = 'pointer';
$axure.eventManager.click('u789', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u789'] = 'top';gv_vAlignTable['u697'] = 'center';gv_vAlignTable['u321'] = 'center';gv_vAlignTable['u294'] = 'top';gv_vAlignTable['u474'] = 'center';gv_vAlignTable['u774'] = 'center';gv_vAlignTable['u481'] = 'center';document.getElementById('u413_img').tabIndex = 0;

u413.style.cursor = 'pointer';
$axure.eventManager.click('u413', function(e) {

if (true) {

	SetPanelState('u135', 'pd1u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u693'] = 'center';document.getElementById('u600_img').tabIndex = 0;

u600.style.cursor = 'pointer';
$axure.eventManager.click('u600', function(e) {

if (true) {

	SetPanelState('u135', 'pd1u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u406'] = 'center';gv_vAlignTable['u625'] = 'center';gv_vAlignTable['u252'] = 'center';gv_vAlignTable['u222'] = 'center';gv_vAlignTable['u466'] = 'center';gv_vAlignTable['u434'] = 'center';gv_vAlignTable['u402'] = 'center';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u427'] = 'top';document.getElementById('u646_img').tabIndex = 0;

u646.style.cursor = 'pointer';
$axure.eventManager.click('u646', function(e) {

if (true) {

	SetPanelState('u135', 'pd4u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u428'] = 'top';gv_vAlignTable['u243'] = 'top';gv_vAlignTable['u614'] = 'center';gv_vAlignTable['u430'] = 'center';gv_vAlignTable['u674'] = 'center';gv_vAlignTable['u608'] = 'center';document.getElementById('u271_img').tabIndex = 0;

u271.style.cursor = 'pointer';
$axure.eventManager.click('u271', function(e) {

if (true) {

	SetPanelState('u135', 'pd1u135','none','',500,'none','',500);

}
});
document.getElementById('u642_img').tabIndex = 0;

u642.style.cursor = 'pointer';
$axure.eventManager.click('u642', function(e) {

if (true) {

	SetPanelState('u135', 'pd3u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u449'] = 'top';gv_vAlignTable['u668'] = 'center';document.getElementById('u527_img').tabIndex = 0;

u527.style.cursor = 'pointer';
$axure.eventManager.click('u527', function(e) {

if (true) {

	BringToFront("u485");
function waituecb49a52820c45bc99fa324c29a5ea241() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitub8bce14ee29249c0a33f9b4f2d956c891() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu4b00eda0ba4340ff8405f618f5f55a3e1() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu63b601db53a74f8ba3332a13a30745051() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu086493974c054153bf9812f69d0a3eb01() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd5u504','none','',500,'none','',500);
function waitu13c87d6708914259bba5bb72102e1ed81() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu501bb1b438124769a932e27acc1a94801() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitua9818b92c9224b34944c9c3c0e7a26591() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitue76166ea65184af8b085b954fa48a0761() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitub8f39fc0dd01414bba88c0925333a7b81() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waitub8f39fc0dd01414bba88c0925333a7b81, 100);
}
setTimeout(waitue76166ea65184af8b085b954fa48a0761, 100);
}
setTimeout(waitua9818b92c9224b34944c9c3c0e7a26591, 100);
}
setTimeout(waitu501bb1b438124769a932e27acc1a94801, 100);
}
setTimeout(waitu13c87d6708914259bba5bb72102e1ed81, 100);
}
setTimeout(waitu086493974c054153bf9812f69d0a3eb01, 100);
}
setTimeout(waitu63b601db53a74f8ba3332a13a30745051, 100);
}
setTimeout(waitu4b00eda0ba4340ff8405f618f5f55a3e1, 100);
}
setTimeout(waitub8bce14ee29249c0a33f9b4f2d956c891, 100);
}
setTimeout(waituecb49a52820c45bc99fa324c29a5ea241, 100);

}
});
gv_vAlignTable['u262'] = 'center';gv_vAlignTable['u562'] = 'center';gv_vAlignTable['u47'] = 'center';document.getElementById('u42_img').tabIndex = 0;
HookHover('u42', false);

u42.style.cursor = 'pointer';
$axure.eventManager.click('u42', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u477'] = 'center';gv_vAlignTable['u165'] = 'center';gv_vAlignTable['u226'] = 'top';gv_vAlignTable['u385'] = 'top';gv_vAlignTable['u462'] = 'center';gv_vAlignTable['u95'] = 'center';gv_vAlignTable['u167'] = 'center';gv_vAlignTable['u194'] = 'center';gv_vAlignTable['u784'] = 'top';u126.tabIndex = 0;

u126.style.cursor = 'pointer';
$axure.eventManager.click('u126', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');
function waitud60c4460105243299b524b0b32b428cf1() {

	SetPanelState('u125', 'pd1u125','none','',500,'none','',500);
function waitub3ccdb0e2b0e45289ccb18b7f7d0de481() {
function waitu7d17a4dc47ea4dd0b7636d8a947ae1e31() {
}
setTimeout(waitu7d17a4dc47ea4dd0b7636d8a947ae1e31, 200);
}
setTimeout(waitub3ccdb0e2b0e45289ccb18b7f7d0de481, 200);
}
setTimeout(waitud60c4460105243299b524b0b32b428cf1, 300);

}
});
gv_vAlignTable['u126'] = 'top';gv_vAlignTable['u150'] = 'center';gv_vAlignTable['u313'] = 'center';gv_vAlignTable['u593'] = 'top';document.getElementById('u525_img').tabIndex = 0;

u525.style.cursor = 'pointer';
$axure.eventManager.click('u525', function(e) {

if (true) {

	BringToFront("u485");
function waitu2423c184074a4a29ad1c01a37de7457e1() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waituc9e5d1dc7a4a4503900e6cf6cdb8cd4b1() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu33cb9bdb7a08417baf86ed2062b36cd41() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu711cd83e4f78499c88da56125662700b1() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitub18126f116354aeba4c16e6d09a26dcc1() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd4u504','none','',500,'none','',500);
function waitu0c25507abb454059aa2ae4ca4fd8f9a61() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu3505cf6c68b3424bb8f4f91e46c07f911() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitue25ac60ef5fd435ebe56318e2539bf791() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu29a3b70f66cc40a79231f9dd38fca9cc1() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitu34a71421ad0c4d13a3e05107854ccc311() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waitu34a71421ad0c4d13a3e05107854ccc311, 100);
}
setTimeout(waitu29a3b70f66cc40a79231f9dd38fca9cc1, 100);
}
setTimeout(waitue25ac60ef5fd435ebe56318e2539bf791, 100);
}
setTimeout(waitu3505cf6c68b3424bb8f4f91e46c07f911, 100);
}
setTimeout(waitu0c25507abb454059aa2ae4ca4fd8f9a61, 100);
}
setTimeout(waitub18126f116354aeba4c16e6d09a26dcc1, 100);
}
setTimeout(waitu711cd83e4f78499c88da56125662700b1, 100);
}
setTimeout(waitu33cb9bdb7a08417baf86ed2062b36cd41, 100);
}
setTimeout(waituc9e5d1dc7a4a4503900e6cf6cdb8cd4b1, 100);
}
setTimeout(waitu2423c184074a4a29ad1c01a37de7457e1, 100);

}
});
gv_vAlignTable['u780'] = 'center';u122.tabIndex = 0;

u122.style.cursor = 'pointer';
$axure.eventManager.click('u122', function(e) {

if (true) {

	SetPanelVisibility('u93','hidden','none',500);

}
});

$axure.eventManager.mouseover('u122', function(e) {
if (!IsTrueMouseOver('u122',e)) return;
if (true) {

	SetPanelVisibility('u112','','none',500);

}
});

$axure.eventManager.mouseout('u122', function(e) {
if (!IsTrueMouseOut('u122',e)) return;
if (true) {

	SetPanelVisibility('u112','hidden','none',500);

}
});
document.getElementById('u341_img').tabIndex = 0;

u341.style.cursor = 'pointer';
$axure.eventManager.click('u341', function(e) {

if (true) {

	BringToFront("u303");
function waituee462a1706b74406b61628299b4ff64f1() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitue1a87cc908ae4f44b02ea9ef5ea9ccb11() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu93b39e0f326f423484e7c9857affbf341() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu137a63a12a084ac2898dfa5c0f63eb2b1() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu0d592347048c44b98fd68f6333cbbf8b1() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd3u322','none','',500,'none','',500);
function waitu2c1a35d39b19475190972451693723ef1() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitucc88ea1c4cea417cb314a65c49036fde1() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu0acd190d29514b0ba90bd9922459c26b1() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu73c5c8539e1b47ae84a8055cf327d4471() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitu7280bf860be84b7c93dd73111a6987751() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waitu7280bf860be84b7c93dd73111a6987751, 100);
}
setTimeout(waitu73c5c8539e1b47ae84a8055cf327d4471, 100);
}
setTimeout(waitu0acd190d29514b0ba90bd9922459c26b1, 100);
}
setTimeout(waitucc88ea1c4cea417cb314a65c49036fde1, 100);
}
setTimeout(waitu2c1a35d39b19475190972451693723ef1, 100);
}
setTimeout(waitu0d592347048c44b98fd68f6333cbbf8b1, 100);
}
setTimeout(waitu137a63a12a084ac2898dfa5c0f63eb2b1, 100);
}
setTimeout(waitu93b39e0f326f423484e7c9857affbf341, 100);
}
setTimeout(waitue1a87cc908ae4f44b02ea9ef5ea9ccb11, 100);
}
setTimeout(waituee462a1706b74406b61628299b4ff64f1, 100);

}
});
document.getElementById('u712_img').tabIndex = 0;

u712.style.cursor = 'pointer';
$axure.eventManager.click('u712', function(e) {

if (true) {

	SetPanelState('u135', 'pd1u135','none','',500,'none','',500);

}
});
document.getElementById('u366_img').tabIndex = 0;

u366.style.cursor = 'pointer';
$axure.eventManager.click('u366', function(e) {

if (true) {

	BringToFront("u303");
function waitu0c4cb32a75e64b12b020e8a84ae628d21() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waituf4c90e5df6444d138374efaad8620bab1() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitufa95f0687eeb43508bd1311ba8eb47aa1() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu075489eb4ffe445d9961c49c534211fc1() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu27e82be218b247028f0793012f115a201() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd4u322','none','',500,'none','',500);
function waitu58c023714e51491c987681ad3b33fc3a1() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitud27f6c8ed2ed49d8a6a7b568e5d4bde21() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu08d460c0bb354d31992967da7d307f5d1() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitue2430c53fbcb4cef885f75f95a4c50651() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitu37bdf31882d6434a90edab2b96e377d61() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waitu37bdf31882d6434a90edab2b96e377d61, 100);
}
setTimeout(waitue2430c53fbcb4cef885f75f95a4c50651, 100);
}
setTimeout(waitu08d460c0bb354d31992967da7d307f5d1, 100);
}
setTimeout(waitud27f6c8ed2ed49d8a6a7b568e5d4bde21, 100);
}
setTimeout(waitu58c023714e51491c987681ad3b33fc3a1, 100);
}
setTimeout(waitu27e82be218b247028f0793012f115a201, 100);
}
setTimeout(waitu075489eb4ffe445d9961c49c534211fc1, 100);
}
setTimeout(waitufa95f0687eeb43508bd1311ba8eb47aa1, 100);
}
setTimeout(waituf4c90e5df6444d138374efaad8620bab1, 100);
}
setTimeout(waitu0c4cb32a75e64b12b020e8a84ae628d21, 100);

}
});
gv_vAlignTable['u115'] = 'top';document.getElementById('u334_img').tabIndex = 0;

u334.style.cursor = 'pointer';
$axure.eventManager.click('u334', function(e) {

if (true) {

	BringToFront("u303");
function waitu590273513ed9436aa4fdec8dba3d76941() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitudbd29e73b44648a3b2a3ad27b5f512111() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitub655a9c0fae24a36a58da1dff03fd9ae1() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu135a921764544137a13f1584c5529c6d1() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitud622d01caca8443daf7aa3ab5b535f181() {

	SetPanelState('u303', 'pd5u303','none','',500,'none','',500);

	SetPanelState('u322', 'pd6u322','none','',500,'none','',500);
function waitu733ae1ec84c84d7d8bc1b2dd74950e741() {

	SetPanelState('u303', 'pd4u303','none','',500,'none','',500);
function waitu0dccd57622e24ff9aee55410f72ad1781() {

	SetPanelState('u303', 'pd3u303','none','',500,'none','',500);
function waitu2b3a04ef766043a99a04716420f77e5f1() {

	SetPanelState('u303', 'pd2u303','none','',500,'none','',500);
function waitu04aab818ad844ecca2f7c85401f0b5c01() {

	SetPanelState('u303', 'pd1u303','none','',500,'none','',500);
function waitu0575030b0589481e95b8780df1f05d8a1() {

	SetPanelState('u303', 'pd0u303','none','',500,'none','',500);

	SetPanelVisibility('u303','hidden','none',500);
}
setTimeout(waitu0575030b0589481e95b8780df1f05d8a1, 100);
}
setTimeout(waitu04aab818ad844ecca2f7c85401f0b5c01, 100);
}
setTimeout(waitu2b3a04ef766043a99a04716420f77e5f1, 100);
}
setTimeout(waitu0dccd57622e24ff9aee55410f72ad1781, 100);
}
setTimeout(waitu733ae1ec84c84d7d8bc1b2dd74950e741, 100);
}
setTimeout(waitud622d01caca8443daf7aa3ab5b535f181, 100);
}
setTimeout(waitu135a921764544137a13f1584c5529c6d1, 100);
}
setTimeout(waitub655a9c0fae24a36a58da1dff03fd9ae1, 100);
}
setTimeout(waitudbd29e73b44648a3b2a3ad27b5f512111, 100);
}
setTimeout(waitu590273513ed9436aa4fdec8dba3d76941, 100);

}
});
gv_vAlignTable['u724'] = 'center';document.getElementById('u48_img').tabIndex = 0;
HookHover('u48', false);

u48.style.cursor = 'pointer';
$axure.eventManager.click('u48', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u302'] = 'top';gv_vAlignTable['u59'] = 'center';gv_vAlignTable['u740'] = 'center';document.getElementById('u546_img').tabIndex = 0;

u546.style.cursor = 'pointer';
$axure.eventManager.click('u546', function(e) {

if (true) {

	BringToFront("u485");
function waitu7f35a463ebc245f89cfad4256057966f1() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitu56de5f1f412a4e598e8edb6f5ba0166f1() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitub135599508ca497789d61c7c1c2fb9421() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu6be77a6a33e54fd9b441b89a517cb8c81() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu2c77a3082c7b42f6a28cfb384b93b9a81() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd3u504','none','',500,'none','',500);
function waitu40c553b5a6be4b9197e112ef0dbac7821() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitu3742d4e9ca37400081fe57a1c46850531() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu80f0afce20ad435ca758a1a25dbbfd641() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitu5869824e4c7247048cc4bad7ff8ae21e1() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitu88fa7ca3cad043249beb119a600beaa01() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waitu88fa7ca3cad043249beb119a600beaa01, 100);
}
setTimeout(waitu5869824e4c7247048cc4bad7ff8ae21e1, 100);
}
setTimeout(waitu80f0afce20ad435ca758a1a25dbbfd641, 100);
}
setTimeout(waitu3742d4e9ca37400081fe57a1c46850531, 100);
}
setTimeout(waitu40c553b5a6be4b9197e112ef0dbac7821, 100);
}
setTimeout(waitu2c77a3082c7b42f6a28cfb384b93b9a81, 100);
}
setTimeout(waitu6be77a6a33e54fd9b441b89a517cb8c81, 100);
}
setTimeout(waitub135599508ca497789d61c7c1c2fb9421, 100);
}
setTimeout(waitu56de5f1f412a4e598e8edb6f5ba0166f1, 100);
}
setTimeout(waitu7f35a463ebc245f89cfad4256057966f1, 100);

}
});
gv_vAlignTable['u765'] = 'top';u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u13'] = 'top';document.getElementById('u91_img').tabIndex = 0;

u91.style.cursor = 'pointer';
$axure.eventManager.click('u91', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u123'));

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Search_results.html');

}
});
gv_vAlignTable['u143'] = 'center';document.getElementById('u733_img').tabIndex = 0;

u733.style.cursor = 'pointer';
$axure.eventManager.click('u733', function(e) {

if (true) {

	SetPanelState('u135', 'pd3u135','none','',500,'none','',500);

}
});
gv_vAlignTable['u169'] = 'center';gv_vAlignTable['u701'] = 'top';gv_vAlignTable['u355'] = 'center';gv_vAlignTable['u508'] = 'center';gv_vAlignTable['u171'] = 'center';document.getElementById('u542_img').tabIndex = 0;

u542.style.cursor = 'pointer';
$axure.eventManager.click('u542', function(e) {

if (true) {

	BringToFront("u485");
function waitu9077dcee75224f019b321212220ba4691() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waitub0e648ab99b14e1d9ffa16b2909b94711() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waituf6f1017c97a043758dbb318c5d91b6031() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitu4503a8d5685240c5b0b1ac1bdd3346ad1() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitubf83cff978334417895110e0f98f9e431() {

	SetPanelState('u485', 'pd5u485','none','',500,'none','',500);

	SetPanelState('u504', 'pd6u504','none','',500,'none','',500);
function waitu94d10b6941ba428dbaa8112903d79a361() {

	SetPanelState('u485', 'pd4u485','none','',500,'none','',500);
function waitueb37b10980f04c9e8f90ead0317fa3191() {

	SetPanelState('u485', 'pd3u485','none','',500,'none','',500);
function waitub621daf5d2274728a48af221570bb3641() {

	SetPanelState('u485', 'pd2u485','none','',500,'none','',500);
function waitufd99bab5c44e4b1c8fe4a43824a25b741() {

	SetPanelState('u485', 'pd1u485','none','',500,'none','',500);
function waituecc382b3f3294e95b71a2241d8eca2c51() {

	SetPanelState('u485', 'pd0u485','none','',500,'none','',500);

	SetPanelVisibility('u485','hidden','none',500);
}
setTimeout(waituecc382b3f3294e95b71a2241d8eca2c51, 100);
}
setTimeout(waitufd99bab5c44e4b1c8fe4a43824a25b741, 100);
}
setTimeout(waitub621daf5d2274728a48af221570bb3641, 100);
}
setTimeout(waitueb37b10980f04c9e8f90ead0317fa3191, 100);
}
setTimeout(waitu94d10b6941ba428dbaa8112903d79a361, 100);
}
setTimeout(waitubf83cff978334417895110e0f98f9e431, 100);
}
setTimeout(waitu4503a8d5685240c5b0b1ac1bdd3346ad1, 100);
}
setTimeout(waituf6f1017c97a043758dbb318c5d91b6031, 100);
}
setTimeout(waitub0e648ab99b14e1d9ffa16b2909b94711, 100);
}
setTimeout(waitu9077dcee75224f019b321212220ba4691, 100);

}
});
gv_vAlignTable['u761'] = 'top';u14.tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u73'] = 'center';gv_vAlignTable['u629'] = 'top';document.getElementById('u748_img').tabIndex = 0;

u748.style.cursor = 'pointer';
$axure.eventManager.click('u748', function(e) {

if (true) {

	SetPanelState('u135', 'pd16u135','none','',500,'none','',500);
function waitu152059f294e34e02bcbd9b095e67cd6a1() {

	SetPanelState('u135', 'pd17u135','none','',500,'none','',500);
function waitu5c2678e6f2fb47d08c4ea8ffafff16f41() {

	SetPanelState('u135', 'pd18u135','none','',500,'none','',500);
function waitu29f9b4deba2f4713a5963ca4edcac06f1() {

	SetPanelState('u135', 'pd9u135','none','',500,'none','',500);
}
setTimeout(waitu29f9b4deba2f4713a5963ca4edcac06f1, 100);
}
setTimeout(waitu5c2678e6f2fb47d08c4ea8ffafff16f41, 100);
}
setTimeout(waitu152059f294e34e02bcbd9b095e67cd6a1, 100);

}
});
u9.tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
gv_vAlignTable['u9'] = 'top';