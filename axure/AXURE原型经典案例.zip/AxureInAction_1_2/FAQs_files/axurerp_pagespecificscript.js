﻿for(var i = 0; i < 174; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

SetWidgetSelected('u5');
}

if ((GetGlobalVariableValue('ShoppingBasket')) == ('Empty')) {

	SetPanelState('u45', 'pd0u45','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('1'))) {

SetWidgetRichText('u47', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (1 item)</span></p>');

	SetPanelState('u45', 'pd1u45','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('2'))) {

SetWidgetRichText('u47', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (2 items)</span></p>');

	SetPanelState('u45', 'pd1u45','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('3'))) {

SetWidgetRichText('u47', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (3 items)</span></p>');

	SetPanelState('u45', 'pd1u45','none','',500,'none','',500);

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) {

}

});

function rdo0LoadHome(e) {

}
u122.tabIndex = 0;

u122.style.cursor = 'pointer';
$axure.eventManager.click('u122', function(e) {

if (true) {

	ScrollToWidget('u132', false,true,'none',500);

}
});
gv_vAlignTable['u122'] = 'top';document.getElementById('u21_img').tabIndex = 0;
HookHover('u21', false);

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u32'] = 'center';u156.tabIndex = 0;

u156.style.cursor = 'pointer';
$axure.eventManager.click('u156', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u156'] = 'top';gv_vAlignTable['u130'] = 'center';document.getElementById('u7_img').tabIndex = 0;
HookHover('u7', false);

u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u2'] = 'center';gv_vAlignTable['u4'] = 'center';u153.tabIndex = 0;

u153.style.cursor = 'pointer';
$axure.eventManager.click('u153', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u153'] = 'top';u140.tabIndex = 0;

u140.style.cursor = 'pointer';
$axure.eventManager.click('u140', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u140'] = 'top';document.getElementById('u17_img').tabIndex = 0;
HookHover('u17', false);

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
u135.tabIndex = 0;

u135.style.cursor = 'pointer';
$axure.eventManager.click('u135', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u135'] = 'top';u151.tabIndex = 0;

u151.style.cursor = 'pointer';
$axure.eventManager.click('u151', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u151'] = 'top';document.getElementById('u42_img').tabIndex = 0;

u42.style.cursor = 'pointer';
$axure.eventManager.click('u42', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u55'] = 'center';gv_vAlignTable['u14'] = 'center';document.getElementById('u48_img').tabIndex = 0;

u48.style.cursor = 'pointer';
$axure.eventManager.click('u48', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}

if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('OnLoadVariable')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
u105.tabIndex = 0;

u105.style.cursor = 'pointer';
$axure.eventManager.click('u105', function(e) {

if (true) {

	ScrollToWidget('u113', false,true,'none',500);

}
});
gv_vAlignTable['u105'] = 'top';document.getElementById('u27_img').tabIndex = 0;
HookHover('u27', false);

u27.style.cursor = 'pointer';
$axure.eventManager.click('u27', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u138'] = 'center';gv_vAlignTable['u20'] = 'center';u67.tabIndex = 0;

u67.style.cursor = 'pointer';
$axure.eventManager.click('u67', function(e) {

if (true) {

	SetPanelVisibility('u60','hidden','none',500);

}
});

$axure.eventManager.mouseover('u67', function(e) {
if (!IsTrueMouseOver('u67',e)) return;
if (true) {

	SetPanelVisibility('u63','','none',500);

}
});

$axure.eventManager.mouseout('u67', function(e) {
if (!IsTrueMouseOut('u67',e)) return;
if (true) {

	SetPanelVisibility('u63','hidden','none',500);

}
});
gv_vAlignTable['u65'] = 'center';u152.tabIndex = 0;

u152.style.cursor = 'pointer';
$axure.eventManager.click('u152', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u152'] = 'top';gv_vAlignTable['u110'] = 'top';gv_vAlignTable['u6'] = 'center';gv_vAlignTable['u108'] = 'top';document.getElementById('u37_img').tabIndex = 0;
HookHover('u37', false);

u37.style.cursor = 'pointer';
$axure.eventManager.click('u37', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u62'] = 'center';u141.tabIndex = 0;

u141.style.cursor = 'pointer';
$axure.eventManager.click('u141', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u141'] = 'top';document.getElementById('u11_img').tabIndex = 0;
HookHover('u11', false);

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u75'] = 'center';u133.tabIndex = 0;

u133.style.cursor = 'pointer';
$axure.eventManager.click('u133', function(e) {

if (true) {

	ScrollToWidget('u103', false,true,'none',500);

}
});
gv_vAlignTable['u133'] = 'top';gv_vAlignTable['u34'] = 'center';u89.tabIndex = 0;

u89.style.cursor = 'pointer';
$axure.eventManager.click('u89', function(e) {

if (true) {

	SetPanelVisibility('u60','hidden','none',500);

}
});

$axure.eventManager.mouseover('u89', function(e) {
if (!IsTrueMouseOver('u89',e)) return;
if (true) {

	SetPanelVisibility('u79','','none',500);

}
});

$axure.eventManager.mouseout('u89', function(e) {
if (!IsTrueMouseOut('u89',e)) return;
if (true) {

	SetPanelVisibility('u79','hidden','none',500);

}
});
gv_vAlignTable['u47'] = 'center';gv_vAlignTable['u72'] = 'center';u99.tabIndex = 0;

u99.style.cursor = 'pointer';
$axure.eventManager.click('u99', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u66'] = 'top';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u57'] = 'top';gv_vAlignTable['u16'] = 'center';gv_vAlignTable['u172'] = 'center';u149.tabIndex = 0;

u149.style.cursor = 'pointer';
$axure.eventManager.click('u149', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u149'] = 'top';u118.tabIndex = 0;

u118.style.cursor = 'pointer';
$axure.eventManager.click('u118', function(e) {

if (true) {

	ScrollToWidget('u103', false,true,'none',500);

}
});
gv_vAlignTable['u118'] = 'top';u88.tabIndex = 0;

u88.style.cursor = 'pointer';
$axure.eventManager.click('u88', function(e) {

if (true) {

	SetPanelVisibility('u60','hidden','none',500);

}
});

$axure.eventManager.mouseover('u88', function(e) {
if (!IsTrueMouseOver('u88',e)) return;
if (true) {

	SetPanelVisibility('u76','','none',500);

}
});

$axure.eventManager.mouseout('u88', function(e) {
if (!IsTrueMouseOut('u88',e)) return;
if (true) {

	SetPanelVisibility('u76','hidden','none',500);

}
});
gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u26'] = 'center';u119.tabIndex = 0;

u119.style.cursor = 'pointer';
$axure.eventManager.click('u119', function(e) {

if (true) {

	ScrollToWidget('u103', false,true,'none',500);

}
});
gv_vAlignTable['u119'] = 'top';u85.tabIndex = 0;

u85.style.cursor = 'pointer';
$axure.eventManager.click('u85', function(e) {

if (true) {

	SetPanelVisibility('u60','hidden','none',500);

}
});

$axure.eventManager.mouseover('u85', function(e) {
if (!IsTrueMouseOver('u85',e)) return;
if (true) {

	SetPanelVisibility('u70','','none',500);

}
});

$axure.eventManager.mouseout('u85', function(e) {
if (!IsTrueMouseOut('u85',e)) return;
if (true) {

	SetPanelVisibility('u70','hidden','none',500);

}
});
gv_vAlignTable['u51'] = 'center';gv_vAlignTable['u10'] = 'center';u100.tabIndex = 0;

u100.style.cursor = 'pointer';
$axure.eventManager.click('u100', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('My_details.html');

}
else
if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('LoginStatus')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u100'] = 'top';u144.tabIndex = 0;

u144.style.cursor = 'pointer';
$axure.eventManager.click('u144', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u144'] = 'top';gv_vAlignTable['u166'] = 'center';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u30'] = 'center';document.getElementById('u95_img').tabIndex = 0;

u95.style.cursor = 'pointer';
$axure.eventManager.click('u95', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
u116.tabIndex = 0;

u116.style.cursor = 'pointer';
$axure.eventManager.click('u116', function(e) {

if (true) {

	ScrollToWidget('u103', false,true,'none',500);

}
});
gv_vAlignTable['u116'] = 'top';gv_vAlignTable['u158'] = 'top';document.getElementById('u33_img').tabIndex = 0;
HookHover('u33', false);

u33.style.cursor = 'pointer';
$axure.eventManager.click('u33', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u160'] = 'top';u157.tabIndex = 0;

u157.style.cursor = 'pointer';
$axure.eventManager.click('u157', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u157'] = 'top';document.getElementById('u46_img').tabIndex = 0;

u46.style.cursor = 'pointer';
$axure.eventManager.click('u46', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}
});
gv_vAlignTable['u126'] = 'center';document.getElementById('u5_img').tabIndex = 0;
HookHover('u5', false);

u5.style.cursor = 'pointer';
$axure.eventManager.click('u5', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u98'] = 'center';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u169'] = 'center';gv_vAlignTable['u56'] = 'top';u150.tabIndex = 0;

u150.style.cursor = 'pointer';
$axure.eventManager.click('u150', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u150'] = 'top';u142.tabIndex = 0;

u142.style.cursor = 'pointer';
$axure.eventManager.click('u142', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u142'] = 'top';u106.tabIndex = 0;

u106.style.cursor = 'pointer';
$axure.eventManager.click('u106', function(e) {

if (true) {

	ScrollToWidget('u114', false,true,'none',500);

}
});
gv_vAlignTable['u106'] = 'top';u154.tabIndex = 0;

u154.style.cursor = 'pointer';
$axure.eventManager.click('u154', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u154'] = 'top';gv_vAlignTable['u40'] = 'center';u139.tabIndex = 0;

u139.style.cursor = 'pointer';
$axure.eventManager.click('u139', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u139'] = 'top';u87.tabIndex = 0;

u87.style.cursor = 'pointer';
$axure.eventManager.click('u87', function(e) {

if (true) {

	SetPanelVisibility('u60','hidden','none',500);

}
});

$axure.eventManager.mouseover('u87', function(e) {
if (!IsTrueMouseOver('u87',e)) return;
if (true) {

	SetPanelVisibility('u73','','none',500);

}
});

$axure.eventManager.mouseout('u87', function(e) {
if (!IsTrueMouseOut('u87',e)) return;
if (true) {

	SetPanelVisibility('u73','hidden','none',500);

}
});
gv_vAlignTable['u53'] = 'center';u104.tabIndex = 0;

u104.style.cursor = 'pointer';
$axure.eventManager.click('u104', function(e) {

if (true) {

	ScrollToWidget('u112', false,true,'none',500);

}
});
gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u121'] = 'center';document.getElementById('u19_img').tabIndex = 0;
HookHover('u19', false);

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
u155.tabIndex = 0;

u155.style.cursor = 'pointer';
$axure.eventManager.click('u155', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u155'] = 'top';gv_vAlignTable['u109'] = 'top';gv_vAlignTable['u84'] = 'top';HookHover('u97', false);
u134.tabIndex = 0;

u134.style.cursor = 'pointer';
$axure.eventManager.click('u134', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u134'] = 'top';gv_vAlignTable['u81'] = 'center';gv_vAlignTable['u128'] = 'center';u94.tabIndex = 0;

u94.style.cursor = 'pointer';
$axure.eventManager.click('u94', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');

SetGlobalVariableValue('BookPageViewed', '');

SetGlobalVariableValue('CitySelected', '');

SetGlobalVariableValue('LoginStatus', '');

SetGlobalVariableValue('ReviewVar', '');

SetGlobalVariableValue('EmployeesName', '');

	SetPanelState('u92', 'pd1u92','none','',500,'none','',500);
function waituf022ddcb6b474903a282219d39d908ef1() {

	SetPanelState('u92', 'pd0u92','none','',500,'none','',500);
}
setTimeout(waituf022ddcb6b474903a282219d39d908ef1, 4000);

}
});
gv_vAlignTable['u94'] = 'top';gv_vAlignTable['u102'] = 'top';document.getElementById('u9_img').tabIndex = 0;
HookHover('u9', false);

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u69'] = 'center';u147.tabIndex = 0;

u147.style.cursor = 'pointer';
$axure.eventManager.click('u147', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u147'] = 'top';u163.tabIndex = 0;

u163.style.cursor = 'pointer';
$axure.eventManager.click('u163', function(e) {

if (true) {

	self.location.href='http://www.lucabenazzi.eu';

}
});
u91.tabIndex = 0;

u91.style.cursor = 'pointer';
$axure.eventManager.click('u91', function(e) {

if (true) {

	self.location.href='index.html';

}
});
gv_vAlignTable['u91'] = 'top';gv_vAlignTable['u131'] = 'top';gv_vAlignTable['u24'] = 'center';document.getElementById('u23_img').tabIndex = 0;
HookHover('u23', false);

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
u117.tabIndex = 0;

u117.style.cursor = 'pointer';
$axure.eventManager.click('u117', function(e) {

if (true) {

	ScrollToWidget('u103', false,true,'none',500);

}
});
gv_vAlignTable['u117'] = 'top';HookHover('u13', false);
document.getElementById('u29_img').tabIndex = 0;
HookHover('u29', false);

u29.style.cursor = 'pointer';
$axure.eventManager.click('u29', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u86'] = 'top';document.getElementById('u58_img').tabIndex = 0;

u58.style.cursor = 'pointer';
$axure.eventManager.click('u58', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u90'));

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Search_results.html');

}
});
gv_vAlignTable['u173'] = 'top';gv_vAlignTable['u111'] = 'top';u0.tabIndex = 0;

u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u0'] = 'top';document.getElementById('u31_img').tabIndex = 0;
HookHover('u31', false);

u31.style.cursor = 'pointer';
$axure.eventManager.click('u31', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u83'] = 'top';gv_vAlignTable['u8'] = 'center';document.getElementById('u3_img').tabIndex = 0;
HookHover('u3', false);

u3.style.cursor = 'pointer';
$axure.eventManager.click('u3', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u96'] = 'center';u146.tabIndex = 0;

u146.style.cursor = 'pointer';
$axure.eventManager.click('u146', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
gv_vAlignTable['u146'] = 'top';document.getElementById('u15_img').tabIndex = 0;
HookHover('u15', false);

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u124'] = 'center';u148.tabIndex = 0;

u148.style.cursor = 'pointer';
$axure.eventManager.click('u148', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u148'] = 'top';u93.tabIndex = 0;

u93.style.cursor = 'pointer';
$axure.eventManager.click('u93', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');
function waitud60c4460105243299b524b0b32b428cf1() {

	SetPanelState('u92', 'pd1u92','none','',500,'none','',500);
function waitub3ccdb0e2b0e45289ccb18b7f7d0de481() {
function waitu7d17a4dc47ea4dd0b7636d8a947ae1e31() {
}
setTimeout(waitu7d17a4dc47ea4dd0b7636d8a947ae1e31, 200);
}
setTimeout(waitub3ccdb0e2b0e45289ccb18b7f7d0de481, 200);
}
setTimeout(waitud60c4460105243299b524b0b32b428cf1, 300);

}
});
gv_vAlignTable['u93'] = 'top';u145.tabIndex = 0;

u145.style.cursor = 'pointer';
$axure.eventManager.click('u145', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u145'] = 'top';gv_vAlignTable['u12'] = 'center';document.getElementById('u165_img').tabIndex = 0;

u165.style.cursor = 'pointer';
$axure.eventManager.click('u165', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
document.getElementById('u25_img').tabIndex = 0;
HookHover('u25', false);

u25.style.cursor = 'pointer';
$axure.eventManager.click('u25', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
gv_vAlignTable['u59'] = 'center';
$axure.eventManager.keyup('u90', function(e) {

if ((GetWidgetText('u90')) == ('')) {

	SetPanelVisibility('u60','hidden','none',500);

}
else
if (true) {

	SetPanelState('u60', 'pd0u60','none','',500,'none','',500);

SetGlobalVariableValue('IncrementalSearchVar', GetWidgetText('u90'));

SetWidgetRichText('u82', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dada</span></p>');

SetWidgetRichText('u83', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dat</span></p>');

SetWidgetRichText('u84', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">gi</span></p>');

SetWidgetRichText('u86', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

SetWidgetRichText('u66', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

	SetPanelVisibility('u60','','none',500);

	BringToFront("u60");
function waitu796b5745765043a58e9fe38835b455f51() {

	SetPanelState('u60', 'pd1u60','none','',500,'none','',500);
}
setTimeout(waitu796b5745765043a58e9fe38835b455f51, 2000);

}
});

$axure.eventManager.blur('u90', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u90'));

}
});
gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u161'] = 'top';gv_vAlignTable['u22'] = 'center';u143.tabIndex = 0;

u143.style.cursor = 'pointer';
$axure.eventManager.click('u143', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u143'] = 'top';u107.tabIndex = 0;

u107.style.cursor = 'pointer';
$axure.eventManager.click('u107', function(e) {

if (true) {

	ScrollToWidget('u115', false,true,'none',500);

}
});
gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u162'] = 'top';document.getElementById('u35_img').tabIndex = 0;
HookHover('u35', false);

u35.style.cursor = 'pointer';
$axure.eventManager.click('u35', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u136'] = 'top';gv_vAlignTable['u28'] = 'center';