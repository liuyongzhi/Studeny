﻿for(var i = 0; i < 842; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

SetWidgetSelected('u43');
}

if ((GetGlobalVariableValue('ShoppingBasket')) == ('Empty')) {

	SetPanelState('u81', 'pd0u81','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('1'))) {

SetWidgetRichText('u83', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (1 item)</span></p>');

	SetPanelState('u81', 'pd1u81','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('2'))) {

SetWidgetRichText('u83', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (2 items)</span></p>');

	SetPanelState('u81', 'pd1u81','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('3'))) {

SetWidgetRichText('u83', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (3 items)</span></p>');

	SetPanelState('u81', 'pd1u81','none','',500,'none','',500);

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) {

}

});

function rdo1LoadHome(e) {

}
gv_vAlignTable['u285'] = 'top';gv_vAlignTable['u312'] = 'center';gv_vAlignTable['u712'] = 'top';gv_vAlignTable['u824'] = 'center';gv_vAlignTable['u691'] = 'center';gv_vAlignTable['u497'] = 'center';gv_vAlignTable['u817'] = 'top';gv_vAlignTable['u684'] = 'center';gv_vAlignTable['u688'] = 'top';gv_vAlignTable['u213'] = 'top';gv_vAlignTable['u493'] = 'center';gv_vAlignTable['u400'] = 'center';gv_vAlignTable['u206'] = 'center';gv_vAlignTable['u680'] = 'center';gv_vAlignTable['u612'] = 'center';gv_vAlignTable['u234'] = 'center';gv_vAlignTable['u699'] = 'center';u202.tabIndex = 0;

u202.style.cursor = 'pointer';
$axure.eventManager.click('u202', function(e) {

if (true) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
HookHover('u49', false);
gv_vAlignTable['u640'] = 'center';gv_vAlignTable['u446'] = 'top';gv_vAlignTable['u665'] = 'center';gv_vAlignTable['u228'] = 'top';gv_vAlignTable['u633'] = 'top';gv_vAlignTable['u87'] = 'center';gv_vAlignTable['u601'] = 'top';gv_vAlignTable['u255'] = 'center';gv_vAlignTable['u474'] = 'top';gv_vAlignTable['u661'] = 'top';gv_vAlignTable['u249'] = 'center';gv_vAlignTable['u396'] = 'center';gv_vAlignTable['u627'] = 'center';document.getElementById('u63_img').tabIndex = 0;
HookHover('u63', false);

u63.style.cursor = 'pointer';
$axure.eventManager.click('u63', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u361'] = 'top';gv_vAlignTable['u648'] = 'top';gv_vAlignTable['u275'] = 'top';u22.tabIndex = 0;

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u298'] = 'top';gv_vAlignTable['u265'] = 'center';gv_vAlignTable['u185'] = 'top';u838.tabIndex = 0;

u838.style.cursor = 'pointer';
$axure.eventManager.click('u838', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u838'] = 'top';gv_vAlignTable['u98'] = 'center';u584.tabIndex = 0;

u584.style.cursor = 'pointer';
$axure.eventManager.click('u584', function(e) {

if (true) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
gv_vAlignTable['u584'] = 'top';gv_vAlignTable['u176'] = 'center';gv_vAlignTable['u181'] = 'center';gv_vAlignTable['u796'] = 'center';gv_vAlignTable['u300'] = 'top';gv_vAlignTable['u325'] = 'top';gv_vAlignTable['u552'] = 'center';gv_vAlignTable['u580'] = 'center';gv_vAlignTable['u512'] = 'center';gv_vAlignTable['u537'] = 'center';gv_vAlignTable['u792'] = 'top';gv_vAlignTable['u134'] = 'center';gv_vAlignTable['u505'] = 'top';gv_vAlignTable['u89'] = 'center';gv_vAlignTable['u599'] = 'center';gv_vAlignTable['u102'] = 'top';document.getElementById('u39_img').tabIndex = 0;
HookHover('u39', false);

u39.style.cursor = 'pointer';
$axure.eventManager.click('u39', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
u127.tabIndex = 0;

u127.style.cursor = 'pointer';
$axure.eventManager.click('u127', function(e) {

if (true) {

	self.location.href='index.html';

}
});
gv_vAlignTable['u127'] = 'top';gv_vAlignTable['u346'] = 'top';gv_vAlignTable['u565'] = 'center';gv_vAlignTable['u162'] = 'top';gv_vAlignTable['u533'] = 'top';gv_vAlignTable['u752'] = 'center';gv_vAlignTable['u777'] = 'top';u130.tabIndex = 0;

u130.style.cursor = 'pointer';
$axure.eventManager.click('u130', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');

SetGlobalVariableValue('BookPageViewed', '');

SetGlobalVariableValue('CitySelected', '');

SetGlobalVariableValue('LoginStatus', '');

SetGlobalVariableValue('ReviewVar', '');

SetGlobalVariableValue('EmployeesName', '');

	SetPanelState('u128', 'pd1u128','none','',500,'none','',500);
function waituf022ddcb6b474903a282219d39d908ef1() {

	SetPanelState('u128', 'pd0u128','none','',500,'none','',500);
}
setTimeout(waituf022ddcb6b474903a282219d39d908ef1, 4000);

}
});
gv_vAlignTable['u130'] = 'top';gv_vAlignTable['u501'] = 'center';gv_vAlignTable['u374'] = 'top';gv_vAlignTable['u745'] = 'center';gv_vAlignTable['u717'] = 'center';gv_vAlignTable['u739'] = 'center';document.getElementById('u53_img').tabIndex = 0;
HookHover('u53', false);

u53.style.cursor = 'pointer';
$axure.eventManager.click('u53', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u375'] = 'top';u12.tabIndex = 0;

u12.style.cursor = 'pointer';
$axure.eventManager.click('u12', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u12'] = 'top';document.getElementById('u71_img').tabIndex = 0;
HookHover('u71', false);

u71.style.cursor = 'pointer';
$axure.eventManager.click('u71', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u543'] = 'center';gv_vAlignTable['u297'] = 'center';gv_vAlignTable['u811'] = 'center';u836.tabIndex = 0;

u836.style.cursor = 'pointer';
$axure.eventManager.click('u836', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u836'] = 'top';gv_vAlignTable['u484'] = 'center';gv_vAlignTable['u288'] = 'top';gv_vAlignTable['u804'] = 'top';u7.tabIndex = 0;

u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u7'] = 'top';gv_vAlignTable['u293'] = 'center';gv_vAlignTable['u200'] = 'top';gv_vAlignTable['u214'] = 'top';gv_vAlignTable['u225'] = 'center';gv_vAlignTable['u832'] = 'top';gv_vAlignTable['u480'] = 'center';gv_vAlignTable['u450'] = 'center';gv_vAlignTable['u437'] = 'center';gv_vAlignTable['u405'] = 'top';gv_vAlignTable['u499'] = 'center';gv_vAlignTable['u314'] = 'top';gv_vAlignTable['u246'] = 'top';gv_vAlignTable['u465'] = 'center';document.getElementById('u82_img').tabIndex = 0;

u82.style.cursor = 'pointer';
$axure.eventManager.click('u82', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}
});
gv_vAlignTable['u652'] = 'center';gv_vAlignTable['u306'] = 'center';gv_vAlignTable['u645'] = 'top';gv_vAlignTable['u208'] = 'center';gv_vAlignTable['u242'] = 'center';u461.tabIndex = 0;

u461.style.cursor = 'pointer';
$axure.eventManager.click('u461', function(e) {

if (true) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
u121.tabIndex = 0;

u121.style.cursor = 'pointer';
$axure.eventManager.click('u121', function(e) {

if (true) {

	SetPanelVisibility('u96','hidden','none',500);

}
});

$axure.eventManager.mouseover('u121', function(e) {
if (!IsTrueMouseOver('u121',e)) return;
if (true) {

	SetPanelVisibility('u106','','none',500);

}
});

$axure.eventManager.mouseout('u121', function(e) {
if (!IsTrueMouseOut('u121',e)) return;
if (true) {

	SetPanelVisibility('u106','hidden','none',500);

}
});
document.getElementById('u43_img').tabIndex = 0;
HookHover('u43', false);

u43.style.cursor = 'pointer';
$axure.eventManager.click('u43', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u773'] = 'center';gv_vAlignTable['u710'] = 'center';gv_vAlignTable['u819'] = 'top';document.getElementById('u61_img').tabIndex = 0;
HookHover('u61', false);

u61.style.cursor = 'pointer';
$axure.eventManager.click('u61', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
document.getElementById('u67_img').tabIndex = 0;
HookHover('u67', false);

u67.style.cursor = 'pointer';
$axure.eventManager.click('u67', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u391'] = 'top';u197.tabIndex = 0;

u197.style.cursor = 'pointer';
$axure.eventManager.click('u197', function(e) {

if (true) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
gv_vAlignTable['u197'] = 'top';gv_vAlignTable['u787'] = 'center';gv_vAlignTable['u365'] = 'center';gv_vAlignTable['u384'] = 'center';gv_vAlignTable['u790'] = 'top';u6.tabIndex = 0;

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u193'] = 'center';gv_vAlignTable['u783'] = 'center';u125.tabIndex = 0;

u125.style.cursor = 'pointer';
$axure.eventManager.click('u125', function(e) {

if (true) {

	SetPanelVisibility('u96','hidden','none',500);

}
});

$axure.eventManager.mouseover('u125', function(e) {
if (!IsTrueMouseOver('u125',e)) return;
if (true) {

	SetPanelVisibility('u115','','none',500);

}
});

$axure.eventManager.mouseout('u125', function(e) {
if (!IsTrueMouseOut('u125',e)) return;
if (true) {

	SetPanelVisibility('u115','hidden','none',500);

}
});
u5.tabIndex = 0;

u5.style.cursor = 'pointer';
$axure.eventManager.click('u5', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u5'] = 'top';gv_vAlignTable['u380'] = 'center';gv_vAlignTable['u550'] = 'center';gv_vAlignTable['u337'] = 'center';gv_vAlignTable['u524'] = 'center';u19.tabIndex = 0;

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u19'] = 'top';gv_vAlignTable['u146'] = 'top';gv_vAlignTable['u517'] = 'top';gv_vAlignTable['u114'] = 'center';u333.tabIndex = 0;

u333.style.cursor = 'pointer';
$axure.eventManager.click('u333', function(e) {

if (true) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
gv_vAlignTable['u301'] = 'top';gv_vAlignTable['u520'] = 'top';u174.tabIndex = 0;

u174.style.cursor = 'pointer';
$axure.eventManager.click('u174', function(e) {

if ((GetPanelState('u189')) != ('pd3u189')) {

	SetPanelState('u189', 'pd3u189','none','',500,'none','',500);

	SetPanelVisibility('u189','','none',500);

	MoveWidgetTo('u189', GetNum('457'), GetNum('288'),'none',500);

}
else
if ((GetPanelState('u189')) == ('pd3u189')) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
gv_vAlignTable['u174'] = 'top';gv_vAlignTable['u545'] = 'top';gv_vAlignTable['u764'] = 'top';gv_vAlignTable['u142'] = 'top';gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u732'] = 'top';u168.tabIndex = 0;

u168.style.cursor = 'pointer';
$axure.eventManager.click('u168', function(e) {

if ((GetPanelState('u189')) != ('pd0u189')) {

	SetPanelState('u189', 'pd0u189','none','',500,'none','',500);

	SetPanelVisibility('u189','','none',500);

	MoveWidgetTo('u189', GetNum('186'), GetNum('295'),'none',500);

}
else
if ((GetPanelState('u189')) == ('pd0u189')) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
gv_vAlignTable['u168'] = 'top';gv_vAlignTable['u539'] = 'center';gv_vAlignTable['u758'] = 'center';gv_vAlignTable['u573'] = 'top';gv_vAlignTable['u170'] = 'center';gv_vAlignTable['u760'] = 'center';u719.tabIndex = 0;

u719.style.cursor = 'pointer';
$axure.eventManager.click('u719', function(e) {

if (true) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
document.getElementById('u51_img').tabIndex = 0;
HookHover('u51', false);

u51.style.cursor = 'pointer';
$axure.eventManager.click('u51', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u373'] = 'center';gv_vAlignTable['u779'] = 'top';document.getElementById('u57_img').tabIndex = 0;
HookHover('u57', false);

u57.style.cursor = 'pointer';
$axure.eventManager.click('u57', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
u715.tabIndex = 0;

u715.style.cursor = 'pointer';
$axure.eventManager.click('u715', function(e) {

if (true) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
gv_vAlignTable['u715'] = 'top';gv_vAlignTable['u196'] = 'top';gv_vAlignTable['u687'] = 'top';gv_vAlignTable['u284'] = 'center';u263.tabIndex = 0;

u263.style.cursor = 'pointer';
$axure.eventManager.click('u263', function(e) {

if (true) {

	SetPanelState('u204', 'pd6u204','none','',500,'none','',500);
function waitu597a9b3822494c3bada0d191f5a53d801() {

	SetPanelState('u204', 'pd7u204','none','',500,'none','',500);
function waitu2ab28717f4fc4e3686ace76aeac9ab3b1() {

	SetPanelState('u204', 'pd8u204','none','',500,'none','',500);
function waitud3a4ee3c114c4547bd5785cc1335f9bc1() {

	SetPanelState('u204', 'pd0u204','none','',500,'none','',500);
}
setTimeout(waitud3a4ee3c114c4547bd5785cc1335f9bc1, 200);
}
setTimeout(waitu2ab28717f4fc4e3686ace76aeac9ab3b1, 200);
}
setTimeout(waitu597a9b3822494c3bada0d191f5a53d801, 2000);

}
});
gv_vAlignTable['u816'] = 'top';gv_vAlignTable['u280'] = 'center';gv_vAlignTable['u212'] = 'center';document.getElementById('u69_img').tabIndex = 0;
HookHover('u69', false);

u69.style.cursor = 'pointer';
$axure.eventManager.click('u69', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u424'] = 'center';gv_vAlignTable['u299'] = 'top';gv_vAlignTable['u240'] = 'center';gv_vAlignTable['u417'] = 'top';gv_vAlignTable['u636'] = 'center';gv_vAlignTable['u452'] = 'center';gv_vAlignTable['u603'] = 'top';gv_vAlignTable['u445'] = 'top';gv_vAlignTable['u304'] = 'center';gv_vAlignTable['u261'] = 'top';gv_vAlignTable['u632'] = 'top';gv_vAlignTable['u439'] = 'center';gv_vAlignTable['u658'] = 'center';gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u660'] = 'top';document.getElementById('u41_img').tabIndex = 0;
HookHover('u41', false);

u41.style.cursor = 'pointer';
$axure.eventManager.click('u41', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u221'] = 'center';document.getElementById('u47_img').tabIndex = 0;
HookHover('u47', false);

u47.style.cursor = 'pointer';
$axure.eventManager.click('u47', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
u16.tabIndex = 0;

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u58'] = 'center';document.getElementById('u78_img').tabIndex = 0;

u78.style.cursor = 'pointer';
$axure.eventManager.click('u78', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u587'] = 'top';gv_vAlignTable['u343'] = 'center';gv_vAlignTable['u184'] = 'top';gv_vAlignTable['u259'] = 'top';u590.tabIndex = 0;

u590.style.cursor = 'pointer';
$axure.eventManager.click('u590', function(e) {

if (true) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
u4.tabIndex = 0;

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u350'] = 'center';gv_vAlignTable['u583'] = 'top';gv_vAlignTable['u79'] = 'center';gv_vAlignTable['u105'] = 'center';gv_vAlignTable['u324'] = 'top';gv_vAlignTable['u199'] = 'center';gv_vAlignTable['u789'] = 'center';gv_vAlignTable['u253'] = 'center';gv_vAlignTable['u140'] = 'top';u165.tabIndex = 0;

u165.style.cursor = 'pointer';
$axure.eventManager.click('u165', function(e) {

if ((GetPanelState('u189')) != ('pd2u189')) {

	SetPanelState('u189', 'pd2u189','none','',500,'none','',500);

	SetPanelVisibility('u189','','none',500);

	MoveWidgetTo('u189', GetNum('365'), GetNum('272'),'none',500);

}
else
if ((GetPanelState('u189')) == ('pd2u189')) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
gv_vAlignTable['u165'] = 'top';HookHover('u133', false);
gv_vAlignTable['u504'] = 'top';gv_vAlignTable['u101'] = 'center';gv_vAlignTable['u345'] = 'top';gv_vAlignTable['u532'] = 'top';gv_vAlignTable['u557'] = 'top';gv_vAlignTable['u776'] = 'top';gv_vAlignTable['u339'] = 'center';gv_vAlignTable['u558'] = 'top';u13.tabIndex = 0;

u13.style.cursor = 'pointer';
$axure.eventManager.click('u13', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u13'] = 'top';gv_vAlignTable['u560'] = 'top';gv_vAlignTable['u148'] = 'top';gv_vAlignTable['u519'] = 'top';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u392'] = 'top';document.getElementById('u55_img').tabIndex = 0;
HookHover('u55', false);

u55.style.cursor = 'pointer';
$axure.eventManager.click('u55', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u830'] = 'center';gv_vAlignTable['u330'] = 'center';gv_vAlignTable['u487'] = 'top';gv_vAlignTable['u490'] = 'top';gv_vAlignTable['u3'] = 'center';gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u803'] = 'top';gv_vAlignTable['u567'] = 'center';gv_vAlignTable['u695'] = 'center';gv_vAlignTable['u831'] = 'top';gv_vAlignTable['u411'] = 'center';gv_vAlignTable['u404'] = 'top';gv_vAlignTable['u623'] = 'center';gv_vAlignTable['u818'] = 'top';gv_vAlignTable['u245'] = 'top';gv_vAlignTable['u616'] = 'top';gv_vAlignTable['u432'] = 'top';gv_vAlignTable['u458'] = 'center';gv_vAlignTable['u273'] = 'top';gv_vAlignTable['u644'] = 'center';u20.tabIndex = 0;

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u20'] = 'top';u460.tabIndex = 0;

u460.style.cursor = 'pointer';
$axure.eventManager.click('u460', function(e) {

if (true) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
gv_vAlignTable['u419'] = 'top';gv_vAlignTable['u638'] = 'center';u21.tabIndex = 0;

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u21'] = 'top';gv_vAlignTable['u672'] = 'top';gv_vAlignTable['u673'] = 'top';gv_vAlignTable['u27'] = 'top';gv_vAlignTable['u617'] = 'top';gv_vAlignTable['u659'] = 'top';document.getElementById('u45_img').tabIndex = 0;
HookHover('u45', false);

u45.style.cursor = 'pointer';
$axure.eventManager.click('u45', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u390'] = 'top';gv_vAlignTable['u595'] = 'center';u124.tabIndex = 0;

u124.style.cursor = 'pointer';
$axure.eventManager.click('u124', function(e) {

if (true) {

	SetPanelVisibility('u96','hidden','none',500);

}
});

$axure.eventManager.mouseover('u124', function(e) {
if (!IsTrueMouseOver('u124',e)) return;
if (true) {

	SetPanelVisibility('u112','','none',500);

}
});

$axure.eventManager.mouseout('u124', function(e) {
if (!IsTrueMouseOut('u124',e)) return;
if (true) {

	SetPanelVisibility('u112','hidden','none',500);

}
});
u589.tabIndex = 0;

u589.style.cursor = 'pointer';
$axure.eventManager.click('u589', function(e) {

if (true) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u117'] = 'center';gv_vAlignTable['u152'] = 'top';gv_vAlignTable['u398'] = 'center';gv_vAlignTable['u767'] = 'center';gv_vAlignTable['u108'] = 'center';gv_vAlignTable['u120'] = 'top';gv_vAlignTable['u516'] = 'center';u332.tabIndex = 0;

u332.style.cursor = 'pointer';
$axure.eventManager.click('u332', function(e) {

if (true) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
gv_vAlignTable['u703'] = 'top';gv_vAlignTable['u358'] = 'center';document.getElementById('u94_img').tabIndex = 0;

u94.style.cursor = 'pointer';
$axure.eventManager.click('u94', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u126'));

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Search_results.html');

}
});
gv_vAlignTable['u173'] = 'center';gv_vAlignTable['u544'] = 'top';gv_vAlignTable['u763'] = 'top';gv_vAlignTable['u360'] = 'top';gv_vAlignTable['u731'] = 'top';gv_vAlignTable['u756'] = 'center';gv_vAlignTable['u319'] = 'center';u11.tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
gv_vAlignTable['u11'] = 'top';gv_vAlignTable['u572'] = 'top';gv_vAlignTable['u70'] = 'center';u17.tabIndex = 0;

u17.style.cursor = 'pointer';
$axure.eventManager.click('u17', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u17'] = 'top';gv_vAlignTable['u76'] = 'center';gv_vAlignTable['u718'] = 'top';gv_vAlignTable['u559'] = 'top';gv_vAlignTable['u778'] = 'top';gv_vAlignTable['u287'] = 'top';gv_vAlignTable['u826'] = 'center';gv_vAlignTable['u167'] = 'center';u18.tabIndex = 0;

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u686'] = 'top';gv_vAlignTable['u308'] = 'center';gv_vAlignTable['u822'] = 'center';gv_vAlignTable['u495'] = 'center';gv_vAlignTable['u815'] = 'center';gv_vAlignTable['u682'] = 'center';gv_vAlignTable['u489'] = 'top';u28.tabIndex = 0;

u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	self.location.href='http://www.lucabenazzi.eu';

}
});
gv_vAlignTable['u809'] = 'center';gv_vAlignTable['u236'] = 'center';gv_vAlignTable['u85'] = 'center';document.getElementById('u65_img').tabIndex = 0;
HookHover('u65', false);

u65.style.cursor = 'pointer';
$axure.eventManager.click('u65', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u667'] = 'center';gv_vAlignTable['u610'] = 'center';gv_vAlignTable['u416'] = 'top';u721.tabIndex = 0;

u721.style.cursor = 'pointer';
$axure.eventManager.click('u721', function(e) {

if (true) {

	SetPanelState('u722', 'pd1u722','none','',500,'none','',500);
function waitu5da163c1c9ff46d48ccedd1b3741ed441() {

	SetPanelState('u722', 'pd2u722','none','',500,'none','',500);
function waitu9bb19b6303754b3980eb514dd16261441() {

	SetPanelState('u722', 'pd3u722','none','',500,'none','',500);
function waitu197cf57b9e684d8fbb7a14fbc05af3821() {

	SetPanelState('u722', 'pd4u722','none','',500,'none','',500);
function waitufb465931047b476491d48741262e0b801() {

	SetPanelState('u722', 'pd5u722','none','',500,'none','',500);
}
setTimeout(waitufb465931047b476491d48741262e0b801, 100);
}
setTimeout(waitu197cf57b9e684d8fbb7a14fbc05af3821, 100);
}
setTimeout(waitu9bb19b6303754b3980eb514dd16261441, 100);
}
setTimeout(waitu5da163c1c9ff46d48ccedd1b3741ed441, 100);

}
});
gv_vAlignTable['u721'] = 'top';gv_vAlignTable['u257'] = 'center';gv_vAlignTable['u258'] = 'top';document.getElementById('u84_img').tabIndex = 0;

u84.style.cursor = 'pointer';
$axure.eventManager.click('u84', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}

if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('OnLoadVariable')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u444'] = 'top';gv_vAlignTable['u260'] = 'top';gv_vAlignTable['u631'] = 'top';gv_vAlignTable['u656'] = 'center';gv_vAlignTable['u219'] = 'center';gv_vAlignTable['u472'] = 'top';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u66'] = 'center';gv_vAlignTable['u618'] = 'top';gv_vAlignTable['u459'] = 'top';gv_vAlignTable['u678'] = 'center';gv_vAlignTable['u25'] = 'top';gv_vAlignTable['u227'] = 'center';gv_vAlignTable['u187'] = 'center';gv_vAlignTable['u606'] = 'center';gv_vAlignTable['u586'] = 'center';u177.tabIndex = 0;

u177.style.cursor = 'pointer';
$axure.eventManager.click('u177', function(e) {

if ((GetPanelState('u189')) != ('pd1u189')) {

	SetPanelState('u189', 'pd1u189','none','',500,'none','',500);

	SetPanelVisibility('u189','','none',500);

	MoveWidgetTo('u189', GetNum('186'), GetNum('400'),'none',500);

}
else
if ((GetPanelState('u189')) == ('pd1u189')) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
gv_vAlignTable['u177'] = 'top';gv_vAlignTable['u183'] = 'center';gv_vAlignTable['u582'] = 'center';gv_vAlignTable['u389'] = 'top';gv_vAlignTable['u111'] = 'center';u136.tabIndex = 0;

u136.style.cursor = 'pointer';
$axure.eventManager.click('u136', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('My_details.html');

}
else
if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('LoginStatus')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u136'] = 'top';gv_vAlignTable['u726'] = 'center';gv_vAlignTable['u323'] = 'center';gv_vAlignTable['u510'] = 'center';gv_vAlignTable['u164'] = 'center';gv_vAlignTable['u754'] = 'center';gv_vAlignTable['u132'] = 'center';gv_vAlignTable['u503'] = 'top';gv_vAlignTable['u376'] = 'top';gv_vAlignTable['u747'] = 'top';gv_vAlignTable['u158'] = 'top';u720.tabIndex = 0;

u720.style.cursor = 'pointer';
$axure.eventManager.click('u720', function(e) {

if (true) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
gv_vAlignTable['u344'] = 'top';gv_vAlignTable['u563'] = 'center';gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u160'] = 'top';gv_vAlignTable['u531'] = 'top';gv_vAlignTable['u556'] = 'center';gv_vAlignTable['u119'] = 'top';gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u743'] = 'center';gv_vAlignTable['u179'] = 'center';gv_vAlignTable['u769'] = 'center';gv_vAlignTable['u711'] = 'top';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u518'] = 'top';gv_vAlignTable['u771'] = 'center';u8.tabIndex = 0;

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u359'] = 'top';gv_vAlignTable['u578'] = 'center';u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u191'] = 'center';gv_vAlignTable['u267'] = 'center';gv_vAlignTable['u813'] = 'center';gv_vAlignTable['u327'] = 'center';gv_vAlignTable['u486'] = 'center';gv_vAlignTable['u806'] = 'top';gv_vAlignTable['u841'] = 'top';gv_vAlignTable['u295'] = 'center';gv_vAlignTable['u834'] = 'top';gv_vAlignTable['u482'] = 'center';gv_vAlignTable['u802'] = 'center';gv_vAlignTable['u828'] = 'center';gv_vAlignTable['u315'] = 'top';gv_vAlignTable['u223'] = 'center';gv_vAlignTable['u467'] = 'center';gv_vAlignTable['u435'] = 'center';gv_vAlignTable['u654'] = 'center';gv_vAlignTable['u403'] = 'top';gv_vAlignTable['u647'] = 'top';gv_vAlignTable['u429'] = 'top';gv_vAlignTable['u244'] = 'top';gv_vAlignTable['u615'] = 'top';gv_vAlignTable['u431'] = 'top';u650.tabIndex = 0;

u650.style.cursor = 'pointer';
$axure.eventManager.click('u650', function(e) {

if (true) {

	SetPanelState('u591', 'pd6u591','none','',500,'none','',500);
function waitue85e44bb6c254bffb0a3bb075431f8a11() {

	SetPanelState('u591', 'pd7u591','none','',500,'none','',500);
function waitu734678392a144d1094f3a8ed037156e71() {

	SetPanelState('u591', 'pd8u591','none','',500,'none','',500);
function waitu24b4d290bbf14e9981916757f4de313b1() {

	SetPanelState('u591', 'pd0u591','none','',500,'none','',500);
}
setTimeout(waitu24b4d290bbf14e9981916757f4de313b1, 200);
}
setTimeout(waitu734678392a144d1094f3a8ed037156e71, 200);
}
setTimeout(waitue85e44bb6c254bffb0a3bb075431f8a11, 2000);

}
});
u456.tabIndex = 0;

u456.style.cursor = 'pointer';
$axure.eventManager.click('u456', function(e) {

if (true) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
gv_vAlignTable['u456'] = 'top';gv_vAlignTable['u675'] = 'top';gv_vAlignTable['u238'] = 'center';gv_vAlignTable['u272'] = 'top';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u669'] = 'center';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u418'] = 'top';gv_vAlignTable['u671'] = 'center';gv_vAlignTable['u478'] = 'center';gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u386'] = 'center';gv_vAlignTable['u195'] = 'center';gv_vAlignTable['u785'] = 'center';gv_vAlignTable['u382'] = 'center';gv_vAlignTable['u526'] = 'center';gv_vAlignTable['u216'] = 'top';u781.tabIndex = 0;

u781.style.cursor = 'pointer';
$axure.eventManager.click('u781', function(e) {

if (true) {

	SetPanelState('u722', 'pd6u722','none','',500,'none','',500);
function waitu2e6c7144f2d546659245c2d61e94ab031() {

	SetPanelState('u722', 'pd7u722','none','',500,'none','',500);
function waitu1ff41762dc1e4aca94fe7734924817741() {

	SetPanelState('u722', 'pd8u722','none','',500,'none','',500);
function waitu45b6db35df75406abc981d402c82d1ec1() {

	SetPanelState('u722', 'pd0u722','none','',500,'none','',500);
}
setTimeout(waitu45b6db35df75406abc981d402c82d1ec1, 200);
}
setTimeout(waitu1ff41762dc1e4aca94fe7734924817741, 200);
}
setTimeout(waitu2e6c7144f2d546659245c2d61e94ab031, 2000);

}
});
u123.tabIndex = 0;

u123.style.cursor = 'pointer';
$axure.eventManager.click('u123', function(e) {

if (true) {

	SetPanelVisibility('u96','hidden','none',500);

}
});

$axure.eventManager.mouseover('u123', function(e) {
if (!IsTrueMouseOver('u123',e)) return;
if (true) {

	SetPanelVisibility('u109','','none',500);

}
});

$axure.eventManager.mouseout('u123', function(e) {
if (!IsTrueMouseOut('u123',e)) return;
if (true) {

	SetPanelVisibility('u109','hidden','none',500);

}
});
u588.tabIndex = 0;

u588.style.cursor = 'pointer';
$axure.eventManager.click('u588', function(e) {

if (true) {

	SetPanelState('u591', 'pd1u591','none','',500,'none','',500);
function waitua1bc3447d7664ac4b8918a665dbbfa581() {

	SetPanelState('u591', 'pd2u591','none','',500,'none','',500);
function waitu46a87d0a91394a96a2034dcd7661d6c91() {

	SetPanelState('u591', 'pd3u591','none','',500,'none','',500);
function waituf07e7e53eb1c422c899e8a170a3820341() {

	SetPanelState('u591', 'pd4u591','none','',500,'none','',500);
function waitu3ab65033cd6d4a27879dccc690029d011() {

	SetPanelState('u591', 'pd5u591','none','',500,'none','',500);
}
setTimeout(waitu3ab65033cd6d4a27879dccc690029d011, 100);
}
setTimeout(waituf07e7e53eb1c422c899e8a170a3820341, 100);
}
setTimeout(waitu46a87d0a91394a96a2034dcd7661d6c91, 100);
}
setTimeout(waitua1bc3447d7664ac4b8918a665dbbfa581, 100);

}
});
gv_vAlignTable['u588'] = 'top';gv_vAlignTable['u230'] = 'top';gv_vAlignTable['u310'] = 'center';gv_vAlignTable['u706'] = 'center';gv_vAlignTable['u1'] = 'center';u522.tabIndex = 0;

u522.style.cursor = 'pointer';
$axure.eventManager.click('u522', function(e) {

if (true) {

	SetPanelState('u463', 'pd6u463','none','',500,'none','',500);
function waituf5876e245fdc4dd2906065baa28e00e11() {

	SetPanelState('u463', 'pd7u463','none','',500,'none','',500);
function waitu0c721f12446345289500423b4d08087a1() {

	SetPanelState('u463', 'pd8u463','none','',500,'none','',500);
function waituc3baa7910c4c41c180b9f41aa885896f1() {

	SetPanelState('u463', 'pd0u463','none','',500,'none','',500);
}
setTimeout(waituc3baa7910c4c41c180b9f41aa885896f1, 200);
}
setTimeout(waitu0c721f12446345289500423b4d08087a1, 200);
}
setTimeout(waituf5876e245fdc4dd2906065baa28e00e11, 2000);

}
});
gv_vAlignTable['u741'] = 'center';gv_vAlignTable['u547'] = 'top';gv_vAlignTable['u144'] = 'top';gv_vAlignTable['u734'] = 'top';gv_vAlignTable['u331'] = 'top';gv_vAlignTable['u702'] = 'top';gv_vAlignTable['u356'] = 'center';gv_vAlignTable['u575'] = 'top';gv_vAlignTable['u728'] = 'center';document.getElementById('u30_img').tabIndex = 0;

u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u762'] = 'top';gv_vAlignTable['u569'] = 'center';gv_vAlignTable['u730'] = 'center';gv_vAlignTable['u36'] = 'top';gv_vAlignTable['u291'] = 'center';gv_vAlignTable['u571'] = 'center';gv_vAlignTable['u775'] = 'center';gv_vAlignTable['u749'] = 'top';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u367'] = 'center';gv_vAlignTable['u72'] = 'center';gv_vAlignTable['u286'] = 'top';gv_vAlignTable['u800'] = 'center';gv_vAlignTable['u685'] = 'top';gv_vAlignTable['u282'] = 'center';gv_vAlignTable['u426'] = 'center';gv_vAlignTable['u488'] = 'top';gv_vAlignTable['u454'] = 'center';u203.tabIndex = 0;

u203.style.cursor = 'pointer';
$axure.eventManager.click('u203', function(e) {

if (true) {

	SetPanelState('u204', 'pd1u204','none','',500,'none','',500);
function waitu2045961950d24be18c307613adc3f2931() {

	SetPanelState('u204', 'pd2u204','none','',500,'none','',500);
function waitu4a5fbe6aa04d44c4a7b2a126aa1580061() {

	SetPanelState('u204', 'pd3u204','none','',500,'none','',500);
function waitub24fcd7739c64dfb86de2f983f7352141() {

	SetPanelState('u204', 'pd4u204','none','',500,'none','',500);
function waitud808020b38314c4580d98db05ef5c8be1() {

	SetPanelState('u204', 'pd5u204','none','',500,'none','',500);
}
setTimeout(waitud808020b38314c4580d98db05ef5c8be1, 100);
}
setTimeout(waitub24fcd7739c64dfb86de2f983f7352141, 100);
}
setTimeout(waitu4a5fbe6aa04d44c4a7b2a126aa1580061, 100);
}
setTimeout(waitu2045961950d24be18c307613adc3f2931, 100);

}
});
gv_vAlignTable['u203'] = 'top';gv_vAlignTable['u422'] = 'center';gv_vAlignTable['u447'] = 'top';gv_vAlignTable['u229'] = 'top';gv_vAlignTable['u415'] = 'center';gv_vAlignTable['u231'] = 'top';gv_vAlignTable['u602'] = 'top';gv_vAlignTable['u475'] = 'top';gv_vAlignTable['u409'] = 'center';gv_vAlignTable['u443'] = 'center';gv_vAlignTable['u662'] = 'top';gv_vAlignTable['u798'] = 'center';gv_vAlignTable['u469'] = 'center';gv_vAlignTable['u630'] = 'top';gv_vAlignTable['u26'] = 'top';gv_vAlignTable['u473'] = 'top';gv_vAlignTable['u471'] = 'center';gv_vAlignTable['u278'] = 'center';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u62'] = 'center';gv_vAlignTable['u377'] = 'top';u328.tabIndex = 0;

u328.style.cursor = 'pointer';
$axure.eventManager.click('u328', function(e) {

if (true) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
gv_vAlignTable['u328'] = 'top';u394.tabIndex = 0;

u394.style.cursor = 'pointer';
$axure.eventManager.click('u394', function(e) {

if (true) {

	SetPanelState('u335', 'pd6u335','none','',500,'none','',500);
function waitub69aeb726e7644609a8b07014b4e62911() {

	SetPanelState('u335', 'pd7u335','none','',500,'none','',500);
function waitu51ee9c4423fc4403b060711ef6fff4921() {

	SetPanelState('u335', 'pd8u335','none','',500,'none','',500);
function waitud505fc4274164fc2920d846b86b4de581() {

	SetPanelState('u335', 'pd0u335','none','',500,'none','',500);
}
setTimeout(waitud505fc4274164fc2920d846b86b4de581, 200);
}
setTimeout(waitu51ee9c4423fc4403b060711ef6fff4921, 200);
}
setTimeout(waitub69aeb726e7644609a8b07014b4e62911, 2000);

}
});
gv_vAlignTable['u316'] = 'top';gv_vAlignTable['u388'] = 'center';gv_vAlignTable['u354'] = 'center';gv_vAlignTable['u793'] = 'top';gv_vAlignTable['u700'] = 'top';u135.tabIndex = 0;

u135.style.cursor = 'pointer';
$axure.eventManager.click('u135', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
u103.tabIndex = 0;

u103.style.cursor = 'pointer';
$axure.eventManager.click('u103', function(e) {

if (true) {

	SetPanelVisibility('u96','hidden','none',500);

}
});

$axure.eventManager.mouseover('u103', function(e) {
if (!IsTrueMouseOver('u103',e)) return;
if (true) {

	SetPanelVisibility('u99','','none',500);

}
});

$axure.eventManager.mouseout('u103', function(e) {
if (!IsTrueMouseOut('u103',e)) return;
if (true) {

	SetPanelVisibility('u99','hidden','none',500);

}
});
gv_vAlignTable['u541'] = 'center';gv_vAlignTable['u347'] = 'top';u129.tabIndex = 0;

u129.style.cursor = 'pointer';
$axure.eventManager.click('u129', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');
function waitud60c4460105243299b524b0b32b428cf1() {

	SetPanelState('u128', 'pd1u128','none','',500,'none','',500);
function waitub3ccdb0e2b0e45289ccb18b7f7d0de481() {
function waitu7d17a4dc47ea4dd0b7636d8a947ae1e31() {
}
setTimeout(waitu7d17a4dc47ea4dd0b7636d8a947ae1e31, 200);
}
setTimeout(waitub3ccdb0e2b0e45289ccb18b7f7d0de481, 200);
}
setTimeout(waitud60c4460105243299b524b0b32b428cf1, 300);

}
});
gv_vAlignTable['u129'] = 'top';gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u534'] = 'top';document.getElementById('u131_img').tabIndex = 0;

u131.style.cursor = 'pointer';
$axure.eventManager.click('u131', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u502'] = 'top';gv_vAlignTable['u156'] = 'top';gv_vAlignTable['u746'] = 'top';gv_vAlignTable['u528'] = 'center';u10.tabIndex = 0;

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u714'] = 'center';gv_vAlignTable['u369'] = 'center';gv_vAlignTable['u530'] = 'center';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u708'] = 'center';gv_vAlignTable['u371'] = 'center';gv_vAlignTable['u34'] = 'center';gv_vAlignTable['u251'] = 'center';gv_vAlignTable['u210'] = 'center';gv_vAlignTable['u52'] = 'center';u837.tabIndex = 0;

u837.style.cursor = 'pointer';
$axure.eventManager.click('u837', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u837'] = 'top';gv_vAlignTable['u805'] = 'top';gv_vAlignTable['u697'] = 'center';gv_vAlignTable['u321'] = 'center';gv_vAlignTable['u840'] = 'center';gv_vAlignTable['u274'] = 'top';gv_vAlignTable['u833'] = 'top';gv_vAlignTable['u413'] = 'center';gv_vAlignTable['u693'] = 'center';gv_vAlignTable['u600'] = 'top';gv_vAlignTable['u406'] = 'top';gv_vAlignTable['u625'] = 'center';gv_vAlignTable['u441'] = 'center';gv_vAlignTable['u83'] = 'center';gv_vAlignTable['u215'] = 'top';gv_vAlignTable['u402'] = 'center';gv_vAlignTable['u621'] = 'center';gv_vAlignTable['u646'] = 'top';gv_vAlignTable['u428'] = 'center';gv_vAlignTable['u243'] = 'top';gv_vAlignTable['u614'] = 'center';u201.tabIndex = 0;

u201.style.cursor = 'pointer';
$axure.eventManager.click('u201', function(e) {

if (true) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
gv_vAlignTable['u269'] = 'center';gv_vAlignTable['u430'] = 'top';gv_vAlignTable['u455'] = 'top';gv_vAlignTable['u674'] = 'top';gv_vAlignTable['u608'] = 'center';gv_vAlignTable['u271'] = 'center';gv_vAlignTable['u642'] = 'center';gv_vAlignTable['u362'] = 'top';gv_vAlignTable['u42'] = 'center';u462.tabIndex = 0;

u462.style.cursor = 'pointer';
$axure.eventManager.click('u462', function(e) {

if (true) {

	SetPanelState('u463', 'pd1u463','none','',500,'none','',500);
function waitu8da23c147bb94fc5a36dc5d7de6e994d1() {

	SetPanelState('u463', 'pd2u463','none','',500,'none','',500);
function waitu1995a6ea86944ce8a3721ae1774a59f31() {

	SetPanelState('u463', 'pd3u463','none','',500,'none','',500);
function waitu83419e291bef413c9db1ee8938c1b4301() {

	SetPanelState('u463', 'pd4u463','none','',500,'none','',500);
function waitu696805b6d2854b75a9d573fd42eb1dfa1() {

	SetPanelState('u463', 'pd5u463','none','',500,'none','',500);
}
setTimeout(waitu696805b6d2854b75a9d573fd42eb1dfa1, 100);
}
setTimeout(waitu83419e291bef413c9db1ee8938c1b4301, 100);
}
setTimeout(waitu1995a6ea86944ce8a3721ae1774a59f31, 100);
}
setTimeout(waitu8da23c147bb94fc5a36dc5d7de6e994d1, 100);

}
});
gv_vAlignTable['u462'] = 'top';gv_vAlignTable['u95'] = 'center';gv_vAlignTable['u791'] = 'top';gv_vAlignTable['u597'] = 'center';
$axure.eventManager.keyup('u126', function(e) {

if ((GetWidgetText('u126')) == ('')) {

	SetPanelVisibility('u96','hidden','none',500);

}
else
if (true) {

	SetPanelState('u96', 'pd0u96','none','',500,'none','',500);

SetGlobalVariableValue('IncrementalSearchVar', GetWidgetText('u126'));

SetWidgetRichText('u118', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dada</span></p>');

SetWidgetRichText('u119', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dat</span></p>');

SetWidgetRichText('u120', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">gi</span></p>');

SetWidgetRichText('u122', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

SetWidgetRichText('u102', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

	SetPanelVisibility('u96','','none',500);

	BringToFront("u96");
function waitu796b5745765043a58e9fe38835b455f51() {

	SetPanelState('u96', 'pd1u96','none','',500,'none','',500);
}
setTimeout(waitu796b5745765043a58e9fe38835b455f51, 2000);

}
});

$axure.eventManager.blur('u126', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u126'));

}
});
gv_vAlignTable['u313'] = 'top';gv_vAlignTable['u188'] = 'top';gv_vAlignTable['u554'] = 'center';gv_vAlignTable['u593'] = 'center';gv_vAlignTable['u154'] = 'top';gv_vAlignTable['u352'] = 'center';gv_vAlignTable['u122'] = 'top';gv_vAlignTable['u341'] = 'center';gv_vAlignTable['u737'] = 'center';u334.tabIndex = 0;

u334.style.cursor = 'pointer';
$axure.eventManager.click('u334', function(e) {

if (true) {

	SetPanelState('u335', 'pd1u335','none','',500,'none','',500);
function waitu01a7344c92614cc48a8180e7494bff311() {

	SetPanelState('u335', 'pd2u335','none','',500,'none','',500);
function waitu57687ab6c8214dd4b2a95dee68ae20ba1() {

	SetPanelState('u335', 'pd3u335','none','',500,'none','',500);
function waitucae8de4cc4394410b2ae79a5613eb4211() {

	SetPanelState('u335', 'pd4u335','none','',500,'none','',500);
function waitu7ea0d49cd190463f9a73d1f6425f319f1() {

	SetPanelState('u335', 'pd5u335','none','',500,'none','',500);
}
setTimeout(waitu7ea0d49cd190463f9a73d1f6425f319f1, 100);
}
setTimeout(waitucae8de4cc4394410b2ae79a5613eb4211, 100);
}
setTimeout(waitu57687ab6c8214dd4b2a95dee68ae20ba1, 100);
}
setTimeout(waitu01a7344c92614cc48a8180e7494bff311, 100);

}
});
gv_vAlignTable['u334'] = 'top';gv_vAlignTable['u724'] = 'center';gv_vAlignTable['u150'] = 'top';document.getElementById('u59_img').tabIndex = 0;
HookHover('u59', false);

u59.style.cursor = 'pointer';
$axure.eventManager.click('u59', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u546'] = 'top';gv_vAlignTable['u91'] = 'center';gv_vAlignTable['u514'] = 'center';gv_vAlignTable['u733'] = 'top';gv_vAlignTable['u701'] = 'top';gv_vAlignTable['u574'] = 'top';gv_vAlignTable['u508'] = 'center';u171.tabIndex = 0;

u171.style.cursor = 'pointer';
$axure.eventManager.click('u171', function(e) {

if ((GetPanelState('u189')) != ('pd4u189')) {

	SetPanelState('u189', 'pd4u189','none','',500,'none','',500);

	SetPanelVisibility('u189','','none',500);

	MoveWidgetTo('u189', GetNum('497'), GetNum('305'),'none',500);

}
else
if ((GetPanelState('u189')) == ('pd4u189')) {

	SetPanelVisibility('u189','hidden','none',500);

}
});
gv_vAlignTable['u171'] = 'top';gv_vAlignTable['u761'] = 'top';u14.tabIndex = 0;

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u14'] = 'top';document.getElementById('u73_img').tabIndex = 0;
HookHover('u73', false);

u73.style.cursor = 'pointer';
$axure.eventManager.click('u73', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u629'] = 'center';gv_vAlignTable['u748'] = 'top';u9.tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u9'] = 'top';