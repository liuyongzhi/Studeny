﻿for(var i = 0; i < 339; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

SetGlobalVariableValue('BookPageViewed', 'Yes');

SetWidgetSelected('u85');
}

if ((GetGlobalVariableValue('BookQuantity')) == ('1')) {

SetWidgetRichText('u25', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:16px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Item price: £ 23.10</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:16px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Delivery: £ 1.20</span></p>');

SetWidgetRichText('u27', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:19px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Sub-total: </span><span style="font-family:Verdana;font-size:19px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">£ 24.30</span></p>');

SetWidgetRichText('u33', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">1</span></p>');

}

if ((GetGlobalVariableValue('BookQuantity')) == ('2')) {

SetWidgetRichText('u25', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:16px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Item price: £ 46.20</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:16px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Delivery: £ 1.20</span></p>');

SetWidgetRichText('u27', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:19px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Sub-total: </span><span style="font-family:Verdana;font-size:19px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">£ 47.40</span></p>');

SetWidgetRichText('u33', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">2</span></p>');

}

if ((GetGlobalVariableValue('BookQuantity')) >= Number('3')) {

SetWidgetRichText('u25', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:16px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Item price: £ 69.30</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:16px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Delivery: £ 1.20</span></p>');

SetWidgetRichText('u27', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:19px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Sub-total: </span><span style="font-family:Verdana;font-size:19px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">£ 70.50</span></p>');

SetWidgetRichText('u33', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">3</span></p>');

}

if ((GetGlobalVariableValue('ShoppingBasket')) == ('Empty')) {

	SetPanelState('u19', 'pd0u19','none','',500,'none','',500);

}

if ((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) {

	SetPanelState('u19', 'pd1u19','none','',500,'none','',500);

}
else
if (true) {

SetWidgetRichText('u33', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('BookQuantity')) + '</span></p>');

}

if ((GetGlobalVariableValue('ShoppingBasket')) == ('Empty')) {

	SetPanelState('u97', 'pd0u97','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('1'))) {

SetWidgetRichText('u99', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (1 item)</span></p>');

	SetPanelState('u97', 'pd1u97','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('2'))) {

SetWidgetRichText('u99', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (2 items)</span></p>');

	SetPanelState('u97', 'pd1u97','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('3'))) {

SetWidgetRichText('u99', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (3 items)</span></p>');

	SetPanelState('u97', 'pd1u97','none','',500,'none','',500);

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) {

}

});

function rdo1LoadHome(e) {

}
gv_vAlignTable['u167'] = 'top';gv_vAlignTable['u36'] = 'center';document.getElementById('u216_img').tabIndex = 0;

u216.style.cursor = 'pointer';
$axure.eventManager.click('u216', function(e) {

if (true) {

	SetPanelState('u206', 'pd1u206','none','',500,'none','',500);
function waitu1ce26ce310e34f5bba8cf68a5f3156a01() {

	SetPanelState('u206', 'pd2u206','none','',500,'none','',500);

	SetPanelVisibility('u197','hidden','none',500);
}
setTimeout(waitu1ce26ce310e34f5bba8cf68a5f3156a01, 1000);

}
});
gv_vAlignTable['u194'] = 'center';gv_vAlignTable['u72'] = 'center';gv_vAlignTable['u333'] = 'center';u152.tabIndex = 0;

u152.style.cursor = 'pointer';
$axure.eventManager.click('u152', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('My_details.html');

}
else
if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('LoginStatus')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u152'] = 'top';gv_vAlignTable['u231'] = 'top';gv_vAlignTable['u60'] = 'center';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u166'] = 'center';gv_vAlignTable['u298'] = 'center';u139.tabIndex = 0;

u139.style.cursor = 'pointer';
$axure.eventManager.click('u139', function(e) {

if (true) {

	SetPanelVisibility('u112','hidden','none',500);

}
});

$axure.eventManager.mouseover('u139', function(e) {
if (!IsTrueMouseOver('u139',e)) return;
if (true) {

	SetPanelVisibility('u125','','none',500);

}
});

$axure.eventManager.mouseout('u139', function(e) {
if (!IsTrueMouseOut('u139',e)) return;
if (true) {

	SetPanelVisibility('u125','hidden','none',500);

}
});
gv_vAlignTable['u201'] = 'top';u1.tabIndex = 0;

u1.style.cursor = 'pointer';
$axure.eventManager.click('u1', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u1'] = 'top';gv_vAlignTable['u215'] = 'center';document.getElementById('u193_img').tabIndex = 0;

u193.style.cursor = 'pointer';
$axure.eventManager.click('u193', function(e) {

if (true) {

	SetPanelState('u180', 'pd2u180','none','',500,'none','',500);

}
});
document.getElementById('u11_img').tabIndex = 0;

u11.style.cursor = 'pointer';
$axure.eventManager.click('u11', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Write_review.html');

}
});
document.getElementById('u332_img').tabIndex = 0;

u332.style.cursor = 'pointer';
$axure.eventManager.click('u332', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
u151.tabIndex = 0;

u151.style.cursor = 'pointer';
$axure.eventManager.click('u151', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u202'] = 'top';gv_vAlignTable['u138'] = 'top';document.getElementById('u100_img').tabIndex = 0;

u100.style.cursor = 'pointer';
$axure.eventManager.click('u100', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}

if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('OnLoadVariable')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u236'] = 'top';gv_vAlignTable['u192'] = 'center';document.getElementById('u67_img').tabIndex = 0;
HookHover('u67', false);

u67.style.cursor = 'pointer';
$axure.eventManager.click('u67', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
u321.tabIndex = 0;

u321.style.cursor = 'pointer';
$axure.eventManager.click('u321', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u321'] = 'top';gv_vAlignTable['u150'] = 'center';gv_vAlignTable['u287'] = 'center';document.getElementById('u48_img').tabIndex = 0;

u48.style.cursor = 'pointer';
$axure.eventManager.click('u48', function(e) {

if (true) {

SetGlobalVariableValue('BookQuantity', GetWidgetText('u51'));

SetGlobalVariableValue('ShoppingBasket', 'Full');

SetWidgetRichText('u33', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('BookQuantity')) + '</span></p>');

	self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

function waitu698e4adb9ac04a4ea33ff19b0a28ab551() {

	SetPanelState('u19', 'pd1u19','none','',500,'none','',500);
}
setTimeout(waitu698e4adb9ac04a4ea33ff19b0a28ab551, 500);

}
});
gv_vAlignTable['u327'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u80'] = 'center';u318.tabIndex = 0;

u318.style.cursor = 'pointer';
$axure.eventManager.click('u318', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u318'] = 'top';gv_vAlignTable['u268'] = 'top';u330.tabIndex = 0;

u330.style.cursor = 'pointer';
$axure.eventManager.click('u330', function(e) {

if (true) {

	self.location.href='http://www.lucabenazzi.eu';

}
});
gv_vAlignTable['u159'] = 'top';document.getElementById('u163_img').tabIndex = 0;

u163.style.cursor = 'pointer';
$axure.eventManager.click('u163', function(e) {

if (true) {

	SetPanelVisibility('u162','hidden','none',500);

	MoveWidgetBy('u196', GetNum('0'), GetNum('-150'),'none',500);

	MoveWidgetBy('u239', GetNum('0'), GetNum('-150'),'none',500);

	MoveWidgetBy('u295', GetNum('0'), GetNum('-150'),'none',500);

}
});
document.getElementById('u63_img').tabIndex = 0;
HookHover('u63', false);

u63.style.cursor = 'pointer';
$axure.eventManager.click('u63', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
document.getElementById('u37_img').tabIndex = 0;

u37.style.cursor = 'pointer';
$axure.eventManager.click('u37', function(e) {

if (true) {

	SetPanelState('u34', 'pd0u34','none','',500,'none','',500);

	SetPanelVisibility('u34','hidden','none',500);

}
});
u307.tabIndex = 0;

u307.style.cursor = 'pointer';
$axure.eventManager.click('u307', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u307'] = 'top';gv_vAlignTable['u18'] = 'top';gv_vAlignTable['u50'] = 'top';gv_vAlignTable['u74'] = 'center';document.getElementById('u79_img').tabIndex = 0;
HookHover('u79', false);

u79.style.cursor = 'pointer';
$axure.eventManager.click('u79', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
document.getElementById('u55_img').tabIndex = 0;
HookHover('u55', false);

u55.style.cursor = 'pointer';
$axure.eventManager.click('u55', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
HookHover('u149', false);
gv_vAlignTable['u111'] = 'center';u306.tabIndex = 0;

u306.style.cursor = 'pointer';
$axure.eventManager.click('u306', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u306'] = 'top';gv_vAlignTable['u284'] = 'top';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u161'] = 'center';gv_vAlignTable['u329'] = 'top';gv_vAlignTable['u175'] = 'center';gv_vAlignTable['u148'] = 'center';document.getElementById('u110_img').tabIndex = 0;

u110.style.cursor = 'pointer';
$axure.eventManager.click('u110', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u142'));

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Search_results.html');

}
});
gv_vAlignTable['u305'] = 'center';gv_vAlignTable['u283'] = 'top';gv_vAlignTable['u124'] = 'center';gv_vAlignTable['u279'] = 'center';u241.tabIndex = 0;

u241.style.cursor = 'pointer';
$axure.eventManager.click('u241', function(e) {

if (true) {

	SetPanelState('u240', 'pd0u240','none','',500,'none','',500);

	SetPanelVisibility('u263','hidden','none',500);

	MoveWidgetBy('u295', GetNum('0'), GetNum('-150'),'none',500);

	MoveWidgetBy('u301', GetNum('0'), GetNum('-150'),'none',500);

}
});
gv_vAlignTable['u241'] = 'top';document.getElementById('u297_img').tabIndex = 0;

u297.style.cursor = 'pointer';
$axure.eventManager.click('u297', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Write_review.html');

}
});
gv_vAlignTable['u8'] = 'center';gv_vAlignTable['u49'] = 'center';gv_vAlignTable['u25'] = 'top';document.getElementById('u81_img').tabIndex = 0;
HookHover('u81', false);

u81.style.cursor = 'pointer';
$axure.eventManager.click('u81', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u228'] = 'center';gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u282'] = 'center';gv_vAlignTable['u76'] = 'center';u296.tabIndex = 0;

u296.style.cursor = 'pointer';
$axure.eventManager.click('u296', function(e) {

if (true) {

	ScrollToWidget('u294', false,true,'none',500);

}
});
gv_vAlignTable['u296'] = 'top';u137.tabIndex = 0;

u137.style.cursor = 'pointer';
$axure.eventManager.click('u137', function(e) {

if (true) {

	SetPanelVisibility('u112','hidden','none',500);

}
});

$axure.eventManager.mouseover('u137', function(e) {
if (!IsTrueMouseOver('u137',e)) return;
if (true) {

	SetPanelVisibility('u122','','none',500);

}
});

$axure.eventManager.mouseout('u137', function(e) {
if (!IsTrueMouseOut('u137',e)) return;
if (true) {

	SetPanelVisibility('u122','hidden','none',500);

}
});
gv_vAlignTable['u33'] = 'top';gv_vAlignTable['u254'] = 'center';gv_vAlignTable['u173'] = 'center';gv_vAlignTable['u213'] = 'center';gv_vAlignTable['u303'] = 'center';document.getElementById('u94_img').tabIndex = 0;

u94.style.cursor = 'pointer';
$axure.eventManager.click('u94', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u5'] = 'top';u317.tabIndex = 0;

u317.style.cursor = 'pointer';
$axure.eventManager.click('u317', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u317'] = 'top';gv_vAlignTable['u136'] = 'top';gv_vAlignTable['u109'] = 'top';document.getElementById('u172_img').tabIndex = 0;

u172.style.cursor = 'pointer';
$axure.eventManager.click('u172', function(e) {

if (true) {

	SetPanelState('u162', 'pd1u162','none','',500,'none','',500);
function waitu06f17b6e82c7452a96b3ae970f95db051() {

	SetPanelState('u162', 'pd2u162','none','',500,'none','',500);

	SetPanelVisibility('u177','hidden','none',500);
}
setTimeout(waitu06f17b6e82c7452a96b3ae970f95db051, 1000);

}
});
gv_vAlignTable['u267'] = 'center';gv_vAlignTable['u121'] = 'center';u316.tabIndex = 0;

u316.style.cursor = 'pointer';
$axure.eventManager.click('u316', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u316'] = 'top';gv_vAlignTable['u135'] = 'top';gv_vAlignTable['u108'] = 'top';gv_vAlignTable['u252'] = 'top';gv_vAlignTable['u171'] = 'center';gv_vAlignTable['u64'] = 'center';u2.tabIndex = 0;

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u2'] = 'top';u315.tabIndex = 0;

u315.style.cursor = 'pointer';
$axure.eventManager.click('u315', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u315'] = 'top';u293.tabIndex = 0;

u293.style.cursor = 'pointer';
$axure.eventManager.click('u293', function(e) {

if (true) {

	SetPanelVisibility('u285','hidden','none',500);

}
});
gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u134'] = 'top';gv_vAlignTable['u251'] = 'center';gv_vAlignTable['u265'] = 'center';gv_vAlignTable['u82'] = 'center';gv_vAlignTable['u238'] = 'top';gv_vAlignTable['u200'] = 'top';u314.tabIndex = 0;

u314.style.cursor = 'pointer';
$axure.eventManager.click('u314', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u314'] = 'top';u292.tabIndex = 0;

u292.style.cursor = 'pointer';
$axure.eventManager.click('u292', function(e) {

if (true) {

	SetPanelVisibility('u285','hidden','none',500);

}
});
gv_vAlignTable['u292'] = 'top';document.getElementById('u77_img').tabIndex = 0;
HookHover('u77', false);

u77.style.cursor = 'pointer';
$axure.eventManager.click('u77', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
gv_vAlignTable['u133'] = 'center';document.getElementById('u147_img').tabIndex = 0;

u147.style.cursor = 'pointer';
$axure.eventManager.click('u147', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u90'] = 'center';document.getElementById('u61_img').tabIndex = 0;
HookHover('u61', false);

u61.style.cursor = 'pointer';
$axure.eventManager.click('u61', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u164'] = 'center';gv_vAlignTable['u95'] = 'center';document.getElementById('u191_img').tabIndex = 0;

u191.style.cursor = 'pointer';
$axure.eventManager.click('u191', function(e) {

if (true) {

	SetPanelState('u180', 'pd1u180','none','',500,'none','',500);

}
});
u146.tabIndex = 0;

u146.style.cursor = 'pointer';
$axure.eventManager.click('u146', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');

SetGlobalVariableValue('BookPageViewed', '');

SetGlobalVariableValue('CitySelected', '');

SetGlobalVariableValue('LoginStatus', '');

SetGlobalVariableValue('ReviewVar', '');

SetGlobalVariableValue('EmployeesName', '');

	SetPanelState('u144', 'pd1u144','none','',500,'none','',500);
function waituf022ddcb6b474903a282219d39d908ef1() {

	SetPanelState('u144', 'pd0u144','none','',500,'none','',500);
}
setTimeout(waituf022ddcb6b474903a282219d39d908ef1, 4000);

}
});
gv_vAlignTable['u146'] = 'top';document.getElementById('u52_img').tabIndex = 0;

u52.style.cursor = 'pointer';
$axure.eventManager.click('u52', function(e) {

if (true) {

SetGlobalVariableValue('BookQuantity', GetWidgetText('u51'));

SetGlobalVariableValue('ShoppingBasket', 'Full');

SetWidgetRichText('u33', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('BookQuantity')) + '</span></p>');

	self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

function waitu00a0caff81da4e81872e62ca8e3d46d51() {

	SetPanelState('u19', 'pd1u19','none','',500,'none','',500);
}
setTimeout(waitu00a0caff81da4e81872e62ca8e3d46d51, 500);

}
});
gv_vAlignTable['u277'] = 'center';gv_vAlignTable['u47'] = 'center';document.getElementById('u28_img').tabIndex = 0;

u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}
});
u145.tabIndex = 0;

u145.style.cursor = 'pointer';
$axure.eventManager.click('u145', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');
function waitud60c4460105243299b524b0b32b428cf1() {

	SetPanelState('u144', 'pd1u144','none','',500,'none','',500);
function waitub3ccdb0e2b0e45289ccb18b7f7d0de481() {
function waitu7d17a4dc47ea4dd0b7636d8a947ae1e31() {
}
setTimeout(waitu7d17a4dc47ea4dd0b7636d8a947ae1e31, 200);
}
setTimeout(waitub3ccdb0e2b0e45289ccb18b7f7d0de481, 200);
}
setTimeout(waitud60c4460105243299b524b0b32b428cf1, 300);

}
});
gv_vAlignTable['u145'] = 'top';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u262'] = 'top';u322.tabIndex = 0;

u322.style.cursor = 'pointer';
$axure.eventManager.click('u322', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u322'] = 'top';document.getElementById('u276_img').tabIndex = 0;

u276.style.cursor = 'pointer';
$axure.eventManager.click('u276', function(e) {

if (true) {

	SetPanelState('u240', 'pd0u240','none','',500,'none','',500);

	SetPanelVisibility('u263','hidden','none',500);

	MoveWidgetBy('u295', GetNum('0'), GetNum('-150'),'none',500);

}
});
HookHover('u65', false);
gv_vAlignTable['u249'] = 'center';gv_vAlignTable['u211'] = 'top';gv_vAlignTable['u130'] = 'center';document.getElementById('u85_img').tabIndex = 0;
HookHover('u85', false);

u85.style.cursor = 'pointer';
$axure.eventManager.click('u85', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u261'] = 'center';gv_vAlignTable['u43'] = 'center';gv_vAlignTable['u275'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u210'] = 'center';gv_vAlignTable['u325'] = 'top';gv_vAlignTable['u107'] = 'center';document.getElementById('u30_img').tabIndex = 0;

u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if (true) {

	SetPanelState('u34', 'pd0u34','none','',500,'none','',500);
function waitu0d7b63377e0e4429ada28a285ba48cc71() {

	SetPanelState('u34', 'pd1u34','none','',500,'none','',500);
function waitu09deb7cda5df41688a17b21ecdd897ed1() {

	SetPanelState('u34', 'pd2u34','none','',500,'none','',500);
function waitu97a43e48209a4061b4f9260b3b1e63be1() {

	SetPanelState('u34', 'pd3u34','none','',500,'none','',500);
function waitu6bd26c285c034e508f53ee37c788fd161() {

	SetPanelState('u34', 'pd4u34','none','',500,'none','',500);
}
setTimeout(waitu6bd26c285c034e508f53ee37c788fd161, 100);
}
setTimeout(waitu97a43e48209a4061b4f9260b3b1e63be1, 100);
}
setTimeout(waitu09deb7cda5df41688a17b21ecdd897ed1, 100);
}
setTimeout(waitu0d7b63377e0e4429ada28a285ba48cc71, 100);

}
});
u143.tabIndex = 0;

u143.style.cursor = 'pointer';
$axure.eventManager.click('u143', function(e) {

if (true) {

	self.location.href='index.html';

}
});
gv_vAlignTable['u143'] = 'top';document.getElementById('u260_img').tabIndex = 0;

u260.style.cursor = 'pointer';
$axure.eventManager.click('u260', function(e) {

if (true) {

	SetPanelState('u247', 'pd2u247','none','',500,'none','',500);

}
});
document.getElementById('u9_img').tabIndex = 0;

u9.style.cursor = 'pointer';
$axure.eventManager.click('u9', function(e) {

if (true) {

	SetPanelVisibility('u285','','none',500);

	BringToFront("u285");

}
});
gv_vAlignTable['u157'] = 'top';document.getElementById('u59_img').tabIndex = 0;
HookHover('u59', false);

u59.style.cursor = 'pointer';
$axure.eventManager.click('u59', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u189'] = 'center';document.getElementById('u274_img').tabIndex = 0;

u274.style.cursor = 'pointer';
$axure.eventManager.click('u274', function(e) {

if (true) {

	SetPanelState('u263', 'pd1u263','none','',500,'none','',500);
function waitu03ca8bdb1cb644e4a08527d1f670d59d1() {

	SetPanelState('u263', 'pd2u263','none','',500,'none','',500);

	SetPanelVisibility('u240','hidden','none',500);
}
setTimeout(waitu03ca8bdb1cb644e4a08527d1f670d59d1, 1000);

}
});
u309.tabIndex = 0;

u309.style.cursor = 'pointer';
$axure.eventManager.click('u309', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u309'] = 'top';gv_vAlignTable['u328'] = 'top';gv_vAlignTable['u223'] = 'center';
$axure.eventManager.keyup('u142', function(e) {

if ((GetWidgetText('u142')) == ('')) {

	SetPanelVisibility('u112','hidden','none',500);

}
else
if (true) {

	SetPanelState('u112', 'pd0u112','none','',500,'none','',500);

SetGlobalVariableValue('IncrementalSearchVar', GetWidgetText('u142'));

SetWidgetRichText('u134', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dada</span></p>');

SetWidgetRichText('u135', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dat</span></p>');

SetWidgetRichText('u136', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">gi</span></p>');

SetWidgetRichText('u138', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

SetWidgetRichText('u118', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

	SetPanelVisibility('u112','','none',500);

	BringToFront("u112");
function waitu796b5745765043a58e9fe38835b455f51() {

	SetPanelState('u112', 'pd1u112','none','',500,'none','',500);
}
setTimeout(waitu796b5745765043a58e9fe38835b455f51, 2000);

}
});

$axure.eventManager.blur('u142', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u142'));

}
});
gv_vAlignTable['u86'] = 'center';gv_vAlignTable['u70'] = 'center';gv_vAlignTable['u156'] = 'top';gv_vAlignTable['u105'] = 'center';u311.tabIndex = 0;

u311.style.cursor = 'pointer';
$axure.eventManager.click('u311', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u311'] = 'top';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u155'] = 'top';gv_vAlignTable['u272'] = 'center';gv_vAlignTable['u336'] = 'center';u308.tabIndex = 0;

u308.style.cursor = 'pointer';
$axure.eventManager.click('u308', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u308'] = 'top';gv_vAlignTable['u259'] = 'center';u119.tabIndex = 0;

u119.style.cursor = 'pointer';
$axure.eventManager.click('u119', function(e) {

if (true) {

	SetPanelVisibility('u112','hidden','none',500);

}
});

$axure.eventManager.mouseover('u119', function(e) {
if (!IsTrueMouseOver('u119',e)) return;
if (true) {

	SetPanelVisibility('u115','','none',500);

}
});

$axure.eventManager.mouseout('u119', function(e) {
if (!IsTrueMouseOut('u119',e)) return;
if (true) {

	SetPanelVisibility('u115','hidden','none',500);

}
});
document.getElementById('u232_img').tabIndex = 0;

u232.style.cursor = 'pointer';
$axure.eventManager.click('u232', function(e) {

if (true) {

	SetPanelState('u221', 'pd1u221','none','',500,'none','',500);

}
});
gv_vAlignTable['u235'] = 'center';document.getElementById('u75_img').tabIndex = 0;
HookHover('u75', false);

u75.style.cursor = 'pointer';
$axure.eventManager.click('u75', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u208'] = 'center';u312.tabIndex = 0;

u312.style.cursor = 'pointer';
$axure.eventManager.click('u312', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u312'] = 'top';document.getElementById('u98_img').tabIndex = 0;

u98.style.cursor = 'pointer';
$axure.eventManager.click('u98', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}
});
gv_vAlignTable['u103'] = 'center';gv_vAlignTable['u158'] = 'top';u3.tabIndex = 0;

u3.style.cursor = 'pointer';
$axure.eventManager.click('u3', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u3'] = 'top';gv_vAlignTable['u117'] = 'center';gv_vAlignTable['u31'] = 'center';document.getElementById('u234_img').tabIndex = 0;

u234.style.cursor = 'pointer';
$axure.eventManager.click('u234', function(e) {

if (true) {

	SetPanelState('u221', 'pd2u221','none','',500,'none','',500);

}
});
document.getElementById('u73_img').tabIndex = 0;
HookHover('u73', false);

u73.style.cursor = 'pointer';
$axure.eventManager.click('u73', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u270'] = 'center';u199.tabIndex = 0;

u199.style.cursor = 'pointer';
$axure.eventManager.click('u199', function(e) {

if (true) {

	SetPanelState('u197', 'pd1u197','none','',500,'none','',500);

	SetPanelVisibility('u206','','none',500);

	MoveWidgetBy('u239', GetNum('0'), GetNum('150'),'none',500);

	MoveWidgetBy('u295', GetNum('0'), GetNum('150'),'none',500);

	MoveWidgetBy('u301', GetNum('0'), GetNum('150'),'none',500);

	BringToFront("u206");

}
});
gv_vAlignTable['u199'] = 'top';u319.tabIndex = 0;

u319.style.cursor = 'pointer';
$axure.eventManager.click('u319', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u319'] = 'top';gv_vAlignTable['u92'] = 'center';gv_vAlignTable['u56'] = 'center';gv_vAlignTable['u300'] = 'top';gv_vAlignTable['u233'] = 'center';document.getElementById('u87_img').tabIndex = 0;
HookHover('u87', false);

u87.style.cursor = 'pointer';
$axure.eventManager.click('u87', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u68'] = 'center';gv_vAlignTable['u226'] = 'top';u198.tabIndex = 0;

u198.style.cursor = 'pointer';
$axure.eventManager.click('u198', function(e) {

if (true) {

	SetPanelState('u197', 'pd0u197','none','',500,'none','',500);

	SetPanelVisibility('u206','hidden','none',500);

	MoveWidgetBy('u239', GetNum('0'), GetNum('-150'),'none',500);

	MoveWidgetBy('u295', GetNum('0'), GetNum('-150'),'none',500);

	MoveWidgetBy('u301', GetNum('0'), GetNum('-150'),'none',500);

}
});
gv_vAlignTable['u198'] = 'top';gv_vAlignTable['u101'] = 'center';u0.tabIndex = 0;

u0.style.cursor = 'pointer';
$axure.eventManager.click('u0', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u0'] = 'top';gv_vAlignTable['u190'] = 'top';document.getElementById('u89_img').tabIndex = 0;
HookHover('u89', false);

u89.style.cursor = 'pointer';
$axure.eventManager.click('u89', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
u313.tabIndex = 0;

u313.style.cursor = 'pointer';
$axure.eventManager.click('u313', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
gv_vAlignTable['u313'] = 'top';gv_vAlignTable['u291'] = 'center';document.getElementById('u7_img').tabIndex = 0;
HookHover('u7', false);

u7.style.cursor = 'pointer';
$axure.eventManager.click('u7', function(e) {

if (true) {

	SetPanelVisibility('u285','','none',500);

	BringToFront("u285");

}
});
gv_vAlignTable['u246'] = 'top';gv_vAlignTable['u62'] = 'center';gv_vAlignTable['u219'] = 'center';gv_vAlignTable['u114'] = 'center';document.getElementById('u57_img').tabIndex = 0;
HookHover('u57', false);

u57.style.cursor = 'pointer';
$axure.eventManager.click('u57', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u169'] = 'center';gv_vAlignTable['u187'] = 'center';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u245'] = 'top';gv_vAlignTable['u14'] = 'center';document.getElementById('u218_img').tabIndex = 0;

u218.style.cursor = 'pointer';
$axure.eventManager.click('u218', function(e) {

if (true) {

	SetPanelState('u197', 'pd0u197','none','',500,'none','',500);

	SetPanelVisibility('u206','hidden','none',500);

	MoveWidgetBy('u239', GetNum('0'), GetNum('-150'),'none',500);

	MoveWidgetBy('u295', GetNum('0'), GetNum('-150'),'none',500);

}
});
gv_vAlignTable['u99'] = 'center';gv_vAlignTable['u230'] = 'center';gv_vAlignTable['u127'] = 'center';gv_vAlignTable['u338'] = 'top';gv_vAlignTable['u32'] = 'top';gv_vAlignTable['u244'] = 'top';gv_vAlignTable['u27'] = 'top';document.getElementById('u83_img').tabIndex = 0;
HookHover('u83', false);

u83.style.cursor = 'pointer';
$axure.eventManager.click('u83', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
u310.tabIndex = 0;

u310.style.cursor = 'pointer';
$axure.eventManager.click('u310', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u310'] = 'top';document.getElementById('u207_img').tabIndex = 0;

u207.style.cursor = 'pointer';
$axure.eventManager.click('u207', function(e) {

if (true) {

	SetPanelVisibility('u206','hidden','none',500);

	MoveWidgetBy('u239', GetNum('0'), GetNum('-150'),'none',500);

	MoveWidgetBy('u295', GetNum('0'), GetNum('-150'),'none',500);

}
});
gv_vAlignTable['u185'] = 'top';u324.tabIndex = 0;

u324.style.cursor = 'pointer';
$axure.eventManager.click('u324', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u324'] = 'top';gv_vAlignTable['u243'] = 'top';gv_vAlignTable['u257'] = 'top';document.getElementById('u69_img').tabIndex = 0;
HookHover('u69', false);

u69.style.cursor = 'pointer';
$axure.eventManager.click('u69', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u289'] = 'center';gv_vAlignTable['u45'] = 'center';gv_vAlignTable['u184'] = 'center';u323.tabIndex = 0;

u323.style.cursor = 'pointer';
$axure.eventManager.click('u323', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u323'] = 'top';u242.tabIndex = 0;

u242.style.cursor = 'pointer';
$axure.eventManager.click('u242', function(e) {

if (true) {

	SetPanelState('u240', 'pd1u240','none','',500,'none','',500);

	SetPanelVisibility('u263','','none',500);

	MoveWidgetBy('u295', GetNum('0'), GetNum('150'),'none',500);

	MoveWidgetBy('u301', GetNum('0'), GetNum('150'),'none',500);

	BringToFront("u263");

}
});
gv_vAlignTable['u242'] = 'top';gv_vAlignTable['u256'] = 'center';gv_vAlignTable['u53'] = 'center';document.getElementById('u174_img').tabIndex = 0;

u174.style.cursor = 'pointer';
$axure.eventManager.click('u174', function(e) {

if (true) {

	SetPanelState('u177', 'pd0u177','none','',500,'none','',500);

	SetPanelVisibility('u162','hidden','none',500);

	MoveWidgetBy('u196', GetNum('0'), GetNum('-150'),'none',500);

	MoveWidgetBy('u239', GetNum('0'), GetNum('-150'),'none',500);

	MoveWidgetBy('u295', GetNum('0'), GetNum('-150'),'none',500);

}
});
gv_vAlignTable['u205'] = 'center';gv_vAlignTable['u10'] = 'center';u179.tabIndex = 0;

u179.style.cursor = 'pointer';
$axure.eventManager.click('u179', function(e) {

if (true) {

	SetPanelState('u177', 'pd1u177','none','',500,'none','',500);

	SetPanelVisibility('u162','','none',500);

	MoveWidgetBy('u196', GetNum('0'), GetNum('150'),'none',500);

	MoveWidgetBy('u239', GetNum('0'), GetNum('150'),'none',500);

	MoveWidgetBy('u295', GetNum('0'), GetNum('150'),'none',500);

	MoveWidgetBy('u301', GetNum('0'), GetNum('150'),'none',500);

	BringToFront("u162");

}
});
gv_vAlignTable['u179'] = 'top';u141.tabIndex = 0;

u141.style.cursor = 'pointer';
$axure.eventManager.click('u141', function(e) {

if (true) {

	SetPanelVisibility('u112','hidden','none',500);

}
});

$axure.eventManager.mouseover('u141', function(e) {
if (!IsTrueMouseOver('u141',e)) return;
if (true) {

	SetPanelVisibility('u131','','none',500);

}
});

$axure.eventManager.mouseout('u141', function(e) {
if (!IsTrueMouseOut('u141',e)) return;
if (true) {

	SetPanelVisibility('u131','hidden','none',500);

}
});
u39.tabIndex = 0;

u39.style.cursor = 'pointer';
$axure.eventManager.click('u39', function(e) {

if (true) {

	SetPanelState('u34', 'pd0u34','none','',500,'none','',500);

	SetPanelVisibility('u34','hidden','none',500);

}
});
gv_vAlignTable['u39'] = 'top';document.getElementById('u71_img').tabIndex = 0;
HookHover('u71', false);

u71.style.cursor = 'pointer';
$axure.eventManager.click('u71', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
u15.tabIndex = 0;

u15.style.cursor = 'pointer';
$axure.eventManager.click('u15', function(e) {

if (true) {

	SetPanelVisibility('u285','','none',500);

	BringToFront("u285");

}
});
gv_vAlignTable['u15'] = 'top';gv_vAlignTable['u182'] = 'center';gv_vAlignTable['u66'] = 'center';u178.tabIndex = 0;

u178.style.cursor = 'pointer';
$axure.eventManager.click('u178', function(e) {

if (true) {

	SetPanelState('u177', 'pd0u177','none','',500,'none','',500);

	SetPanelVisibility('u162','hidden','none',500);

	MoveWidgetBy('u196', GetNum('0'), GetNum('-150'),'none',500);

	MoveWidgetBy('u239', GetNum('0'), GetNum('-150'),'none',500);

	MoveWidgetBy('u295', GetNum('0'), GetNum('-150'),'none',500);

	MoveWidgetBy('u301', GetNum('0'), GetNum('-150'),'none',500);

}
});
gv_vAlignTable['u178'] = 'top';u140.tabIndex = 0;

u140.style.cursor = 'pointer';
$axure.eventManager.click('u140', function(e) {

if (true) {

	SetPanelVisibility('u112','hidden','none',500);

}
});

$axure.eventManager.mouseover('u140', function(e) {
if (!IsTrueMouseOver('u140',e)) return;
if (true) {

	SetPanelVisibility('u128','','none',500);

}
});

$axure.eventManager.mouseout('u140', function(e) {
if (!IsTrueMouseOut('u140',e)) return;
if (true) {

	SetPanelVisibility('u128','hidden','none',500);

}
});
u23.tabIndex = 0;

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u23'] = 'top';gv_vAlignTable['u154'] = 'top';document.getElementById('u264_img').tabIndex = 0;

u264.style.cursor = 'pointer';
$axure.eventManager.click('u264', function(e) {

if (true) {

	SetPanelVisibility('u263','hidden','none',500);

	MoveWidgetBy('u295', GetNum('0'), GetNum('-150'),'none',500);

}
});
gv_vAlignTable['u203'] = 'top';gv_vAlignTable['u84'] = 'center';document.getElementById('u258_img').tabIndex = 0;

u258.style.cursor = 'pointer';
$axure.eventManager.click('u258', function(e) {

if (true) {

	SetPanelState('u247', 'pd1u247','none','',500,'none','',500);

}
});
u320.tabIndex = 0;

u320.style.cursor = 'pointer';
$axure.eventManager.click('u320', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u320'] = 'top';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u217'] = 'center';gv_vAlignTable['u195'] = 'top';gv_vAlignTable['u225'] = 'center';gv_vAlignTable['u41'] = 'center';