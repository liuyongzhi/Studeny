﻿for(var i = 0; i < 221; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

SetWidgetSelected('u32');
}

if ((GetGlobalVariableValue('ShoppingBasket')) == ('Empty')) {

	SetPanelState('u44', 'pd0u44','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('1'))) {

SetWidgetRichText('u46', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (1 item)</span></p>');

	SetPanelState('u44', 'pd1u44','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('2'))) {

SetWidgetRichText('u46', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (2 items)</span></p>');

	SetPanelState('u44', 'pd1u44','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('3'))) {

SetWidgetRichText('u46', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (3 items)</span></p>');

	SetPanelState('u44', 'pd1u44','none','',500,'none','',500);

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) {

}

});

function rdo0LoadHome(e) {

}
gv_vAlignTable['u122'] = 'center';gv_vAlignTable['u21'] = 'center';gv_vAlignTable['u132'] = 'center';document.getElementById('u32_img').tabIndex = 0;
HookHover('u32', false);

u32.style.cursor = 'pointer';
$axure.eventManager.click('u32', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
u207.tabIndex = 0;

u207.style.cursor = 'pointer';
$axure.eventManager.click('u207', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u207'] = 'top';gv_vAlignTable['u130'] = 'center';gv_vAlignTable['u7'] = 'center';document.getElementById('u2_img').tabIndex = 0;
HookHover('u2', false);

u2.style.cursor = 'pointer';
$axure.eventManager.click('u2', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u110'] = 'center';document.getElementById('u4_img').tabIndex = 0;
HookHover('u4', false);

u4.style.cursor = 'pointer';
$axure.eventManager.click('u4', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u140'] = 'center';gv_vAlignTable['u17'] = 'center';gv_vAlignTable['u212'] = 'top';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u55'] = 'top';u101.tabIndex = 0;

u101.style.cursor = 'pointer';
$axure.eventManager.click('u101', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u101'] = 'top';document.getElementById('u14_img').tabIndex = 0;
HookHover('u14', false);

u14.style.cursor = 'pointer';
$axure.eventManager.click('u14', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u105'] = 'top';gv_vAlignTable['u27'] = 'center';gv_vAlignTable['u138'] = 'center';gv_vAlignTable['u52'] = 'center';document.getElementById('u20_img').tabIndex = 0;
HookHover('u20', false);

u20.style.cursor = 'pointer';
$axure.eventManager.click('u20', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u65'] = 'top';gv_vAlignTable['u120'] = 'center';u189.tabIndex = 0;

u189.style.cursor = 'pointer';
$axure.eventManager.click('u189', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u189'] = 'top';document.getElementById('u24_img').tabIndex = 0;
HookHover('u24', false);

u24.style.cursor = 'pointer';
$axure.eventManager.click('u24', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
u205.tabIndex = 0;

u205.style.cursor = 'pointer';
$axure.eventManager.click('u205', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u205'] = 'top';gv_vAlignTable['u108'] = 'center';document.getElementById('u16_img').tabIndex = 0;
HookHover('u16', false);

u16.style.cursor = 'pointer';
$axure.eventManager.click('u16', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u37'] = 'center';gv_vAlignTable['u11'] = 'center';u200.tabIndex = 0;

u200.style.cursor = 'pointer';
$axure.eventManager.click('u200', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u200'] = 'top';document.getElementById('u34_img').tabIndex = 0;
HookHover('u34', false);

u34.style.cursor = 'pointer';
$axure.eventManager.click('u34', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u68'] = 'center';
$axure.eventManager.keyup('u89', function(e) {

if ((GetWidgetText('u89')) == ('')) {

	SetPanelVisibility('u59','hidden','none',500);

}
else
if (true) {

	SetPanelState('u59', 'pd0u59','none','',500,'none','',500);

SetGlobalVariableValue('IncrementalSearchVar', GetWidgetText('u89'));

SetWidgetRichText('u81', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dada</span></p>');

SetWidgetRichText('u82', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dat</span></p>');

SetWidgetRichText('u83', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">gi</span></p>');

SetWidgetRichText('u85', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

SetWidgetRichText('u65', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

	SetPanelVisibility('u59','','none',500);

	BringToFront("u59");
function waitu796b5745765043a58e9fe38835b455f51() {

	SetPanelState('u59', 'pd1u59','none','',500,'none','',500);
}
setTimeout(waitu796b5745765043a58e9fe38835b455f51, 2000);

}
});

$axure.eventManager.blur('u89', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u89'));

}
});
gv_vAlignTable['u208'] = 'top';document.getElementById('u47_img').tabIndex = 0;

u47.style.cursor = 'pointer';
$axure.eventManager.click('u47', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}

if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('OnLoadVariable')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
u213.tabIndex = 0;

u213.style.cursor = 'pointer';
$axure.eventManager.click('u213', function(e) {

if (true) {

	self.location.href='http://www.lucabenazzi.eu';

}
});
u184.tabIndex = 0;

u184.style.cursor = 'pointer';
$axure.eventManager.click('u184', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u184'] = 'top';u103.tabIndex = 0;

u103.style.cursor = 'pointer';
$axure.eventManager.click('u103', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u103'] = 'top';u99.tabIndex = 0;

u99.style.cursor = 'pointer';
$axure.eventManager.click('u99', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('My_details.html');

}
else
if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('LoginStatus')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u99'] = 'top';u66.tabIndex = 0;

u66.style.cursor = 'pointer';
$axure.eventManager.click('u66', function(e) {

if (true) {

	SetPanelVisibility('u59','hidden','none',500);

}
});

$axure.eventManager.mouseover('u66', function(e) {
if (!IsTrueMouseOver('u66',e)) return;
if (true) {

	SetPanelVisibility('u62','','none',500);

}
});

$axure.eventManager.mouseout('u66', function(e) {
if (!IsTrueMouseOut('u66',e)) return;
if (true) {

	SetPanelVisibility('u62','hidden','none',500);

}
});
gv_vAlignTable['u112'] = 'center';document.getElementById('u179_img').tabIndex = 0;

u179.style.cursor = 'pointer';
$axure.eventManager.click('u179', function(e) {

if (true) {

SetGlobalVariableValue('ReviewVar', GetWidgetText('u178'));

	SetPanelState('u172', 'pd1u172','none','',500,'none','',500);
function waitu3ec08b90531c441b98c47559d167c3331() {

	SetPanelState('u172', 'pd2u172','none','',500,'none','',500);

SetWidgetRichText('u173', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Your review:</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;text-decoration:none;">&nbsp;</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">&quot;' + (GetGlobalVariableValue('ReviewVar')) + '&quot;</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;text-decoration:none;">&nbsp;</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">This review will be published in the next 24 hours, thank you</span></p>');
}
setTimeout(waitu3ec08b90531c441b98c47559d167c3331, 1000);

}
});
document.getElementById('u57_img').tabIndex = 0;

u57.style.cursor = 'pointer';
$axure.eventManager.click('u57', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u89'));

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Search_results.html');

}
});
u191.tabIndex = 0;

u191.style.cursor = 'pointer';
$axure.eventManager.click('u191', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u191'] = 'top';u203.tabIndex = 0;

u203.style.cursor = 'pointer';
$axure.eventManager.click('u203', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u203'] = 'top';document.getElementById('u6_img').tabIndex = 0;
HookHover('u6', false);

u6.style.cursor = 'pointer';
$axure.eventManager.click('u6', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
u168.tabIndex = 0;

u168.style.cursor = 'pointer';
$axure.eventManager.click('u168', function(e) {

if (true) {

	SetPanelState('u106', 'pd4u106','none','',500,'none','',500);

}
});

$axure.eventManager.mouseover('u168', function(e) {
if (!IsTrueMouseOver('u168',e)) return;
if (true) {

                                DisableImageWidget('u157');
                                DisableImageWidget('u159');
                                DisableImageWidget('u161');
                                DisableImageWidget('u163');
}
});

$axure.eventManager.mouseout('u168', function(e) {
if (!IsTrueMouseOut('u168',e)) return;
if (true) {

                                EnableImageWidget('u157');
                                EnableImageWidget('u159');
                                EnableImageWidget('u161');
                                EnableImageWidget('u163');
}
});
gv_vAlignTable['u158'] = 'center';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u118'] = 'center';u197.tabIndex = 0;

u197.style.cursor = 'pointer';
$axure.eventManager.click('u197', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u197'] = 'top';u88.tabIndex = 0;

u88.style.cursor = 'pointer';
$axure.eventManager.click('u88', function(e) {

if (true) {

	SetPanelVisibility('u59','hidden','none',500);

}
});

$axure.eventManager.mouseover('u88', function(e) {
if (!IsTrueMouseOver('u88',e)) return;
if (true) {

	SetPanelVisibility('u78','','none',500);

}
});

$axure.eventManager.mouseout('u88', function(e) {
if (!IsTrueMouseOut('u88',e)) return;
if (true) {

	SetPanelVisibility('u78','hidden','none',500);

}
});
document.getElementById('u26_img').tabIndex = 0;
HookHover('u26', false);

u26.style.cursor = 'pointer';
$axure.eventManager.click('u26', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u216'] = 'center';gv_vAlignTable['u128'] = 'center';gv_vAlignTable['u85'] = 'top';u182.tabIndex = 0;

u182.style.cursor = 'pointer';
$axure.eventManager.click('u182', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Book_page.html');

}
});
gv_vAlignTable['u182'] = 'top';document.getElementById('u10_img').tabIndex = 0;
HookHover('u10', false);

u10.style.cursor = 'pointer';
$axure.eventManager.click('u10', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u77'] = 'center';gv_vAlignTable['u144'] = 'center';gv_vAlignTable['u31'] = 'center';gv_vAlignTable['u82'] = 'top';document.getElementById('u36_img').tabIndex = 0;
HookHover('u36', false);

u36.style.cursor = 'pointer';
$axure.eventManager.click('u36', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
document.getElementById('u30_img').tabIndex = 0;
HookHover('u30', false);

u30.style.cursor = 'pointer';
$axure.eventManager.click('u30', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u219'] = 'center';gv_vAlignTable['u95'] = 'center';gv_vAlignTable['u61'] = 'center';u195.tabIndex = 0;

u195.style.cursor = 'pointer';
$axure.eventManager.click('u195', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u195'] = 'top';gv_vAlignTable['u116'] = 'center';gv_vAlignTable['u74'] = 'center';gv_vAlignTable['u114'] = 'center';gv_vAlignTable['u33'] = 'center';gv_vAlignTable['u160'] = 'center';gv_vAlignTable['u166'] = 'center';u92.tabIndex = 0;

u92.style.cursor = 'pointer';
$axure.eventManager.click('u92', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');
function waitud60c4460105243299b524b0b32b428cf1() {

	SetPanelState('u91', 'pd1u91','none','',500,'none','',500);
function waitub3ccdb0e2b0e45289ccb18b7f7d0de481() {
function waitu7d17a4dc47ea4dd0b7636d8a947ae1e31() {
}
setTimeout(waitu7d17a4dc47ea4dd0b7636d8a947ae1e31, 200);
}
setTimeout(waitub3ccdb0e2b0e45289ccb18b7f7d0de481, 200);
}
setTimeout(waitud60c4460105243299b524b0b32b428cf1, 300);

}
});
gv_vAlignTable['u92'] = 'top';gv_vAlignTable['u46'] = 'center';u202.tabIndex = 0;

u202.style.cursor = 'pointer';
$axure.eventManager.click('u202', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u202'] = 'top';gv_vAlignTable['u126'] = 'center';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u181'] = 'top';u198.tabIndex = 0;

u198.style.cursor = 'pointer';
$axure.eventManager.click('u198', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u198'] = 'top';gv_vAlignTable['u5'] = 'center';u98.tabIndex = 0;

u98.style.cursor = 'pointer';
$axure.eventManager.click('u98', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
u169.tabIndex = 0;

u169.style.cursor = 'pointer';
$axure.eventManager.click('u169', function(e) {

if (true) {

	SetPanelState('u106', 'pd3u106','none','',500,'none','',500);

}
});

$axure.eventManager.mouseover('u169', function(e) {
if (!IsTrueMouseOver('u169',e)) return;
if (true) {

                                DisableImageWidget('u157');
                                DisableImageWidget('u159');
                                DisableImageWidget('u161');
}
});

$axure.eventManager.mouseout('u169', function(e) {
if (!IsTrueMouseOut('u169',e)) return;
if (true) {

                                EnableImageWidget('u157');
                                EnableImageWidget('u159');
                                EnableImageWidget('u161');
}
});
gv_vAlignTable['u56'] = 'top';gv_vAlignTable['u154'] = 'center';u87.tabIndex = 0;

u87.style.cursor = 'pointer';
$axure.eventManager.click('u87', function(e) {

if (true) {

	SetPanelVisibility('u59','hidden','none',500);

}
});

$axure.eventManager.mouseover('u87', function(e) {
if (!IsTrueMouseOver('u87',e)) return;
if (true) {

	SetPanelVisibility('u75','','none',500);

}
});

$axure.eventManager.mouseout('u87', function(e) {
if (!IsTrueMouseOut('u87',e)) return;
if (true) {

	SetPanelVisibility('u75','hidden','none',500);

}
});
u193.tabIndex = 0;

u193.style.cursor = 'pointer';
$axure.eventManager.click('u193', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u193'] = 'top';u192.tabIndex = 0;

u192.style.cursor = 'pointer';
$axure.eventManager.click('u192', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u192'] = 'top';gv_vAlignTable['u150'] = 'center';gv_vAlignTable['u211'] = 'top';u102.tabIndex = 0;

u102.style.cursor = 'pointer';
$axure.eventManager.click('u102', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u164'] = 'center';u206.tabIndex = 0;

u206.style.cursor = 'pointer';
$axure.eventManager.click('u206', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u206'] = 'top';u84.tabIndex = 0;

u84.style.cursor = 'pointer';
$axure.eventManager.click('u84', function(e) {

if (true) {

	SetPanelVisibility('u59','hidden','none',500);

}
});

$axure.eventManager.mouseover('u84', function(e) {
if (!IsTrueMouseOver('u84',e)) return;
if (true) {

	SetPanelVisibility('u69','','none',500);

}
});

$axure.eventManager.mouseout('u84', function(e) {
if (!IsTrueMouseOut('u84',e)) return;
if (true) {

	SetPanelVisibility('u69','hidden','none',500);

}
});
gv_vAlignTable['u50'] = 'center';gv_vAlignTable['u97'] = 'center';u170.tabIndex = 0;

u170.style.cursor = 'pointer';
$axure.eventManager.click('u170', function(e) {

if (true) {

	SetPanelState('u106', 'pd2u106','none','',500,'none','',500);

}
});

$axure.eventManager.mouseover('u170', function(e) {
if (!IsTrueMouseOver('u170',e)) return;
if (true) {

                                DisableImageWidget('u157');
                                DisableImageWidget('u159');
}
});

$axure.eventManager.mouseout('u170', function(e) {
if (!IsTrueMouseOut('u170',e)) return;
if (true) {

                                EnableImageWidget('u157');
                                EnableImageWidget('u159');
}
});
gv_vAlignTable['u134'] = 'center';gv_vAlignTable['u81'] = 'top';document.getElementById('u41_img').tabIndex = 0;

u41.style.cursor = 'pointer';
$axure.eventManager.click('u41', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u177'] = 'center';document.getElementById('u94_img').tabIndex = 0;

u94.style.cursor = 'pointer';
$axure.eventManager.click('u94', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
u190.tabIndex = 0;

u190.style.cursor = 'pointer';
$axure.eventManager.click('u190', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u190'] = 'top';gv_vAlignTable['u185'] = 'top';gv_vAlignTable['u9'] = 'center';gv_vAlignTable['u104'] = 'top';gv_vAlignTable['u19'] = 'center';gv_vAlignTable['u64'] = 'center';gv_vAlignTable['u188'] = 'center';gv_vAlignTable['u162'] = 'center';u204.tabIndex = 0;

u204.style.cursor = 'pointer';
$axure.eventManager.click('u204', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u204'] = 'top';gv_vAlignTable['u156'] = 'center';gv_vAlignTable['u210'] = 'top';gv_vAlignTable['u13'] = 'center';gv_vAlignTable['u29'] = 'center';gv_vAlignTable['u148'] = 'center';gv_vAlignTable['u175'] = 'center';gv_vAlignTable['u58'] = 'center';gv_vAlignTable['u183'] = 'top';u86.tabIndex = 0;

u86.style.cursor = 'pointer';
$axure.eventManager.click('u86', function(e) {

if (true) {

	SetPanelVisibility('u59','hidden','none',500);

}
});

$axure.eventManager.mouseover('u86', function(e) {
if (!IsTrueMouseOver('u86',e)) return;
if (true) {

	SetPanelVisibility('u72','','none',500);

}
});

$axure.eventManager.mouseout('u86', function(e) {
if (!IsTrueMouseOut('u86',e)) return;
if (true) {

	SetPanelVisibility('u72','hidden','none',500);

}
});
gv_vAlignTable['u173'] = 'top';gv_vAlignTable['u39'] = 'center';u171.tabIndex = 0;

u171.style.cursor = 'pointer';
$axure.eventManager.click('u171', function(e) {

if (true) {

	SetPanelState('u106', 'pd1u106','none','',500,'none','',500);

}
});

$axure.eventManager.mouseover('u171', function(e) {
if (!IsTrueMouseOver('u171',e)) return;
if (true) {

                                DisableImageWidget('u157');
}
});

$axure.eventManager.mouseout('u171', function(e) {
if (!IsTrueMouseOut('u171',e)) return;
if (true) {

                                EnableImageWidget('u157');
}
});
gv_vAlignTable['u83'] = 'top';document.getElementById('u8_img').tabIndex = 0;
HookHover('u8', false);

u8.style.cursor = 'pointer';
$axure.eventManager.click('u8', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u3'] = 'center';HookHover('u96', false);
gv_vAlignTable['u146'] = 'center';u196.tabIndex = 0;

u196.style.cursor = 'pointer';
$axure.eventManager.click('u196', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
gv_vAlignTable['u196'] = 'top';gv_vAlignTable['u15'] = 'center';gv_vAlignTable['u124'] = 'center';gv_vAlignTable['u80'] = 'center';gv_vAlignTable['u1'] = 'center';u167.tabIndex = 0;

u167.style.cursor = 'pointer';
$axure.eventManager.click('u167', function(e) {

if (true) {

	SetPanelState('u106', 'pd5u106','none','',500,'none','',500);

}
});

$axure.eventManager.mouseover('u167', function(e) {
if (!IsTrueMouseOver('u167',e)) return;
if (true) {

                                DisableImageWidget('u157');
                                DisableImageWidget('u159');
                                DisableImageWidget('u161');
                                DisableImageWidget('u163');
                                DisableImageWidget('u165');
}
});

$axure.eventManager.mouseout('u167', function(e) {
if (!IsTrueMouseOut('u167',e)) return;
if (true) {

                                EnableImageWidget('u157');
                                EnableImageWidget('u159');
                                EnableImageWidget('u161');
                                EnableImageWidget('u163');
                                EnableImageWidget('u165');
}
});
gv_vAlignTable['u142'] = 'center';u93.tabIndex = 0;

u93.style.cursor = 'pointer';
$axure.eventManager.click('u93', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');

SetGlobalVariableValue('BookPageViewed', '');

SetGlobalVariableValue('CitySelected', '');

SetGlobalVariableValue('LoginStatus', '');

SetGlobalVariableValue('ReviewVar', '');

SetGlobalVariableValue('EmployeesName', '');

	SetPanelState('u91', 'pd1u91','none','',500,'none','',500);
function waituf022ddcb6b474903a282219d39d908ef1() {

	SetPanelState('u91', 'pd0u91','none','',500,'none','',500);
}
setTimeout(waituf022ddcb6b474903a282219d39d908ef1, 4000);

}
});
gv_vAlignTable['u93'] = 'top';gv_vAlignTable['u23'] = 'center';HookHover('u12', false);
u201.tabIndex = 0;

u201.style.cursor = 'pointer';
$axure.eventManager.click('u201', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Employees_directory.html');

}
});
gv_vAlignTable['u201'] = 'top';u199.tabIndex = 0;

u199.style.cursor = 'pointer';
$axure.eventManager.click('u199', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u199'] = 'top';gv_vAlignTable['u25'] = 'center';document.getElementById('u215_img').tabIndex = 0;

u215.style.cursor = 'pointer';
$axure.eventManager.click('u215', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
u90.tabIndex = 0;

u90.style.cursor = 'pointer';
$axure.eventManager.click('u90', function(e) {

if (true) {

	self.location.href='index.html';

}
});
gv_vAlignTable['u90'] = 'top';document.getElementById('u18_img').tabIndex = 0;
HookHover('u18', false);

u18.style.cursor = 'pointer';
$axure.eventManager.click('u18', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u136'] = 'center';document.getElementById('u45_img').tabIndex = 0;

u45.style.cursor = 'pointer';
$axure.eventManager.click('u45', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}
});
document.getElementById('u22_img').tabIndex = 0;
HookHover('u22', false);

u22.style.cursor = 'pointer';
$axure.eventManager.click('u22', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u152'] = 'center';gv_vAlignTable['u35'] = 'center';gv_vAlignTable['u180'] = 'center';document.getElementById('u28_img').tabIndex = 0;
HookHover('u28', false);

u28.style.cursor = 'pointer';
$axure.eventManager.click('u28', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
u194.tabIndex = 0;

u194.style.cursor = 'pointer';
$axure.eventManager.click('u194', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u194'] = 'top';