﻿for(var i = 0; i < 390; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

if (true) {

SetWidgetSelected('u25');
	var obj1 = document.getElementById("u283");
    obj1.focus();

}

if ((GetGlobalVariableValue('ShoppingBasket')) == ('Empty')) {

	SetPanelState('u61', 'pd0u61','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('1'))) {

SetWidgetRichText('u63', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (1 item)</span></p>');

	SetPanelState('u61', 'pd1u61','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('2'))) {

SetWidgetRichText('u63', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (2 items)</span></p>');

	SetPanelState('u61', 'pd1u61','none','',500,'none','',500);

}

if (((GetGlobalVariableValue('ShoppingBasket')) == ('Full')) && ((GetGlobalVariableValue('BookQuantity')) == ('3'))) {

SetWidgetRichText('u63', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#0000CC;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Shopping basket</span><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#0000CC;"> (3 items)</span></p>');

	SetPanelState('u61', 'pd1u61','none','',500,'none','',500);

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

}

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) {

}

});

function rdo2ClosePanel(e) {

if (true) {

	SetPanelVisibility('u261','hidden','none',500);

}

}

function rdo4ClosePanel(e) {

if (true) {

	SetPanelVisibility('u142','hidden','none',500);

}

}

function rdo1ClosePanel(e) {

if (true) {

	SetPanelVisibility('u240','hidden','none',500);

}

}

function rdo3ClosePanel(e) {

if (true) {

	SetPanelVisibility('u121','hidden','none',500);

}

}

function rdo5ClosePanel(e) {

if (true) {

	SetPanelVisibility('u163','hidden','none',500);

}

}

function rdo0LoadHome(e) {

}
u370.tabIndex = 0;

u370.style.cursor = 'pointer';
$axure.eventManager.click('u370', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u370'] = 'top';gv_vAlignTable['u299'] = 'center';gv_vAlignTable['u36'] = 'center';gv_vAlignTable['u180'] = 'center';document.getElementById('u216_img').tabIndex = 0;

u216.style.cursor = 'pointer';
$axure.eventManager.click('u216', function(e) {

if (true) {

}
});
gv_vAlignTable['u72'] = 'top';gv_vAlignTable['u97'] = 'center';gv_vAlignTable['u231'] = 'top';gv_vAlignTable['u78'] = 'center';gv_vAlignTable['u166'] = 'top';gv_vAlignTable['u54'] = 'center';gv_vAlignTable['u201'] = 'top';gv_vAlignTable['u1'] = 'center';gv_vAlignTable['u215'] = 'center';gv_vAlignTable['u193'] = 'center';gv_vAlignTable['u126'] = 'center';gv_vAlignTable['u332'] = 'center';gv_vAlignTable['u151'] = 'top';gv_vAlignTable['u71'] = 'center';gv_vAlignTable['u202'] = 'top';gv_vAlignTable['u26'] = 'center';gv_vAlignTable['u389'] = 'top';gv_vAlignTable['u165'] = 'center';u378.tabIndex = 0;

u378.style.cursor = 'pointer';
$axure.eventManager.click('u378', function(e) {

if (true) {

	self.location.href='http://www.lucabenazzi.eu';

}
});
gv_vAlignTable['u138'] = 'center';gv_vAlignTable['u100'] = 'top';u236.tabIndex = 0;

u236.style.cursor = 'pointer';
$axure.eventManager.click('u236', function(e) {

if (true) {

	SetPanelVisibility('u240','toggle','none',500);

	BringToFront("u240");

}
});
document.getElementById('u214_img').tabIndex = 0;

u214.style.cursor = 'pointer';
$axure.eventManager.click('u214', function(e) {

if (true) {

}
});
gv_vAlignTable['u67'] = 'center';gv_vAlignTable['u269'] = 'top';gv_vAlignTable['u150'] = 'top';
u287.style.cursor = 'pointer';
$axure.eventManager.click('u287', function(e) {

if (((GetCheckState('u287')) == (true)) && (((GetWidgetText('u283')) != (' ')) && ((GetPanelState('u293')) == ('pd0u293')))) {

	SetPanelState('u2', 'pd0u2','none','',500,'none','',500);

}

if (((GetCheckState('u287')) == (true)) && (((GetWidgetText('u283')) != (' ')) && ((GetPanelState('u293')) == ('pd1u293')))) {

	SetPanelState('u2', 'pd1u2','none','',500,'none','',500);

}
else
if ((GetCheckState('u287')) != (true)) {

	SetPanelVisibility('u2','hidden','none',500);

}
});
gv_vAlignTable['u48'] = 'center';gv_vAlignTable['u340'] = 'center';gv_vAlignTable['u24'] = 'center';gv_vAlignTable['u65'] = 'center';u365.tabIndex = 0;

u365.style.cursor = 'pointer';
$axure.eventManager.click('u365', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u365'] = 'top';HookHover('u113', false);
gv_vAlignTable['u268'] = 'top';gv_vAlignTable['u330'] = 'center';gv_vAlignTable['u227'] = 'center';gv_vAlignTable['u42'] = 'center';gv_vAlignTable['u159'] = 'center';gv_vAlignTable['u63'] = 'center';gv_vAlignTable['u32'] = 'center';u177.tabIndex = 0;

u177.style.cursor = 'pointer';
$axure.eventManager.click('u177', function(e) {

if (true) {

rdo5ClosePanel(e);

}
});
document.getElementById('u37_img').tabIndex = 0;
HookHover('u37', false);

u37.style.cursor = 'pointer';
$axure.eventManager.click('u37', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u112'] = 'center';gv_vAlignTable['u307'] = 'center';u285.tabIndex = 0;

u285.style.cursor = 'pointer';
$axure.eventManager.click('u285', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u285'] = 'top';gv_vAlignTable['u18'] = 'center';gv_vAlignTable['u50'] = 'center';document.getElementById('u74_img').tabIndex = 0;

u74.style.cursor = 'pointer';
$axure.eventManager.click('u74', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u106'));

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Search_results.html');

}
});

$axure.eventManager.click('u162', function(e) {

if (true) {

	SetPanelVisibility('u142','hidden','none',500);

}
});
u357.tabIndex = 0;

u357.style.cursor = 'pointer';
$axure.eventManager.click('u357', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
gv_vAlignTable['u357'] = 'top';gv_vAlignTable['u176'] = 'center';gv_vAlignTable['u149'] = 'top';document.getElementById('u111_img').tabIndex = 0;

u111.style.cursor = 'pointer';
$axure.eventManager.click('u111', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u284'] = 'top';gv_vAlignTable['u12'] = 'center';gv_vAlignTable['u342'] = 'center';gv_vAlignTable['u161'] = 'center';u356.tabIndex = 0;

u356.style.cursor = 'pointer';
$axure.eventManager.click('u356', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u356'] = 'top';gv_vAlignTable['u229'] = 'center';gv_vAlignTable['u148'] = 'top';u110.tabIndex = 0;

u110.style.cursor = 'pointer';
$axure.eventManager.click('u110', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');

SetGlobalVariableValue('BookPageViewed', '');

SetGlobalVariableValue('CitySelected', '');

SetGlobalVariableValue('LoginStatus', '');

SetGlobalVariableValue('ReviewVar', '');

SetGlobalVariableValue('EmployeesName', '');

	SetPanelState('u108', 'pd1u108','none','',500,'none','',500);
function waituf022ddcb6b474903a282219d39d908ef1() {

	SetPanelState('u108', 'pd0u108','none','',500,'none','',500);
}
setTimeout(waituf022ddcb6b474903a282219d39d908ef1, 4000);

}
});
gv_vAlignTable['u110'] = 'top';gv_vAlignTable['u305'] = 'center';
$axure.eventManager.keyup('u283', function(e) {

if ((GetWidgetText('u283')) == (' ')) {

SetCheckState('u287', false);

	SetPanelVisibility('u2','hidden','none',500);

	SetPanelVisibility('u120','hidden','none',500);

	var obj1 = document.getElementById("u287");
    obj1.disabled = true;

}
else
if (((GetWidgetText('u283')) != (' ')) && ((GetPanelState('u293')) == ('pd0u293'))) {

SetGlobalVariableValue('EmployeesName', GetWidgetText('u283'));

SetWidgetRichText('u220', '<p style="text-align:center;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">John ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Head of lorem ipsum</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5667</span></p>');

SetWidgetRichText('u221', '<p style="text-align:center;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Laura ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Junior lorem ipsum</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 4567</span></p>');

SetWidgetRichText('u222', '<p style="text-align:center;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Marie ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Head of lorem ipsum</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5467</span></p>');

SetWidgetRichText('u223', '<p style="text-align:center;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Freddie ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Lorem ipsum developer</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5367</span></p>');

SetWidgetRichText('u230', '<p style="text-align:center;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">John ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Senior lorem ipsum</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5667</span></p>');

SetWidgetRichText('u231', '<p style="text-align:center;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Laura ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Account manager </span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 4567</span></p>');

SetWidgetRichText('u232', '<p style="text-align:center;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Marie ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Lorem ipsum director</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5467</span></p>');

SetWidgetRichText('u198', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">John ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Head of lorem ipsum</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5667</span></p>');

SetWidgetRichText('u204', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Marie ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Lorem ipsum director</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5467</span></p>');

SetWidgetRichText('u202', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">John ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Senior lorem ipsum</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5667</span></p>');

SetWidgetRichText('u199', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Laura ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Junior lorem ipsum</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 4567</span></p>');

SetWidgetRichText('u201', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Freddie ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Ipsum manager</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5367</span></p>');

SetWidgetRichText('u203', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Laura ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Account manager</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 4567</span></p>');

SetWidgetRichText('u200', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Marie ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Head of lorem ipsum</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5467</span></p>');

	SetPanelState('u120', 'pd0u120','none','',500,'none','',500);

	SetPanelVisibility('u120','','none',500);

	var obj1 = document.getElementById("u287");
    obj1.disabled = false;

}
else
if (((GetWidgetText('u283')) != (' ')) && ((GetPanelState('u293')) == ('pd1u293'))) {

SetGlobalVariableValue('EmployeesName', GetWidgetText('u283'));

SetWidgetRichText('u220', '<p style="text-align:center;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">John ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Head of lorem ipsum</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5667</span></p>');

SetWidgetRichText('u221', '<p style="text-align:center;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Laura ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Junior lorem ipsum</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 4567</span></p>');

SetWidgetRichText('u222', '<p style="text-align:center;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Marie ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Head of lorem ipsum</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5467</span></p>');

SetWidgetRichText('u223', '<p style="text-align:center;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Freddie ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Lorem ipsum developer</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5367</span></p>');

SetWidgetRichText('u230', '<p style="text-align:center;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">John ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Senior lorem ipsum</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5667</span></p>');

SetWidgetRichText('u231', '<p style="text-align:center;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Laura ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Account manager </span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 4567</span></p>');

SetWidgetRichText('u232', '<p style="text-align:center;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Marie ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Lorem ipsum director</span></p><p style="text-align:center;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5467</span></p>');

SetWidgetRichText('u198', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">John ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Head of lorem ipsum</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5667</span></p>');

SetWidgetRichText('u204', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Marie ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Lorem ipsum director</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5467</span></p>');

SetWidgetRichText('u202', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">John ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Senior lorem ipsum</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5667</span></p>');

SetWidgetRichText('u199', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Laura ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Junior lorem ipsum</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 4567</span></p>');

SetWidgetRichText('u201', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Freddie ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Ipsum manager</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5367</span></p>');

SetWidgetRichText('u203', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Laura ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Account manager</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 4567</span></p>');

SetWidgetRichText('u200', '<p style="text-align:left;"><span style="font-family:Verdana;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Marie ' + (GetGlobalVariableValue('EmployeesName')) + '</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">Head of lorem ipsum</span></p><p style="text-align:left;"><span style="font-family:Verdana;font-size:12px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">Int.: 5467</span></p>');

	SetPanelState('u120', 'pd1u120','none','',500,'none','',500);

	SetPanelVisibility('u120','','none',500);

	var obj1 = document.getElementById("u287");
    obj1.disabled = false;

}
});
gv_vAlignTable['u20'] = 'center';gv_vAlignTable['u124'] = 'top';gv_vAlignTable['u38'] = 'center';gv_vAlignTable['u297'] = 'center';gv_vAlignTable['u8'] = 'center';document.getElementById('u49_img').tabIndex = 0;
HookHover('u49', false);

u49.style.cursor = 'pointer';
$axure.eventManager.click('u49', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
u355.tabIndex = 0;

u355.style.cursor = 'pointer';
$axure.eventManager.click('u355', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u355'] = 'top';document.getElementById('u25_img').tabIndex = 0;
HookHover('u25', false);

u25.style.cursor = 'pointer';
$axure.eventManager.click('u25', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u81'] = 'center';document.getElementById('u228_img').tabIndex = 0;

u228.style.cursor = 'pointer';
$axure.eventManager.click('u228', function(e) {

if (true) {

}
});
gv_vAlignTable['u88'] = 'center';gv_vAlignTable['u282'] = 'top';gv_vAlignTable['u123'] = 'center';gv_vAlignTable['u278'] = 'center';document.getElementById('u33_img').tabIndex = 0;
HookHover('u33', false);

u33.style.cursor = 'pointer';
$axure.eventManager.click('u33', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
u254.tabIndex = 0;

u254.style.cursor = 'pointer';
$axure.eventManager.click('u254', function(e) {

if (true) {

rdo1ClosePanel(e);

}
});
gv_vAlignTable['u99'] = 'top';gv_vAlignTable['u303'] = 'center';
$axure.eventManager.click('u281', function(e) {

if (true) {

	SetPanelVisibility('u261','hidden','none',500);

}
});
gv_vAlignTable['u94'] = 'center';u358.tabIndex = 0;

u358.style.cursor = 'pointer';
$axure.eventManager.click('u358', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u358'] = 'top';gv_vAlignTable['u295'] = 'center';u136.tabIndex = 0;

u136.style.cursor = 'pointer';
$axure.eventManager.click('u136', function(e) {

if (true) {

rdo3ClosePanel(e);

}
});
document.getElementById('u51_img').tabIndex = 0;
HookHover('u51', false);

u51.style.cursor = 'pointer';
$axure.eventManager.click('u51', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Publications.html');

}
});
u109.tabIndex = 0;

u109.style.cursor = 'pointer';
$axure.eventManager.click('u109', function(e) {

if (true) {

SetGlobalVariableValue('SelectedTag', '');

SetGlobalVariableValue('AlbumNo', '');

SetGlobalVariableValue('BookQuantity', '1');

SetGlobalVariableValue('ShoppingBasket', 'Empty');

SetGlobalVariableValue('SearchVar', '');

SetGlobalVariableValue('IncrementalSearchVar', '');
function waitud60c4460105243299b524b0b32b428cf1() {

	SetPanelState('u108', 'pd1u108','none','',500,'none','',500);
function waitub3ccdb0e2b0e45289ccb18b7f7d0de481() {
function waitu7d17a4dc47ea4dd0b7636d8a947ae1e31() {
}
setTimeout(waitu7d17a4dc47ea4dd0b7636d8a947ae1e31, 200);
}
setTimeout(waitub3ccdb0e2b0e45289ccb18b7f7d0de481, 200);
}
setTimeout(waitud60c4460105243299b524b0b32b428cf1, 300);

}
});
gv_vAlignTable['u109'] = 'top';gv_vAlignTable['u253'] = 'center';gv_vAlignTable['u172'] = 'top';u359.tabIndex = 0;

u359.style.cursor = 'pointer';
$axure.eventManager.click('u359', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
gv_vAlignTable['u359'] = 'top';gv_vAlignTable['u267'] = 'top';gv_vAlignTable['u46'] = 'center';gv_vAlignTable['u280'] = 'center';u135.tabIndex = 0;

u135.style.cursor = 'pointer';
$axure.eventManager.click('u135', function(e) {

if (true) {

rdo3ClosePanel(e);

}
});
gv_vAlignTable['u171'] = 'top';u386.tabIndex = 0;

u386.style.cursor = 'pointer';
$axure.eventManager.click('u386', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Books_catalogue.html');

}
});
gv_vAlignTable['u386'] = 'top';gv_vAlignTable['u266'] = 'center';document.getElementById('u64_img').tabIndex = 0;

u64.style.cursor = 'pointer';
$axure.eventManager.click('u64', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}

if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('OnLoadVariable')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
u239.tabIndex = 0;

u239.style.cursor = 'pointer';
$axure.eventManager.click('u239', function(e) {

if (true) {

	SetPanelVisibility('u261','toggle','none',500);

	BringToFront("u261");

}
});
gv_vAlignTable['u301'] = 'center';document.getElementById('u21_img').tabIndex = 0;
HookHover('u21', false);

u21.style.cursor = 'pointer';
$axure.eventManager.click('u21', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u134'] = 'center';gv_vAlignTable['u251'] = 'center';gv_vAlignTable['u170'] = 'top';gv_vAlignTable['u373'] = 'top';gv_vAlignTable['u82'] = 'top';gv_vAlignTable['u16'] = 'center';u238.tabIndex = 0;

u238.style.cursor = 'pointer';
$axure.eventManager.click('u238', function(e) {

if (true) {

	SetPanelVisibility('u261','toggle','none',500);

	BringToFront("u261");

}
});
gv_vAlignTable['u200'] = 'top';gv_vAlignTable['u292'] = 'center';u369.tabIndex = 0;

u369.style.cursor = 'pointer';
$axure.eventManager.click('u369', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u369'] = 'top';gv_vAlignTable['u147'] = 'center';document.getElementById('u58_img').tabIndex = 0;

u58.style.cursor = 'pointer';
$axure.eventManager.click('u58', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u34'] = 'center';gv_vAlignTable['u213'] = 'center';gv_vAlignTable['u191'] = 'center';u368.tabIndex = 0;

u368.style.cursor = 'pointer';
$axure.eventManager.click('u368', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
gv_vAlignTable['u368'] = 'top';gv_vAlignTable['u52'] = 'center';gv_vAlignTable['u263'] = 'center';gv_vAlignTable['u91'] = 'center';gv_vAlignTable['u388'] = 'center';document.getElementById('u47_img').tabIndex = 0;
HookHover('u47', false);

u47.style.cursor = 'pointer';
$axure.eventManager.click('u47', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Our_sketchbook.html');

}
});
gv_vAlignTable['u28'] = 'center';gv_vAlignTable['u145'] = 'top';gv_vAlignTable['u118'] = 'top';gv_vAlignTable['u322'] = 'center';u276.tabIndex = 0;

u276.style.cursor = 'pointer';
$axure.eventManager.click('u276', function(e) {

if (true) {

rdo2ClosePanel(e);

}
});
gv_vAlignTable['u249'] = 'top';u211.tabIndex = 0;

u211.style.cursor = 'pointer';
$axure.eventManager.click('u211', function(e) {

if (true) {

	SetPanelVisibility('u121','toggle','none',500);

	BringToFront("u121");

}
});
gv_vAlignTable['u130'] = 'top';gv_vAlignTable['u85'] = 'center';document.getElementById('u39_img').tabIndex = 0;
HookHover('u39', false);

u39.style.cursor = 'pointer';
$axure.eventManager.click('u39', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u384'] = 'center';gv_vAlignTable['u22'] = 'center';gv_vAlignTable['u144'] = 'center';document.getElementById('u43_img').tabIndex = 0;
HookHover('u43', false);

u43.style.cursor = 'pointer';
$axure.eventManager.click('u43', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Computers.html');

}
});
u275.tabIndex = 0;

u275.style.cursor = 'pointer';
$axure.eventManager.click('u275', function(e) {

if (true) {

rdo2ClosePanel(e);

}
});
gv_vAlignTable['u248'] = 'top';u210.tabIndex = 0;

u210.style.cursor = 'pointer';
$axure.eventManager.click('u210', function(e) {

if (true) {

	SetPanelVisibility('u142','toggle','none',500);

	BringToFront("u142");

}
});
u107.tabIndex = 0;

u107.style.cursor = 'pointer';
$axure.eventManager.click('u107', function(e) {

if (true) {

	self.location.href='index.html';

}
});
gv_vAlignTable['u107'] = 'top';gv_vAlignTable['u44'] = 'center';gv_vAlignTable['u30'] = 'center';document.getElementById('u224_img').tabIndex = 0;

u224.style.cursor = 'pointer';
$axure.eventManager.click('u224', function(e) {

if (true) {

}
});

$axure.eventManager.click('u260', function(e) {

if (true) {

	SetPanelVisibility('u240','hidden','none',500);

}
});
u157.tabIndex = 0;

u157.style.cursor = 'pointer';
$axure.eventManager.click('u157', function(e) {

if (true) {

rdo4ClosePanel(e);

}
});
gv_vAlignTable['u59'] = 'center';gv_vAlignTable['u189'] = 'center';document.getElementById('u35_img').tabIndex = 0;
HookHover('u35', false);

u35.style.cursor = 'pointer';
$axure.eventManager.click('u35', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u274'] = 'center';gv_vAlignTable['u309'] = 'center';gv_vAlignTable['u328'] = 'center';
$axure.eventManager.keyup('u106', function(e) {

if ((GetWidgetText('u106')) == ('')) {

	SetPanelVisibility('u76','hidden','none',500);

}
else
if (true) {

	SetPanelState('u76', 'pd0u76','none','',500,'none','',500);

SetGlobalVariableValue('IncrementalSearchVar', GetWidgetText('u106'));

SetWidgetRichText('u98', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dada</span></p>');

SetWidgetRichText('u99', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">dat</span></p>');

SetWidgetRichText('u100', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span><span style="font-family:Arial;font-size:13px;font-weight:normal;font-style:normal;text-decoration:none;color:#000000;">gi</span></p>');

SetWidgetRichText('u102', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

SetWidgetRichText('u82', '<p style="text-align:left;"><span style="font-family:Arial;font-size:13px;font-weight:bold;font-style:normal;text-decoration:none;color:#000000;">' + (GetGlobalVariableValue('IncrementalSearchVar')) + '</span></p>');

	SetPanelVisibility('u76','','none',500);

	BringToFront("u76");
function waitu796b5745765043a58e9fe38835b455f51() {

	SetPanelState('u76', 'pd1u76','none','',500,'none','',500);
}
setTimeout(waitu796b5745765043a58e9fe38835b455f51, 2000);

}
});

$axure.eventManager.blur('u106', function(e) {

if (true) {

SetGlobalVariableValue('SearchVar', GetWidgetText('u106'));

}
});
gv_vAlignTable['u223'] = 'top';u237.tabIndex = 0;

u237.style.cursor = 'pointer';
$axure.eventManager.click('u237', function(e) {

if (true) {

	SetPanelVisibility('u261','toggle','none',500);

	BringToFront("u261");

}
});
u156.tabIndex = 0;

u156.style.cursor = 'pointer';
$axure.eventManager.click('u156', function(e) {

if (true) {

rdo4ClosePanel(e);

}
});
u354.tabIndex = 0;

u354.style.cursor = 'pointer';
$axure.eventManager.click('u354', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u354'] = 'top';document.getElementById('u226_img').tabIndex = 0;

u226.style.cursor = 'pointer';
$axure.eventManager.click('u226', function(e) {

if (true) {

}
});
gv_vAlignTable['u381'] = 'center';gv_vAlignTable['u222'] = 'top';gv_vAlignTable['u311'] = 'center';gv_vAlignTable['u6'] = 'center';HookHover('u29', false);
gv_vAlignTable['u155'] = 'center';u209.tabIndex = 0;

u209.style.cursor = 'pointer';
$axure.eventManager.click('u209', function(e) {

if (true) {

	SetPanelVisibility('u163','toggle','none',500);

	BringToFront("u163");

}
});
gv_vAlignTable['u353'] = 'center';gv_vAlignTable['u272'] = 'center';document.getElementById('u19_img').tabIndex = 0;
HookHover('u19', false);

u19.style.cursor = 'pointer';
$axure.eventManager.click('u19', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Contact_us.html');

}
});
u367.tabIndex = 0;

u367.style.cursor = 'pointer';
$axure.eventManager.click('u367', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
gv_vAlignTable['u367'] = 'top';u104.tabIndex = 0;

u104.style.cursor = 'pointer';
$axure.eventManager.click('u104', function(e) {

if (true) {

	SetPanelVisibility('u76','hidden','none',500);

}
});

$axure.eventManager.mouseover('u104', function(e) {
if (!IsTrueMouseOver('u104',e)) return;
if (true) {

	SetPanelVisibility('u92','','none',500);

}
});

$axure.eventManager.mouseout('u104', function(e) {
if (!IsTrueMouseOut('u104',e)) return;
if (true) {

	SetPanelVisibility('u92','hidden','none',500);

}
});
gv_vAlignTable['u259'] = 'center';document.getElementById('u380_img').tabIndex = 0;

u380.style.cursor = 'pointer';
$axure.eventManager.click('u380', function(e) {

if (true) {

	self.location.href='http://creativecommons.org/licenses/by-nc-sa/2.0/uk/';

}
});
gv_vAlignTable['u221'] = 'top';
$axure.eventManager.change('u119', function(e) {

if (true) {

	SetPanelVisibility('u290','','none',500);
function waituc6b597b1627b447d90ef7f91ef53a8a71() {

	SetPanelVisibility('u290','hidden','none',500);
}
setTimeout(waituc6b597b1627b447d90ef7f91ef53a8a71, 300);

}
});
u235.tabIndex = 0;

u235.style.cursor = 'pointer';
$axure.eventManager.click('u235', function(e) {

if (true) {

	SetPanelVisibility('u240','toggle','none',500);

	BringToFront("u240");

}
});
u208.tabIndex = 0;

u208.style.cursor = 'pointer';
$axure.eventManager.click('u208', function(e) {

if (true) {

	SetPanelVisibility('u163','toggle','none',500);

	BringToFront("u163");

}
});
u366.tabIndex = 0;

u366.style.cursor = 'pointer';
$axure.eventManager.click('u366', function(e) {

if (true) {

    self.location.href="resources/reload.html#" + encodeURI($axure.globalVariableProvider.getLinkUrl($axure.pageData.url));

}
});
gv_vAlignTable['u366'] = 'top';gv_vAlignTable['u98'] = 'top';u103.tabIndex = 0;

u103.style.cursor = 'pointer';
$axure.eventManager.click('u103', function(e) {

if (true) {

	SetPanelVisibility('u76','hidden','none',500);

}
});

$axure.eventManager.mouseover('u103', function(e) {
if (!IsTrueMouseOver('u103',e)) return;
if (true) {

	SetPanelVisibility('u89','','none',500);

}
});

$axure.eventManager.mouseout('u103', function(e) {
if (!IsTrueMouseOut('u103',e)) return;
if (true) {

	SetPanelVisibility('u89','hidden','none',500);

}
});
u220.tabIndex = 0;

u220.style.cursor = 'pointer';
$axure.eventManager.click('u220', function(e) {

if (true) {

}
});
gv_vAlignTable['u220'] = 'top';u361.tabIndex = 0;

u361.style.cursor = 'pointer';
$axure.eventManager.click('u361', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
gv_vAlignTable['u361'] = 'top';document.getElementById('u31_img').tabIndex = 0;
HookHover('u31', false);

u31.style.cursor = 'pointer';
$axure.eventManager.click('u31', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
u234.tabIndex = 0;

u234.style.cursor = 'pointer';
$axure.eventManager.click('u234', function(e) {

if (true) {

	SetPanelVisibility('u240','toggle','none',500);

	BringToFront("u240");

}
});
gv_vAlignTable['u73'] = 'top';gv_vAlignTable['u351'] = 'center';gv_vAlignTable['u270'] = 'top';gv_vAlignTable['u199'] = 'top';gv_vAlignTable['u102'] = 'top';gv_vAlignTable['u56'] = 'center';u116.tabIndex = 0;

u116.style.cursor = 'pointer';
$axure.eventManager.click('u116', function(e) {

if ((GetGlobalVariableValue('LoginStatus')) == ('LoggedIn')) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('My_details.html');

}
else
if (((GetGlobalVariableValue('LoginStatus')) == ('LoggedOut')) || ((GetGlobalVariableValue('LoginStatus')) == (''))) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Sign_in_page.html');

}
});
gv_vAlignTable['u116'] = 'top';u233.tabIndex = 0;

u233.style.cursor = 'pointer';
$axure.eventManager.click('u233', function(e) {

if (true) {

	SetPanelVisibility('u240','toggle','none',500);

	BringToFront("u240");

}
});
gv_vAlignTable['u247'] = 'top';gv_vAlignTable['u198'] = 'top';u364.tabIndex = 0;

u364.style.cursor = 'pointer';
$axure.eventManager.click('u364', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Albums.html');

}
});
gv_vAlignTable['u364'] = 'top';u101.tabIndex = 0;

u101.style.cursor = 'pointer';
$axure.eventManager.click('u101', function(e) {

if (true) {

	SetPanelVisibility('u76','hidden','none',500);

}
});

$axure.eventManager.mouseover('u101', function(e) {
if (!IsTrueMouseOver('u101',e)) return;
if (true) {

	SetPanelVisibility('u86','','none',500);

}
});

$axure.eventManager.mouseout('u101', function(e) {
if (!IsTrueMouseOut('u101',e)) return;
if (true) {

	SetPanelVisibility('u86','hidden','none',500);

}
});
gv_vAlignTable['u338'] = 'center';u115.tabIndex = 0;

u115.style.cursor = 'pointer';
$axure.eventManager.click('u115', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Order_printed_catalogue.html');

}
});
gv_vAlignTable['u313'] = 'center';gv_vAlignTable['u232'] = 'top';gv_vAlignTable['u246'] = 'top';document.getElementById('u62_img').tabIndex = 0;

u62.style.cursor = 'pointer';
$axure.eventManager.click('u62', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Shopping_basket.html');

}
});
gv_vAlignTable['u219'] = 'center';u363.tabIndex = 0;

u363.style.cursor = 'pointer';
$axure.eventManager.click('u363', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('E_books.html');

}
});
gv_vAlignTable['u363'] = 'top';gv_vAlignTable['u132'] = 'center';gv_vAlignTable['u377'] = 'top';u372.tabIndex = 0;

u372.style.cursor = 'pointer';
$axure.eventManager.click('u372', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('FAQs.html');

}
});
gv_vAlignTable['u372'] = 'top';gv_vAlignTable['u114'] = 'center';gv_vAlignTable['u169'] = 'top';gv_vAlignTable['u187'] = 'center';gv_vAlignTable['u326'] = 'center';gv_vAlignTable['u245'] = 'center';gv_vAlignTable['u14'] = 'center';document.getElementById('u218_img').tabIndex = 0;

u218.style.cursor = 'pointer';
$axure.eventManager.click('u218', function(e) {

if (true) {

}
});
u362.tabIndex = 0;

u362.style.cursor = 'pointer';
$axure.eventManager.click('u362', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Laptops.html');

}
});
gv_vAlignTable['u362'] = 'top';gv_vAlignTable['u376'] = 'top';gv_vAlignTable['u75'] = 'center';u286.tabIndex = 0;

u286.style.cursor = 'pointer';
$axure.eventManager.click('u286', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
gv_vAlignTable['u286'] = 'top';u349.tabIndex = 0;

u349.style.cursor = 'pointer';
$axure.eventManager.click('u349', function(e) {

if (((GetWidgetText('u283')) != (' ')) && ((GetWidgetVisibility('u2')) == (true))) {

	SetPanelState('u120', 'pd1u120','none','',500,'none','',500);

	SetPanelState('u293', 'pd1u293','none','',500,'none','',500);

	SetPanelState('u2', 'pd1u2','none','',500,'none','',500);

}

if (((GetWidgetText('u283')) != (' ')) && ((GetWidgetVisibility('u2')) != (true))) {

	SetPanelState('u120', 'pd1u120','none','',500,'none','',500);

	SetPanelState('u293', 'pd1u293','none','',500,'none','',500);

}
else
if (true) {

	SetPanelState('u293', 'pd1u293','none','',500,'none','',500);

}
});
gv_vAlignTable['u168'] = 'center';gv_vAlignTable['u230'] = 'top';gv_vAlignTable['u127'] = 'top';u105.tabIndex = 0;

u105.style.cursor = 'pointer';
$axure.eventManager.click('u105', function(e) {

if (true) {

	SetPanelVisibility('u76','hidden','none',500);

}
});

$axure.eventManager.mouseover('u105', function(e) {
if (!IsTrueMouseOver('u105',e)) return;
if (true) {

	SetPanelVisibility('u95','','none',500);

}
});

$axure.eventManager.mouseout('u105', function(e) {
if (!IsTrueMouseOut('u105',e)) return;
if (true) {

	SetPanelVisibility('u95','hidden','none',500);

}
});
gv_vAlignTable['u375'] = 'top';document.getElementById('u27_img').tabIndex = 0;
HookHover('u27', false);

u27.style.cursor = 'pointer';
$axure.eventManager.click('u27', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Company.html');

}
});
u83.tabIndex = 0;

u83.style.cursor = 'pointer';
$axure.eventManager.click('u83', function(e) {

if (true) {

	SetPanelVisibility('u76','hidden','none',500);

}
});

$axure.eventManager.mouseover('u83', function(e) {
if (!IsTrueMouseOver('u83',e)) return;
if (true) {

	SetPanelVisibility('u79','','none',500);

}
});

$axure.eventManager.mouseout('u83', function(e) {
if (!IsTrueMouseOut('u83',e)) return;
if (true) {

	SetPanelVisibility('u79','hidden','none',500);

}
});
u207.tabIndex = 0;

u207.style.cursor = 'pointer';
$axure.eventManager.click('u207', function(e) {

if (true) {

	SetPanelVisibility('u163','toggle','none',500);

	BringToFront("u163");

}
});
gv_vAlignTable['u185'] = 'center';gv_vAlignTable['u40'] = 'center';gv_vAlignTable['u324'] = 'center';gv_vAlignTable['u243'] = 'top';u360.tabIndex = 0;

u360.style.cursor = 'pointer';
$axure.eventManager.click('u360', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music.html');

}
});
gv_vAlignTable['u360'] = 'top';gv_vAlignTable['u257'] = 'center';gv_vAlignTable['u69'] = 'center';gv_vAlignTable['u289'] = 'top';document.getElementById('u45_img').tabIndex = 0;
HookHover('u45', false);

u45.style.cursor = 'pointer';
$axure.eventManager.click('u45', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('City_maps.html');

}
});
u206.tabIndex = 0;

u206.style.cursor = 'pointer';
$axure.eventManager.click('u206', function(e) {

if (true) {

	SetPanelVisibility('u121','toggle','none',500);

	BringToFront("u121");

}
});
document.getElementById('u184_img').tabIndex = 0;

u184.style.cursor = 'pointer';
$axure.eventManager.click('u184', function(e) {

if (true) {

}
});
gv_vAlignTable['u242'] = 'center';document.getElementById('u53_img').tabIndex = 0;
HookHover('u53', false);

u53.style.cursor = 'pointer';
$axure.eventManager.click('u53', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Home.html');

}
});
gv_vAlignTable['u129'] = 'top';gv_vAlignTable['u174'] = 'center';u205.tabIndex = 0;

u205.style.cursor = 'pointer';
$axure.eventManager.click('u205', function(e) {

if (true) {

	SetPanelVisibility('u163','toggle','none',500);

	BringToFront("u163");

}
});

$axure.eventManager.click('u183', function(e) {

if (true) {

	SetPanelVisibility('u163','hidden','none',500);

}
});
gv_vAlignTable['u10'] = 'center';
$axure.eventManager.click('u141', function(e) {

if (true) {

	SetPanelVisibility('u121','hidden','none',500);

}
});
gv_vAlignTable['u197'] = 'center';gv_vAlignTable['u336'] = 'center';u255.tabIndex = 0;

u255.style.cursor = 'pointer';
$axure.eventManager.click('u255', function(e) {

if (true) {

rdo1ClosePanel(e);

}
});
gv_vAlignTable['u128'] = 'top';gv_vAlignTable['u288'] = 'top';gv_vAlignTable['u204'] = 'top';gv_vAlignTable['u182'] = 'center';u178.tabIndex = 0;

u178.style.cursor = 'pointer';
$axure.eventManager.click('u178', function(e) {

if (true) {

rdo5ClosePanel(e);

}
});
gv_vAlignTable['u140'] = 'center';document.getElementById('u23_img').tabIndex = 0;
HookHover('u23', false);

u23.style.cursor = 'pointer';
$axure.eventManager.click('u23', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Events.html');

}
});
gv_vAlignTable['u264'] = 'top';u371.tabIndex = 0;

u371.style.cursor = 'pointer';
$axure.eventManager.click('u371', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Music_videos.html');

}
});
gv_vAlignTable['u371'] = 'top';gv_vAlignTable['u203'] = 'top';u320.tabIndex = 0;

u320.style.cursor = 'pointer';
$axure.eventManager.click('u320', function(e) {

if (((GetWidgetText('u283')) != (' ')) && ((GetWidgetVisibility('u2')) == (true))) {

	SetPanelState('u120', 'pd0u120','none','',500,'none','',500);

	SetPanelState('u293', 'pd0u293','none','',500,'none','',500);

	SetPanelState('u2', 'pd0u2','none','',500,'none','',500);

}

if (((GetWidgetText('u283')) != (' ')) && ((GetWidgetVisibility('u2')) != (true))) {

	SetPanelState('u120', 'pd0u120','none','',500,'none','',500);

	SetPanelState('u293', 'pd0u293','none','',500,'none','',500);

}
else
if (true) {

	SetPanelState('u293', 'pd0u293','none','',500,'none','',500);

}
});
gv_vAlignTable['u4'] = 'center';gv_vAlignTable['u217'] = 'center';gv_vAlignTable['u195'] = 'center';gv_vAlignTable['u225'] = 'center';document.getElementById('u41_img').tabIndex = 0;
HookHover('u41', false);

u41.style.cursor = 'pointer';
$axure.eventManager.click('u41', function(e) {

if (true) {

	self.location.href=$axure.globalVariableProvider.getLinkUrl('Desktops.html');

}
});
gv_vAlignTable['u334'] = 'center';gv_vAlignTable['u153'] = 'center';